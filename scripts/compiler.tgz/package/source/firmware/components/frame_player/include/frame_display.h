#pragma once
#include "frame_player.h"

/* Conservative dirty coverage for nearest-neighbour expansion to the 360px LCD.
 * Bounds are clipped before arithmetic; empty/unsupported input returns empty. */
fp_dirty_rect_t fp_display_dirty(uint16_t width, uint16_t height, fp_dirty_rect_t dirty);
void fp_display_expand(const uint16_t *source, uint16_t width, uint16_t height,
                       uint16_t *display, fp_dirty_rect_t dirty);
