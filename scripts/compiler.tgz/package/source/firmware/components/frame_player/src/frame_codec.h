#pragma once
#include "frame_player.h"
#include "../vendor/miniz/miniz_tinfl.h"

enum { FP_MAX_RESOURCE_BYTES = 4 + FP_MAX_PIXELS + (FP_MAX_PIXELS + 7) / 8 };
typedef struct {
    tinfl_decompressor inflater;
    uint8_t decoded[FP_MAX_RESOURCE_BYTES];
} fp_codec_workspace_t;

const uint8_t *fp_decode_resource(const uint8_t *data, uint32_t length,
    uint8_t codec, uint32_t canvas, fp_codec_workspace_t *workspace,
    uint32_t *decoded_length);
