#include "frame_display.h"

fp_dirty_rect_t fp_display_dirty(uint16_t width, uint16_t height, fp_dirty_rect_t dirty)
{
    fp_dirty_rect_t empty = {0, 0, 0, 0};
    if (!((width == 120u || width == 240u) && height == width)) return empty;
    int32_t x0 = dirty.x, y0 = dirty.y;
    int32_t x1 = x0 + dirty.width, y1 = y0 + dirty.height;
    if (x0 < 0) x0 = 0;
    if (y0 < 0) y0 = 0;
    if (x1 > width) x1 = width;
    if (y1 > height) y1 = height;
    if (!dirty.width || !dirty.height || x1 <= x0 || y1 <= y0) return empty;
    int32_t left = x0 * 360 / width, top = y0 * 360 / height;
    int32_t right = (x1 * 360 + width - 1) / width;
    int32_t bottom = (y1 * 360 + height - 1) / height;
    return (fp_dirty_rect_t){ (int16_t)left, (int16_t)top,
        (uint16_t)(right - left), (uint16_t)(bottom - top) };
}

void fp_display_expand(const uint16_t *source, uint16_t width, uint16_t height,
                       uint16_t *display, fp_dirty_rect_t dirty)
{
    if (!source || !display) return;
    fp_dirty_rect_t area = fp_display_dirty(width, height, dirty);
    for (uint32_t y = (uint16_t)area.y; y < (uint32_t)area.y + area.height; y++) {
        for (uint32_t x = (uint16_t)area.x; x < (uint32_t)area.x + area.width; x++) {
            display[y * 360u + x] = source[(y * height / 360u) * width + x * width / 360u];
        }
    }
}
