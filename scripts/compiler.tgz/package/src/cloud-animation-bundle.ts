import { createHash } from "node:crypto";
import {
  mkdtempSync,
  readFileSync,
  rmSync,
  writeFileSync,
  mkdirSync,
} from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { PNG } from "pngjs";
import { z } from "zod";
import { parseFramePack, canonicalJson } from "./binary.js";
import { compileCharacter } from "./compiler.js";
import {
  FRAME_PACK_CANVAS,
  FRAME_PACK_PIXELS,
  FRAME_PACK_TICK_MS,
} from "./constants.js";
import { crc32 } from "./crc32.js";
import { to565 } from "./ingest/palette.js";
import { FramePlayer } from "./player.js";
import { WasmFramePlayer } from "./wasm-player.js";

export const CLOUD_ANIMATION_BUNDLE_VERSION = 1 as const;
export const CLOUD_ANIMATION_COMPILER_VERSION = "0.2.0-cloud.1" as const;
export const CLOUD_ANIMATION_MIME =
  "application/vnd.aipet.animation-bundle+json" as const;

const sha256Schema = z.string().regex(/^[a-f0-9]{64}$/);
const phaseSchema = z.enum(["anticipation", "action", "settle", "recovery"]);
const clipSchema = z
  .string()
  .regex(
    /^(foundation|states|expressions|attention|moods|signature|ambient|physical)\/[a-z0-9][a-z0-9-]{0,79}$/,
  );

export const cloudAnimationSelectionSchema = z
  .object({
    kind: z.literal("aipet-animation-selection"),
    contractVersion: z.literal(CLOUD_ANIMATION_BUNDLE_VERSION),
    character: z
      .object({
        id: z.string().regex(/^[a-z][a-z0-9_-]{0,63}$/),
        sourceSha256: sha256Schema,
      })
      .strict(),
    clip: clipSchema,
    sourceVideoSha256: sha256Schema,
    promptSha256: sha256Schema,
    generator: z
      .object({
        model: z.literal("minimax/h3-max/image-to-video"),
        resolution: z.literal("768P"),
        fps: z.literal(24),
        frameCount: z.literal(124),
        durationMs: z.number().int().min(5_000).max(5_300),
        seed: z.number().int().nonnegative().nullable(),
      })
      .strict(),
    frames: z
      .array(
        z
          .object({
            sourceFrame: z.number().int().min(0).max(123),
            durationMs: z
              .number()
              .int()
              .min(FRAME_PACK_TICK_MS)
              .max(10_000)
              .refine(
                (value) => value % FRAME_PACK_TICK_MS === 0,
                "duration must use the 33 ms grid",
              ),
            phase: phaseSchema,
            pngSha256: sha256Schema,
            rgb565Sha256: sha256Schema,
          })
          .strict(),
      )
      .min(10)
      .max(18),
    approvals: z
      .object({
        prompt: z
          .object({
            artifactSha256: sha256Schema,
            approver: z.string().min(1),
            approvedAt: z.string().datetime(),
          })
          .strict(),
        rawCandidate: z
          .object({
            artifactSha256: sha256Schema,
            approver: z.string().min(1),
            approvedAt: z.string().datetime(),
          })
          .strict(),
        selection: z
          .object({
            artifactSha256: sha256Schema,
            approver: z.string().min(1),
            approvedAt: z.string().datetime(),
          })
          .strict(),
      })
      .strict(),
  })
  .strict()
  .superRefine((value, context) => {
    const sourceFrames = value.frames.map((frame) => frame.sourceFrame);
    if (new Set(sourceFrames).size !== sourceFrames.length)
      context.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["frames"],
        message: "source frames must be unique",
      });
    for (let index = 1; index < sourceFrames.length; index++)
      if (sourceFrames[index]! <= sourceFrames[index - 1]!)
        context.addIssue({
          code: z.ZodIssueCode.custom,
          path: ["frames", index, "sourceFrame"],
          message: "source frames must be strictly ordered",
        });
    for (const phase of phaseSchema.options)
      if (!value.frames.some((frame) => frame.phase === phase))
        context.addIssue({
          code: z.ZodIssueCode.custom,
          path: ["frames"],
          message: `selection requires ${phase}`,
        });
    for (const key of ["pngSha256", "rgb565Sha256"] as const) {
      const hashes = value.frames.map((frame) => frame[key]);
      if (new Set(hashes).size !== hashes.length)
        context.addIssue({
          code: z.ZodIssueCode.custom,
          path: ["frames"],
          message: `${key} values must be unique; encode holds with duration`,
        });
    }
  });

export type CloudAnimationSelection = z.infer<
  typeof cloudAnimationSelectionSchema
>;

export interface CloudAnimationFrameAnalysis {
  sourceFrame: number;
  changedPixels: number;
  motion: number;
  centroidX: number;
  centroidY: number;
  foregroundPixels: number;
  componentCount: number;
  meanLuma: number;
  touchesEdge: boolean;
  rgb565Sha256: string;
  framebufferCrc32: string;
}

export interface CloudAnimationAnalysis {
  suggestedSourceFrames: number[];
  frames: CloudAnimationFrameAnalysis[];
  intervalMotionShares: number[];
  warnings: Array<{ code: string; sourceFrame: number | null; detail: string }>;
  totalMotion: number;
}

interface DeviceFrame {
  png: Uint8Array;
  rgb565: Uint16Array;
  rgb565Bytes: Uint8Array;
  foreground: Uint8Array;
  lumaPixels: Uint8Array;
  centroidX: number;
  centroidY: number;
  foregroundPixels: number;
  componentCount: number;
  meanLuma: number;
  touchesEdge: boolean;
}

const digest = (bytes: Uint8Array | string): string =>
  createHash("sha256").update(bytes).digest("hex");
const hex32 = (value: number): string => value.toString(16).padStart(8, "0");

function decodeDeviceFrame(pngBytes: Uint8Array): DeviceFrame {
  const image = PNG.sync.read(Buffer.from(pngBytes));
  if (image.width !== FRAME_PACK_CANVAS || image.height !== FRAME_PACK_CANVAS)
    throw new Error(
      `CLOUD_FRAME_DIMENSIONS_INVALID:${image.width}x${image.height}`,
    );
  const colors = new Map<number, number>();
  const border: number[] = [];
  for (let index = 0; index < FRAME_PACK_PIXELS; index++) {
    if (image.data[index * 4 + 3] !== 255)
      throw new Error(`CLOUD_FRAME_ALPHA_INVALID:${index}`);
    const value = to565([
      image.data[index * 4]!,
      image.data[index * 4 + 1]!,
      image.data[index * 4 + 2]!,
    ]);
    colors.set(value, (colors.get(value) ?? 0) + 1);
    const x = index % FRAME_PACK_CANVAS,
      y = Math.floor(index / FRAME_PACK_CANVAS);
    if (
      x < 4 ||
      y < 4 ||
      x >= FRAME_PACK_CANVAS - 4 ||
      y >= FRAME_PACK_CANVAS - 4
    )
      border.push(value);
  }
  const borderCounts = new Map<number, number>();
  for (const value of border)
    borderCounts.set(value, (borderCounts.get(value) ?? 0) + 1);
  const background =
    [...borderCounts.entries()].sort(
      (a, b) => b[1] - a[1] || a[0] - b[0],
    )[0]?.[0] ?? 0;
  const rgb565 = new Uint16Array(FRAME_PACK_PIXELS),
    foreground = new Uint8Array(FRAME_PACK_PIXELS),
    lumaPixels = new Uint8Array(FRAME_PACK_PIXELS);
  let sumX = 0,
    sumY = 0,
    foregroundPixels = 0,
    luma = 0,
    touchesEdge = false;
  for (let index = 0; index < FRAME_PACK_PIXELS; index++) {
    const red = image.data[index * 4]!,
      green = image.data[index * 4 + 1]!,
      blue = image.data[index * 4 + 2]!;
    const value = to565([red, green, blue]);
    rgb565[index] = value;
    lumaPixels[index] = Math.round(
      red * 0.2126 + green * 0.7152 + blue * 0.0722,
    );
    const isForeground = value !== background;
    if (isForeground) {
      foreground[index] = 1;
      foregroundPixels++;
      const x = index % FRAME_PACK_CANVAS,
        y = Math.floor(index / FRAME_PACK_CANVAS);
      sumX += x;
      sumY += y;
      luma += red * 0.2126 + green * 0.7152 + blue * 0.0722;
      if (x <= 1 || y <= 1 || x >= 118 || y >= 118) touchesEdge = true;
    }
  }
  const rgb565Bytes = new Uint8Array(rgb565.length * 2),
    view = new DataView(rgb565Bytes.buffer);
  rgb565.forEach((value, index) => view.setUint16(index * 2, value, true));
  const visited = new Uint8Array(FRAME_PACK_PIXELS);
  let componentCount = 0;
  for (let origin = 0; origin < FRAME_PACK_PIXELS; origin++) {
    if (!foreground[origin] || visited[origin]) continue;
    const queue = [origin];
    visited[origin] = 1;
    let size = 0;
    while (queue.length) {
      const current = queue.pop()!;
      size++;
      const x = current % FRAME_PACK_CANVAS,
        y = Math.floor(current / FRAME_PACK_CANVAS);
      for (const neighbor of [
        x > 0 ? current - 1 : -1,
        x < FRAME_PACK_CANVAS - 1 ? current + 1 : -1,
        y > 0 ? current - FRAME_PACK_CANVAS : -1,
        y < FRAME_PACK_CANVAS - 1 ? current + FRAME_PACK_CANVAS : -1,
      ]) {
        if (neighbor >= 0 && foreground[neighbor] && !visited[neighbor]) {
          visited[neighbor] = 1;
          queue.push(neighbor);
        }
      }
    }
    // Ignore isolated antialiasing noise; count only visually meaningful
    // foreground islands that could represent detached or duplicated anatomy.
    if (size >= 6) componentCount++;
  }
  return {
    png: pngBytes,
    rgb565,
    rgb565Bytes,
    foreground,
    lumaPixels,
    centroidX: foregroundPixels ? sumX / foregroundPixels : 59.5,
    centroidY: foregroundPixels ? sumY / foregroundPixels : 59.5,
    foregroundPixels,
    componentCount,
    meanLuma: foregroundPixels ? luma / foregroundPixels : 0,
    touchesEdge,
  };
}

function changeCount(left: Uint16Array, right: Uint16Array): number {
  let changed = 0;
  for (let index = 0; index < left.length; index++)
    if (left[index] !== right[index]) changed++;
  return changed;
}

function suggestedFrames(motions: number[], target = 14): number[] {
  const total = motions.reduce((sum, value) => sum + value, 0);
  if (total <= 0)
    return Array.from({ length: target }, (_, index) =>
      Math.round((index * 123) / (target - 1)),
    );
  const cumulative: number[] = [0];
  for (const motion of motions) cumulative.push(cumulative.at(-1)! + motion);
  const selected = new Set<number>([0, 123]);
  for (let slot = 1; slot < target - 1; slot++) {
    const threshold = (total * slot) / (target - 1);
    let index = cumulative.findIndex((value) => value >= threshold);
    if (index < 0) index = 123;
    selected.add(Math.min(123, Math.max(0, index)));
  }
  for (let index = 0; selected.size < target && index < 124; index++)
    selected.add(Math.round((index * 123) / (target - 1)));
  return [...selected].sort((a, b) => a - b).slice(0, target);
}

export function analyzeCloudH3Frames(
  pngFrames: readonly Uint8Array[],
): CloudAnimationAnalysis {
  if (pngFrames.length !== 124)
    throw new Error(`CLOUD_FRAME_COUNT_INVALID:${pngFrames.length}`);
  const decoded = pngFrames.map(decodeDeviceFrame),
    motions = decoded
      .slice(1)
      .map(
        (frame, index) =>
          changeCount(decoded[index]!.rgb565, frame.rgb565) / FRAME_PACK_PIXELS,
      );
  const totalMotion = motions.reduce((sum, value) => sum + value, 0),
    selected = suggestedFrames(motions);
  const intervalMotionShares = selected.slice(1).map((sourceFrame, index) => {
    const start = selected[index]!;
    let motion = 0;
    for (let at = start; at < sourceFrame; at++) motion += motions[at] ?? 0;
    return totalMotion ? motion / totalMotion : 0;
  });
  const warnings: CloudAnimationAnalysis["warnings"] = [];
  decoded.forEach((frame, sourceFrame) => {
    if (frame.touchesEdge)
      warnings.push({
        code: "CANVAS_EDGE_CONTACT",
        sourceFrame,
        detail: "Foreground reaches the two-pixel device safety edge.",
      });
    if (sourceFrame > 0) {
      const prior = decoded[sourceFrame - 1]!,
        changed = motions[sourceFrame - 1]!;
      if (changed === 0)
        warnings.push({
          code: "DUPLICATE_SOURCE_FRAME",
          sourceFrame,
          detail:
            "Frame is byte-identical in RGB565 to its predecessor; encode a hold with duration instead.",
        });
      if (changed > 0.2)
        warnings.push({
          code: "DISCONTINUITY_OR_CUT",
          sourceFrame,
          detail:
            "More than twenty percent of device pixels change in one source frame; inspect for a cut or reconstruction jump.",
        });
      if (
        Math.hypot(
          frame.centroidX - prior.centroidX,
          frame.centroidY - prior.centroidY,
        ) > 4
      )
        warnings.push({
          code: "CENTER_JUMP",
          sourceFrame,
          detail:
            "Foreground centroid moves more than four device pixels in one source frame.",
        });
      const scaleDelta = prior.foregroundPixels
        ? Math.abs(frame.foregroundPixels - prior.foregroundPixels) /
          prior.foregroundPixels
        : 0;
      if (scaleDelta > 0.08)
        warnings.push({
          code: "SCALE_OR_SILHOUETTE_JUMP",
          sourceFrame,
          detail:
            "Foreground area changes by more than eight percent between adjacent frames.",
        });
      if (Math.abs(frame.meanLuma - prior.meanLuma) > 28)
        warnings.push({
          code: "PALETTE_OR_SURFACE_SHADOW_POP",
          sourceFrame,
          detail:
            "Character luminance changes abruptly; inspect palette drift or a harsh surface shadow.",
        });
      let newlyShadowed = 0,
        sharedForeground = 0;
      for (let pixel = 0; pixel < FRAME_PACK_PIXELS; pixel++) {
        if (!frame.foreground[pixel] || !prior.foreground[pixel]) continue;
        sharedForeground++;
        if (prior.lumaPixels[pixel]! - frame.lumaPixels[pixel]! > 45)
          newlyShadowed++;
      }
      if (sharedForeground && newlyShadowed / sharedForeground > 0.04)
        warnings.push({
          code: "HARSH_SURFACE_SHADOW",
          sourceFrame,
          detail:
            "A hard dark patch appears across more than four percent of the shared character surface.",
        });
      if (Math.abs(frame.componentCount - prior.componentCount) >= 1)
        warnings.push({
          code: "DETACHED_OR_DUPLICATED_ACCESSORY",
          sourceFrame,
          detail:
            "The number of meaningful foreground islands changes abruptly; inspect limbs, facial parts, horns, and accessories.",
        });
    }
  });
  const loopMotion =
    changeCount(decoded[123]!.rgb565, decoded[0]!.rgb565) / FRAME_PACK_PIXELS;
  if (
    loopMotion > 0.04 ||
    Math.hypot(
      decoded[123]!.centroidX - decoded[0]!.centroidX,
      decoded[123]!.centroidY - decoded[0]!.centroidY,
    ) > 3
  )
    warnings.push({
      code: "LOOP_SEAM",
      sourceFrame: 123,
      detail:
        "The final frame does not return close enough to the opening frame for a clean loop.",
    });
  intervalMotionShares.forEach((share, index) => {
    if (share > 0.12)
      warnings.push({
        code: "SELECTION_MOTION_GAP",
        sourceFrame: selected[index + 1]!,
        detail: `Suggested interval carries ${(share * 100).toFixed(1)}% of measured motion.`,
      });
  });
  return {
    suggestedSourceFrames: selected,
    intervalMotionShares,
    totalMotion,
    warnings,
    frames: decoded.map((frame, sourceFrame) => ({
      sourceFrame,
      changedPixels: sourceFrame
        ? Math.round((motions[sourceFrame - 1] ?? 0) * FRAME_PACK_PIXELS)
        : 0,
      motion: sourceFrame ? (motions[sourceFrame - 1] ?? 0) : 0,
      centroidX: frame.centroidX,
      centroidY: frame.centroidY,
      foregroundPixels: frame.foregroundPixels,
      componentCount: frame.componentCount,
      meanLuma: frame.meanLuma,
      touchesEdge: frame.touchesEdge,
      rgb565Sha256: digest(frame.rgb565Bytes),
      framebufferCrc32: hex32(crc32(frame.rgb565Bytes)),
    })),
  };
}

function validationManifest(selection: CloudAnimationSelection) {
  const refs = selection.frames.map((_, index) => ({
    frame: {
      file: `frames/${String(index).padStart(2, "0")}.png`,
      kind: "device-grid" as const,
    },
    durationMs: selection.frames[index]!.durationMs,
  }));
  const phases = (phase: z.infer<typeof phaseSchema>) =>
    refs.filter((_, index) => selection.frames[index]!.phase === phase);
  const enterSteps = [...phases("anticipation"), ...phases("action")];
  const holdSteps = phases("settle");
  const exitSteps = phases("recovery");
  return {
    schemaVersion: 4,
    id: "cloud_validation",
    name: "Cloud validation",
    version: "0.0.1",
    gender: "neutral",
    canvas: { width: 120, height: 120 },
    budgetBytes: 2_752_512,
    neutral: { file: "neutral.png", kind: "device-grid" },
    talk: {
      stages: [
        { file: "neutral.png", kind: "device-grid" },
        { file: "neutral.png", kind: "device-grid" },
      ],
      levelBreakpoints: [0, 100],
    },
    emotions: {
      sad: {
        enterSteps,
        holdSteps,
        exitSteps,
        holdMode: "hold-last",
        minHoldMs: 0,
        maxHoldMs: 500,
      },
    },
    idle: {
      bob: { amplitudePx: 0, periodMs: 3168 },
      micro: { minGapMs: 120_000, maxGapMs: 120_001, onsetTicks: 5 },
      performances: [],
    },
    palette: { maxColors: 256, talkReserve: 180 },
    actions: [],
    motion: { fallbacksEnabled: false, parallaxSafe: false, maxParallaxPx: 0 },
    provenance: {
      origin: {
        repoBranch: "cloud-validation",
        commit: selection.sourceVideoSha256,
      },
      generation: selection.generator.model,
      publicationRights:
        "Validation-only authoring artifact; not a complete resident pack.",
    },
    approval: {
      status: "pending",
      notes: "Temporary exact-player validation pack.",
    },
  };
}

function compileValidationPack(
  selection: CloudAnimationSelection,
  frames: readonly Uint8Array[],
): Uint8Array {
  const root = mkdtempSync(join(tmpdir(), "aipet-cloud-validation-"));
  try {
    mkdirSync(join(root, "frames"));
    const lockFiles: Record<string, { sha256: string; bytes: number }> = {};
    frames.forEach((bytes, index) => {
      const file = `frames/${String(index).padStart(2, "0")}.png`;
      writeFileSync(join(root, file), bytes);
      lockFiles[file] = { sha256: digest(bytes), bytes: bytes.byteLength };
    });
    writeFileSync(join(root, "neutral.png"), frames[0]!);
    lockFiles["neutral.png"] = {
      sha256: digest(frames[0]!),
      bytes: frames[0]!.byteLength,
    };
    writeFileSync(
      join(root, "character.json"),
      `${JSON.stringify(validationManifest(selection), null, 2)}\n`,
    );
    writeFileSync(
      join(root, "SOURCES.lock.json"),
      `${JSON.stringify({ origin: { repoBranch: "cloud-validation", commit: selection.sourceVideoSha256 }, files: lockFiles }, null, 2)}\n`,
    );
    return compileCharacter(root, "character.json", { reviewCandidate: true })
      .pack;
  } finally {
    rmSync(root, { recursive: true, force: true });
  }
}

function parityTrace(
  packBytes: Uint8Array,
  wasmBytes: Uint8Array,
): { ticks: number; crc32: string[]; reportSha256: string } {
  const parsed = parseFramePack(packBytes),
    typescript = new FramePlayer(parsed, 0x4833),
    wasm = WasmFramePlayer.create(wasmBytes, packBytes, 0x4833);
  typescript.setEmotion(8);
  wasm.setEmotion(8);
  const crc: string[] = [];
  for (let tick = 0; tick < 360; tick++) {
    typescript.tick();
    wasm.tick();
    const ts = typescript.frameCrc32(),
      portable = wasm.frameCrc32();
    if (ts !== portable)
      throw new Error(
        `CLOUD_RUNTIME_PARITY_FAILED:${tick}:${hex32(ts)}:${hex32(portable)}`,
      );
    crc.push(hex32(ts));
  }
  return {
    ticks: crc.length,
    crc32: crc,
    reportSha256: digest(
      canonicalJson({ runtime: ["typescript", "portable-c-wasm"], crc }),
    ),
  };
}

export function bundledFramePlayerWasm(): Uint8Array {
  return readFileSync(
    fileURLToPath(new URL("./frame_player.wasm", import.meta.url)),
  );
}

export interface CompiledCloudAnimationBundle {
  bytes: Uint8Array;
  sha256: string;
  validationPack: Uint8Array;
  validationPackSha256: string;
  parityReportSha256: string;
  tickCount: number;
}

export function compileCloudAnimationBundle(
  rawSelection: unknown,
  pngFrames: readonly Uint8Array[],
  options: { compilerCommit: string; wasmBytes?: Uint8Array },
): CompiledCloudAnimationBundle {
  const selection = cloudAnimationSelectionSchema.parse(rawSelection);
  if (!/^[a-f0-9]{7,40}$/.test(options.compilerCommit))
    throw new Error("CLOUD_COMPILER_COMMIT_INVALID");
  if (pngFrames.length !== selection.frames.length)
    throw new Error("CLOUD_SELECTED_FRAME_COUNT_MISMATCH");
  const decoded = pngFrames.map(decodeDeviceFrame);
  decoded.forEach((frame, index) => {
    if (digest(frame.png) !== selection.frames[index]!.pngSha256)
      throw new Error(`CLOUD_FRAME_PNG_HASH_MISMATCH:${index}`);
    if (digest(frame.rgb565Bytes) !== selection.frames[index]!.rgb565Sha256)
      throw new Error(`CLOUD_FRAME_RGB565_HASH_MISMATCH:${index}`);
  });
  const validationPack = compileValidationPack(selection, pngFrames),
    parity = parityTrace(
      validationPack,
      options.wasmBytes ?? bundledFramePlayerWasm(),
    );
  const bundle = {
    kind: "aipet-animation-bundle",
    contractVersion: CLOUD_ANIMATION_BUNDLE_VERSION,
    compiler: {
      package: "@aipet/frame-pack",
      version: CLOUD_ANIMATION_COMPILER_VERSION,
      commit: options.compilerCommit,
    },
    selection,
    frames: pngFrames.map((bytes, index) => ({
      ...selection.frames[index],
      pngBase64: Buffer.from(bytes).toString("base64"),
    })),
    validation: {
      temporaryPackSha256: digest(validationPack),
      runtimes: ["typescript", "portable-c-wasm"],
      ticks: parity.ticks,
      traceCrc32: parity.crc32,
      reportSha256: parity.reportSha256,
    },
    finalPack: { eligible: false, blocker: "SPEAKING_FOUNDATION_REQUIRED" },
  };
  const bytes = new TextEncoder().encode(`${canonicalJson(bundle)}\n`);
  return {
    bytes,
    sha256: digest(bytes),
    validationPack,
    validationPackSha256: digest(validationPack),
    parityReportSha256: parity.reportSha256,
    tickCount: parity.ticks,
  };
}
