// TypeScript reference implementation of the full-frame animation director.
//
// This file IS the behavioral specification: the C implementation in
// firmware/components/frame_player mirrors it statement for statement, and
// the parity tests assert per-tick framebuffer CRC equality between the two.
// Everything here is integer math on latched inputs — the same input sequence
// and seed produce byte-identical frames forever, on any host.

import type { ActionEntry, ParsedFramePack } from "./binary.js";
import { isMaskedCodec, isDenseCodec } from "./frame-codec.js";
import { crc32 } from "./crc32.js";
import {
  ACTION_NO_CLIP,
  LOOP_HOLD_LAST,
  LOOP_LOOP,
  LOOP_ONCE,
  PROFILE_BITS,
  ROLE_ABSENT,
  ROLE_IDLE_NEUTRAL,
  SPEAKING_DRIFT_MAX_TICKS,
  SPEAKING_DRIFT_MIN_TICKS,
  SPEAKING_DRIFT_PX,
} from "./constants.js";

/**
 * Touch, shake and gesture pulses and ambient events play once per trigger.
 * Nothing else ends them, so their main clip plays once whatever its loop
 * mode (fp_triggered_one_shot).
 */
export function isTriggeredOneShot(action: Pick<ActionEntry, "semantic" | "activationKind">): boolean {
  return action.activationKind === "ambient-event" || (action.activationKind === "semantic" &&
    (action.semantic === "touch" || action.semantic === "shake" || action.semantic.startsWith("gesture-")));
}

/** Mirrors pet_face_state_t ordinals exactly. */
export const enum SysState {
  BOOTING = 0,
  PROVISIONING = 1,
  CONNECTING = 2,
  IDLE = 3,
  LISTENING = 4,
  THINKING = 5,
  SPEAKING = 6,
  OFFLINE = 7,
  ERROR = 8,
}

export const enum Phase {
  SYS_STATIC = 0,
  IDLE = 1,
  MICRO = 2,
  EMO_ENTER = 3,
  EMO_HOLD = 4,
  EMO_EXIT = 5,
  TALK = 6,
  ATTEND = 7,
}

/** How the pet idles when nothing else happens (mirrors fp_idle_mode_t). */
export const enum IdleMode {
  HOLD = 0, // neutral idle while direct semantic actions are reviewed
  SHOWCASE = 1, // the default: every emotion and performance in turn
  NATURAL = 2, // authored micro gaps, a manual action after a stretch of calm, and interrupted loops resume
}

export const enum AnimationProfile {
  FULL = 0,
  BALANCED = 1,
  REDUCED = 2,
}

export interface DirtyRect {
  x: number;
  y: number;
  width: number;
  height: number;
}

interface ActionCursor {
  action: number;
  clip: number;
  step: number;
  ticksLeft: number;
  entering: boolean;
  exiting: boolean;
  complete: boolean;
}

/** Director tuning constants (ticks are 33 ms). Mirrored in frame_player.c. */
export const SETTLE_TICKS = 30; // 1 s calm after leaving a system state
export const EMOTION_COOLDOWN_TICKS = 18; // ~600 ms same-emotion re-entry block
export const TALK_STAGE_MIN_DWELL_TICKS = 2; // 66 ms before a stage may change down
export const TALK_LOWER_STREAK_TICKS = 2; // consecutive lower mappings required
export const SHOWCASE_GAP_TICKS = 15; // ~0.5 s neutral hub between emotions
export const SHOWCASE_MIN_HOLD_MS = 3000;
export const SHOWCASE_MAX_HOLD_MS = 6000;
/** Natural idle: ticks of calm before a manual action (about 4 to 10 minutes). */
export const CALM_MIN_TICKS = 7200;
export const CALM_MAX_TICKS = 18000;

const EMOTION_NONE = -1;

export class FramePlayer {
  private readonly pack: ParsedFramePack;
  readonly framebuffer: Uint16Array;

  // Latched inputs.
  private sysState: number = SysState.BOOTING;
  private requestedEmotion: number = EMOTION_NONE; // -1 none, 0 clear, 1.. emotion id
  private audioLevel = 0;
  private tapPending = false;
  private shakePending = false;
  private gesturePending: string | null = null;
  private requestedAction = -1;
  private tiltX = 0;
  private tiltY = 0;
  private animationProfile = AnimationProfile.BALANCED;
  private idleMode: number = IdleMode.SHOWCASE;
  private optionalSuppressionTicks = 0;

  // Director state.
  private phase: Phase = Phase.SYS_STATIC;
  private clipIndex = 0;
  private clipStep = 0;
  private clipTicksLeft = 0;
  private currentEmotion = 0; // 0 none, else emotion id
  private pendingEmotion = 0; // queued while exiting / talking; 0 none
  private clearRequested = false;
  private holdMinTicksLeft = 0;
  private holdMaxTicksLeft = 0;
  private cooldownEmotion = 0;
  private cooldownTicksLeft = 0;
  private settleTicksLeft = 0;
  private microCountdown = 0;
  private showcaseIndex = 0;
  private showcaseCountdown = 0;
  private calmCountdown = -1; // -1 until calm begins in IdleMode.NATURAL
  private talkStage = 0;
  private talkDwellTicksLeft = 0;
  private talkLowerStreak = 0;
  private bobTick = 0;
  private shownSysState = -1; // sys state the current SYS/ATTEND clip was chosen for
  private prngState: number;
  private readonly actionCursors: (ActionCursor | null)[] = [null, null, null, null, null];
  private readonly actionEventCountdown: number[];
  private readonly actionCooldownTicks: number[];
  private readonly actionWasEligible: boolean[];
  // IdleMode.NATURAL: the step and ticks each interrupted ambient loop would
  // have shown next, where it resumes; 0 ticks when there is none.
  private readonly loopResumeStep: number[];
  private readonly loopResumeTicks: number[];
  private readonly previousFramebuffer: Uint16Array;
  private visualRevision = 0;
  private dirtyRect: DirtyRect | null = null;
  private fallbackTouchTicks = 0;
  private fallbackShakeTicks = 0;
  private facialGroup = 0;
  private facialBlinkStage = 0;
  private facialBlinkTicks = 0;
  private facialBlinkCountdown = 1;
  private facialPosePhase = 0;
  private facialPoseSide = 1;
  private facialPoseTicks = 1;
  // Speaking poses: gestures between pose banks while talking, and the
  // owner's optional drift. Visible only in TALK; reset on entering it.
  private speakingDriftEnabled = false;
  private speakingPose = 0;
  private speakingGesture = -1;
  private speakingStep = 0;
  private speakingStepTicks = 0;
  private speakingNeutralTicks = 0;
  private speakingBreakTicks = 0;
  private readonly speakingBag: number[] = [];
  private speakingLastGesture = -1;
  private driftStarted = false;
  private driftX = 0;
  private driftY = 0;
  private driftFromX = 0;
  private driftFromY = 0;
  private driftToX = 0;
  private driftToY = 0;
  private driftElapsed = 0;
  private driftDuration = 1;

  constructor(pack: ParsedFramePack, seed: number) {
    this.pack = pack;
    this.framebuffer = new Uint16Array(pack.info.width * pack.info.height); this.previousFramebuffer = new Uint16Array(this.framebuffer.length);
    this.actionEventCountdown = new Array(pack.actions.length).fill(-1);
    this.actionCooldownTicks = new Array(pack.actions.length).fill(0);
    this.actionWasEligible = new Array(pack.actions.length).fill(false);
    this.loopResumeStep = new Array(pack.actions.length).fill(0);
    this.loopResumeTicks = new Array(pack.actions.length).fill(0);
    this.prngState = seed >>> 0 || 0x9e3779b9;
    if (pack.facialRegions) this.facialGroup = pack.facialRegions.centerGroup;
    if (pack.facialRegions?.independentBlink) this.facialPoseTicks=pack.facialRegions.gazeStageTicks![0]!;
    this.enterSysStatic();
    this.render(false);
  }

  setSysState(state: number): void {
    // State masks are 16-bit; an unknown state would shift out of range.
    if ((state | 0) !== state || state < SysState.BOOTING || state > SysState.ERROR) return;
    if(this.sysState!==(state|0))this.requestedAction=-1;
    this.sysState = state | 0;
  }

  requestAction(index:number):boolean {
    if(index===-1){this.requestedAction=-1;return true;}
    if(!Number.isInteger(index)||index<0||index>=this.pack.actions.length||this.pack.actions[index]!.activationKind!=="manual"||
       this.actionCooldownTicks[index]!>0||!this.baseActionAllowed(index)||!this.actionContextMatches(index,false))return false;
    this.requestedAction=index;return true;
  }

  /** id 0 clears the current emotion; unknown ids are ignored at tick time. */
  setEmotion(id: number): void {
    this.requestedEmotion = id | 0;
  }

  setAudioLevel(level: number): void {
    this.audioLevel = level < 0 ? 0 : level > 100 ? 100 : level | 0;
  }

  notifyTap(): void {
    this.tapPending = true;
  }

  notifyTouch(): void {
    this.tapPending = true;
  }

  notifyShake(): void {
    this.shakePending = true;
  }

  notifyGesture(semantic: "gesture-nod" | "gesture-focus" | "gesture-heartbeat" | "gesture-bounce" | "gesture-wobble" | "gesture-pop"): void {
    this.gesturePending = semantic;
  }

  setTilt(x: number, y: number): void {
    this.tiltX = Math.max(-100, Math.min(100, x | 0));
    this.tiltY = Math.max(-100, Math.min(100, y | 0));
  }

  setAnimationProfile(profile: AnimationProfile): void {
    this.animationProfile = profile < AnimationProfile.FULL || profile > AnimationProfile.REDUCED
      ? AnimationProfile.BALANCED
      : profile;
  }

  /** Hold neutral idle while direct semantic actions are reviewed. */
  setIdleShowcaseEnabled(enabled: boolean): void {
    this.setIdleMode(enabled ? IdleMode.SHOWCASE : IdleMode.HOLD);
    if (!enabled) {
      this.requestedEmotion = 0;
      this.pendingEmotion = 0;
    }
  }

  /** Setting the current mode again changes nothing. */
  setIdleMode(mode: IdleMode): void {
    const next = mode === IdleMode.HOLD || mode === IdleMode.NATURAL ? mode : IdleMode.SHOWCASE;
    if (this.idleMode === next) return;
    this.idleMode = next;
    this.calmCountdown = -1;
    // Interrupted loops resume only within one stretch of natural idle.
    this.loopResumeTicks.fill(0);
    if (next === IdleMode.HOLD) {
      this.requestedEmotion = 0;
      this.pendingEmotion = 0;
    }
  }

  /** Subtle speaking movement: the owner's setting, off by default. */
  setSpeakingDrift(enabled: boolean): void {
    this.speakingDriftEnabled = enabled;
  }

  reportHealth(audioHealthy: boolean, presentationMs: number): void {
    if (!audioHealthy || presentationMs > 20) this.optionalSuppressionTicks = Math.ceil(2000 / this.pack.info.tickMs);
  }

  debugPhase(): number {
    return this.phase;
  }

  debugFrame(): number {
    return this.currentFrame();
  }

  debugFacialGroup(): number { return this.pack.facialRegions ? this.facialGroup : -1; }
  debugMouthStage(): number { return this.phase === Phase.TALK ? this.talkStage : 0; }
  debugBlinkStage(): number { return this.facialBlinkStage; }
  debugSpeakingPose(): number { return this.phase === Phase.TALK ? this.speakingPose : 0; }
  debugSpeakingGesture(): number { return this.phase === Phase.TALK ? this.speakingGesture : -1; }

  debugOffsetY(): number {
    return this.facialCompatible() ? this.facialOffsetY() : this.currentOffsetY();
  }

  debugOffsetX(): number {
    return this.currentOffsetX();
  }

  debugActiveAction(plane: number): number {
    return this.actionCursors[plane]?.action ?? -1;
  }

  getVisualRevision(): number {
    return this.visualRevision;
  }

  getDirtyRect(): DirtyRect | null {
    return this.dirtyRect ? { ...this.dirtyRect } : null;
  }

  frameCrc32(): number {
    // Serialize explicitly little-endian (the wire/device layout) instead of
    // viewing the Uint16Array's host-endian bytes.
    const fb = this.framebuffer;
    const bytes = new Uint8Array(fb.length * 2);
    for (let i = 0; i < fb.length; i++) {
      bytes[i * 2] = fb[i]! & 0xff;
      bytes[i * 2 + 1] = fb[i]! >> 8;
    }
    return crc32(bytes);
  }

  // ---- PRNG (xorshift32) — draw order is part of the parity contract. ----
  private nextRandom(): number {
    let x = this.prngState;
    x ^= (x << 13) >>> 0;
    x = x >>> 0;
    x ^= x >>> 17;
    x ^= (x << 5) >>> 0;
    x = x >>> 0;
    this.prngState = x;
    return x;
  }

  private drawMicroCountdown(): void {
    const { microGapMinTicks, microGapMaxTicks, micro } = this.pack.idle;
    if (micro.length === 0) {
      this.microCountdown = -1;
      return;
    }
    const span = microGapMaxTicks - microGapMinTicks + 1;
    this.microCountdown = microGapMinTicks + (this.nextRandom() % span);
  }

  private drawMicroClip(): number {
    const { micro } = this.pack.idle;
    // Mirrors the defensive C boundary. The normal countdown path never
    // calls this for an empty list, but neutral is the safe recovery target
    // if director state is ever corrupted or restored inconsistently.
    if (micro.length === 0) return this.pack.roles[ROLE_IDLE_NEUTRAL]!;
    let total = 0;
    for (const m of micro) total += m.weight;
    let r = this.nextRandom() % total;
    for (const m of micro) {
      if (r < m.weight) return m.clip;
      r -= m.weight;
    }
    return micro[micro.length - 1]!.clip;
  }

  // ---- Clip cursor -------------------------------------------------------
  private startClip(clipIndex: number): void {
    this.clipIndex = clipIndex;
    this.clipStep = 0;
    this.clipTicksLeft = this.pack.clips[clipIndex]!.steps[0]!.durationTicks;
  }

  /** Advance the clip one tick; returns true when a ONCE clip has finished. */
  private advanceClip(): boolean {
    const clip = this.pack.clips[this.clipIndex]!;
    this.clipTicksLeft--;
    if (this.clipTicksLeft > 0) return false;
    if (this.clipStep + 1 < clip.steps.length) {
      this.clipStep++;
      this.clipTicksLeft = clip.steps[this.clipStep]!.durationTicks;
      return false;
    }
    switch (clip.loopMode) {
      case LOOP_LOOP:
        this.clipStep = 0;
        this.clipTicksLeft = clip.steps[0]!.durationTicks;
        return false;
      case LOOP_HOLD_LAST:
        this.clipTicksLeft = clip.steps[this.clipStep]!.durationTicks;
        return false;
      default:
        // LOOP_ONCE: freeze on the last step; the director transitions away.
        this.clipTicksLeft = 0;
        return true;
    }
  }

  private clipFinished(): boolean {
    return this.clipTicksLeft <= 0;
  }

  // ---- Role helpers ------------------------------------------------------
  private roleClipOrNeutral(role: number): number {
    const clip = this.pack.roles[role]!;
    return clip === ROLE_ABSENT ? this.pack.roles[ROLE_IDLE_NEUTRAL]! : clip;
  }

  private sysRoleClip(): number {
    switch (this.sysState) {
      case SysState.OFFLINE:
        return this.roleClipOrNeutral(3); // ROLE_OFFLINE
      case SysState.ERROR:
        return this.roleClipOrNeutral(4); // ROLE_ERROR
      default:
        return this.roleClipOrNeutral(2); // ROLE_BOOTING (booting/provisioning/connecting)
    }
  }

  private attendRoleClip(): number {
    return this.sysState === SysState.THINKING
      ? this.roleClipOrNeutral(6) // ROLE_THINKING_BASE
      : this.roleClipOrNeutral(5); // ROLE_LISTENING_BASE
  }

  private findEmotion(id: number): number {
    for (let i = 0; i < this.pack.emotions.length; i++) {
      if (this.pack.emotions[i]!.id === id) return i;
    }
    return -1;
  }

  // ---- Phase entries -----------------------------------------------------
  private enterSysStatic(): void {
    this.phase = Phase.SYS_STATIC;
    this.currentEmotion = 0;
    this.clearRequested = false;
    this.shownSysState = this.sysState;
    this.startClip(this.sysRoleClip());
  }

  private enterIdle(withSettle: boolean): void {
    this.phase = Phase.IDLE;
    this.currentEmotion = 0;
    this.clearRequested = false;
    this.settleTicksLeft = withSettle ? SETTLE_TICKS : 0;
    this.startClip(this.pack.roles[ROLE_IDLE_NEUTRAL]!);
    this.drawMicroCountdown();
    this.showcaseCountdown = SHOWCASE_GAP_TICKS;
  }

  private enterAttend(): void {
    this.phase = Phase.ATTEND;
    this.currentEmotion = 0;
    this.clearRequested = false;
    this.shownSysState = this.sysState;
    this.startClip(this.attendRoleClip());
  }

  private enterTalk(): void {
    this.phase = Phase.TALK;
    this.currentEmotion = 0;
    this.clearRequested = false;
    this.talkStage = this.pack.talk.levelToStage[this.audioLevel]!;
    this.talkDwellTicksLeft = TALK_STAGE_MIN_DWELL_TICKS;
    this.talkLowerStreak = 0;
    if (this.pack.speakingPoses) {
      this.speakingGesture = -1;
      this.speakingPose = 0;
      this.speakingStep = 0;
      this.speakingStepTicks = 0;
      this.speakingNeutralTicks = 0;
      this.speakingBreakTicks = this.drawSpeakingBreak();
      this.driftStarted = false;
      this.driftX = 0;
      this.driftY = 0;
    }
  }

  private enterEmotion(id: number): void {
    const index = this.findEmotion(id);
    // Callers verify the id; an unknown id would be a director bug.
    const emotion = this.pack.emotions[index]!;
    this.phase = Phase.EMO_ENTER;
    this.currentEmotion = id;
    this.clearRequested = false;
    this.holdMinTicksLeft = Math.max(1, Math.round(emotion.minHoldMs / this.pack.info.tickMs));
    this.holdMaxTicksLeft = Math.max(this.holdMinTicksLeft, Math.round(emotion.maxHoldMs / this.pack.info.tickMs));
    this.startClip(emotion.enterClip);
  }

  private enterShowcaseEmotion(id: number): void {
    this.enterEmotion(id);
    const span = SHOWCASE_MAX_HOLD_MS - SHOWCASE_MIN_HOLD_MS + 1;
    const holdMs = SHOWCASE_MIN_HOLD_MS + (this.nextRandom() % span);
    const holdTicks = Math.max(1, Math.round(holdMs / this.pack.info.tickMs));
    this.holdMinTicksLeft = holdTicks;
    this.holdMaxTicksLeft = holdTicks;
  }

  private beginEmotionExit(): void {
    const emotion = this.pack.emotions[this.findEmotion(this.currentEmotion)]!;
    this.phase = Phase.EMO_EXIT;
    this.startClip(emotion.exitClip);
  }

  private finishEmotionExit(): void {
    this.cooldownEmotion = this.currentEmotion;
    this.cooldownTicksLeft = EMOTION_COOLDOWN_TICKS;
    const pending = this.pendingEmotion;
    this.pendingEmotion = 0;
    if (pending !== 0 && pending !== this.cooldownEmotion && this.findEmotion(pending) >= 0) {
      this.enterEmotion(pending);
    } else {
      this.enterIdle(false);
    }
  }

  // ---- Input intake ------------------------------------------------------
  /** Consume the latched emotion request according to the current phase. */
  private consumeEmotionRequest(): void {
    const request = this.requestedEmotion;
    if (request === EMOTION_NONE) return;
    this.requestedEmotion = EMOTION_NONE;
    if (request === 0) {
      // Clear. Meaningful only while an emotion is active or queued.
      this.pendingEmotion = 0;
      if (this.phase === Phase.EMO_ENTER || this.phase === Phase.EMO_HOLD) this.clearRequested = true;
      return;
    }
    if (this.findEmotion(request) < 0) {
      // A release may omit this expression. Clear any previous expression
      // instead of leaving a stale pose on screen.
      this.pendingEmotion = 0;
      if (this.phase === Phase.EMO_ENTER || this.phase === Phase.EMO_HOLD) this.clearRequested = true;
      return;
    }
    switch (this.phase) {
      case Phase.IDLE:
      case Phase.MICRO:
        if (request === this.cooldownEmotion && this.cooldownTicksLeft > 0) return;
        this.pendingEmotion = request;
        break;
      case Phase.EMO_ENTER:
      case Phase.EMO_HOLD:
        if (request === this.currentEmotion) {
          // Refresh: extend the hold window.
          const emotion = this.pack.emotions[this.findEmotion(request)]!;
          this.holdMaxTicksLeft = Math.max(
            this.holdMaxTicksLeft,
            Math.max(1, Math.round(emotion.maxHoldMs / this.pack.info.tickMs)),
          );
          this.clearRequested = false;
        } else {
          this.pendingEmotion = request;
        }
        break;
      case Phase.EMO_EXIT:
      case Phase.TALK:
      case Phase.ATTEND:
      case Phase.SYS_STATIC:
        this.pendingEmotion = request;
        break;
    }
  }

  // ---- Main tick ---------------------------------------------------------
  tick(): void {
    this.bobTick++;
    // Wrap at the bob period (identical in C) so the counter can never
    // overflow int32 on device; the offset math only uses bobTick % period.
    const bobPeriod = this.pack.idle.bobPeriodTicks;
    if (bobPeriod > 0 && this.bobTick >= bobPeriod) this.bobTick = 0;
    if (this.cooldownTicksLeft > 0) this.cooldownTicksLeft--;
    this.consumeEmotionRequest();
    this.updateFacialRegions();
    this.tickCalm();

    // Highest-priority claim by system state.
    const wantsSys =
      this.sysState === SysState.BOOTING ||
      this.sysState === SysState.PROVISIONING ||
      this.sysState === SysState.CONNECTING ||
      this.sysState === SysState.OFFLINE ||
      this.sysState === SysState.ERROR;
    const wantsTalk = this.sysState === SysState.SPEAKING;
    const wantsAttend = this.sysState === SysState.LISTENING || this.sysState === SysState.THINKING;

    if (wantsSys) {
      if (this.phase !== Phase.SYS_STATIC || this.shownSysState !== this.sysState) this.enterSysStatic();
      else this.advanceClip();
      this.render();
      return;
    }
    if (wantsTalk) {
      if (this.phase !== Phase.TALK) this.enterTalk();
      else this.tickTalk();
      this.render();
      return;
    }
    if (wantsAttend) {
      if (this.phase !== Phase.ATTEND || this.shownSysState !== this.sysState) this.enterAttend();
      else this.advanceClip();
      this.render();
      return;
    }

    if (this.idleMode === IdleMode.HOLD) {
      if (this.phase !== Phase.IDLE) this.enterIdle(false);
      else this.advanceClip();
      this.render();
      return;
    }

    // sysState == IDLE: the idle/emotion family owns the frame.
    switch (this.phase) {
      case Phase.SYS_STATIC:
      case Phase.TALK:
      case Phase.ATTEND:
        this.enterIdle(this.phase === Phase.SYS_STATIC);
        break;
      case Phase.IDLE:
        this.tickIdle();
        break;
      case Phase.MICRO:
        if (this.pendingEmotion !== 0) {
          // Micros are neutral-adjacent; abort straight into the emotion.
          const pending = this.pendingEmotion;
          this.pendingEmotion = 0;
          this.enterEmotion(pending);
        } else if (this.advanceClip()) {
          this.enterIdle(false);
        }
        break;
      case Phase.EMO_ENTER:
        if (this.advanceClip()) {
          this.phase = Phase.EMO_HOLD;
          this.startClip(this.pack.emotions[this.findEmotion(this.currentEmotion)]!.holdClip);
        }
        break;
      case Phase.EMO_HOLD:
        this.tickEmotionHold();
        break;
      case Phase.EMO_EXIT:
        if (this.advanceClip()) this.finishEmotionExit();
        break;
    }
    this.render();
  }

  private tickIdle(): void {
    if (this.settleTicksLeft > 0) {
      this.settleTicksLeft--;
      this.advanceClip();
      return;
    }
    if (this.pendingEmotion !== 0) {
      const pending = this.pendingEmotion;
      this.pendingEmotion = 0;
      this.enterEmotion(pending);
      return;
    }
    const emotionCount = this.pack.emotions.length;
    const performanceCount = this.pack.idle.micro.length;
    const showcaseCount = emotionCount + performanceCount;
    if (showcaseCount > 0 && this.idleMode === IdleMode.SHOWCASE) {
      if (this.showcaseCountdown > 0) this.showcaseCountdown--;
      if (this.showcaseCountdown === 0) {
        const slot = this.showcaseIndex % showcaseCount;
        const paired = Math.min(emotionCount, performanceCount) * 2;
        let useEmotion: boolean;
        let index: number;
        if (slot < paired) {
          useEmotion = (slot & 1) === 0;
          index = Math.floor(slot / 2);
        } else {
          const tail = slot - paired;
          useEmotion = emotionCount > performanceCount;
          index = paired / 2 + tail;
        }
        this.showcaseIndex = (slot + 1) % showcaseCount;
        if (useEmotion) {
          this.enterShowcaseEmotion(this.pack.emotions[index]!.id);
        } else {
          this.phase = Phase.MICRO;
          this.startClip(this.pack.idle.micro[index]!.clip);
        }
        return;
      }
      this.advanceClip();
      return;
    }
    if (this.microCountdown > 0) {
      this.microCountdown--;
      if (this.microCountdown === 0) {
        this.phase = Phase.MICRO;
        this.startClip(this.drawMicroClip());
        return;
      }
    }
    this.advanceClip();
  }

  /** A manual action requestAction would accept now. */
  private manualReady(index: number): boolean {
    return this.pack.actions[index]!.activationKind === "manual" && this.actionCooldownTicks[index]! <= 0 &&
      this.baseActionAllowed(index) && this.actionContextMatches(index, false);
  }

  /** One that calm may start: ready now, and over when its clip ends. */
  private calmCandidate(index: number): boolean {
    return this.manualReady(index) && this.pack.clips[this.pack.actions[index]!.clip]!.loopMode === LOOP_ONCE;
  }

  /** IdleMode.NATURAL: a stretch of calm ends with one of the pack's manual
   * actions that plays once. Calm is the idle family outside the reduced
   * profile, with no input, emotion or request, and nothing but an ambient loop
   * on the base plane. While none is ready (a cooldown, a moment of degraded
   * rendering) the calm pauses. The countdown is drawn when calm begins with
   * one ready, so no other mode or pack draws from the PRNG here. Mirrors
   * fp_actions_calm(). */
  private tickCalm(): void {
    const base = this.actionCursors[0];
    const calm = this.idleMode === IdleMode.NATURAL && this.sysState === SysState.IDLE &&
      this.animationProfile !== AnimationProfile.REDUCED &&
      (this.phase === Phase.IDLE || this.phase === Phase.MICRO) && !this.tapPending && !this.shakePending &&
      this.gesturePending === null && this.pendingEmotion === 0 && this.requestedAction < 0 &&
      (!base || this.pack.actions[base.action]!.activationKind === "ambient-loop");
    if (!calm) {
      this.calmCountdown = -1;
      return;
    }
    let ready = 0;
    for (let i = 0; i < this.pack.actions.length; i++) if (this.calmCandidate(i)) ready++;
    if (ready === 0) return;
    if (this.calmCountdown < 0) {
      this.calmCountdown = CALM_MIN_TICKS + (this.nextRandom() % (CALM_MAX_TICKS - CALM_MIN_TICKS + 1));
      return;
    }
    if (--this.calmCountdown > 0) return;
    let pick = this.nextRandom() % ready;
    for (let i = 0; i < this.pack.actions.length; i++) {
      if (this.calmCandidate(i) && pick-- === 0) {
        this.requestedAction = i;
        break;
      }
    }
    this.calmCountdown = -1;
  }

  private tickEmotionHold(): void {
    if (this.holdMinTicksLeft > 0) this.holdMinTicksLeft--;
    if (this.holdMaxTicksLeft > 0) this.holdMaxTicksLeft--;
    const wantsOut = this.clearRequested || this.pendingEmotion !== 0 || this.holdMaxTicksLeft === 0;
    if (wantsOut && this.holdMinTicksLeft === 0) {
      this.beginEmotionExit();
      return;
    }
    this.advanceClip();
  }

  private tickTalk(): void {
    const raw = this.pack.talk.levelToStage[this.audioLevel]!;
    if (this.talkDwellTicksLeft > 0) this.talkDwellTicksLeft--;
    if (raw > this.talkStage) {
      this.talkStage = raw;
      this.talkDwellTicksLeft = TALK_STAGE_MIN_DWELL_TICKS;
      this.talkLowerStreak = 0;
    } else if (raw < this.talkStage) {
      this.talkLowerStreak++;
      if (this.talkDwellTicksLeft === 0 && this.talkLowerStreak >= TALK_LOWER_STREAK_TICKS) {
        this.talkStage = raw;
        this.talkDwellTicksLeft = TALK_STAGE_MIN_DWELL_TICKS;
        this.talkLowerStreak = 0;
      }
    } else {
      this.talkLowerStreak = 0;
    }
    if (this.pack.speakingPoses) {
      // A base action owns the frame; the speaking gestures wait for it.
      const held = this.actionCursors[0] !== null;
      if (!held) this.tickSpeakingGesture(raw);
      this.tickDrift(held);
    }
  }

  // ---- Speaking poses (mirrors frame_director.c) --------------------------
  private drawSpeakingBreak(): number {
    const { breakMinTicks, breakMaxTicks } = this.pack.speakingPoses!;
    return breakMinTicks + (this.nextRandom() % (breakMaxTicks - breakMinTicks + 1));
  }

  /** Shuffled rotation of the automatic gestures, never the same one twice in a row. */
  private chooseSpeakingGesture(): number {
    const gestures = this.pack.speakingPoses!.gestures;
    const bag = this.speakingBag;
    if (bag.length === 0) {
      for (let g = 0; g < gestures.length; g++) if (gestures[g]!.automatic) bag.push(g);
      for (let i = bag.length - 1; i > 0; i--) {
        const j = this.nextRandom() % (i + 1);
        const swap = bag[i]!;
        bag[i] = bag[j]!;
        bag[j] = swap;
      }
      const last = bag.length - 1;
      if (last > 0 && bag[last] === this.speakingLastGesture) {
        bag[last] = bag[0]!;
        bag[0] = this.speakingLastGesture;
      }
    }
    const gesture = bag.pop()!;
    this.speakingLastGesture = gesture;
    return gesture;
  }

  /** Gestures start only while speech is audible, after a full neutral break. */
  private tickSpeakingGesture(raw: number): void {
    const gestures = this.pack.speakingPoses!.gestures;
    if (this.animationProfile === AnimationProfile.REDUCED) {
      if (this.speakingGesture >= 0) {
        this.speakingGesture = -1;
        this.speakingPose = 0;
        this.speakingNeutralTicks = 0;
      }
      return;
    }
    if (this.speakingGesture >= 0) {
      if (--this.speakingStepTicks > 0) return;
      const steps = gestures[this.speakingGesture]!.steps;
      if (++this.speakingStep >= steps.length) {
        this.speakingGesture = -1;
        this.speakingPose = 0;
        this.speakingNeutralTicks = 0;
        this.speakingBreakTicks = this.drawSpeakingBreak();
        return;
      }
      this.speakingPose = steps[this.speakingStep]!.pose;
      this.speakingStepTicks = steps[this.speakingStep]!.ticks;
      return;
    }
    if (this.speakingNeutralTicks < this.speakingBreakTicks) this.speakingNeutralTicks++;
    if (this.speakingNeutralTicks < this.speakingBreakTicks || raw === 0) return;
    const gesture = this.chooseSpeakingGesture();
    const first = gestures[gesture]!.steps[0]!;
    this.speakingGesture = gesture;
    this.speakingStep = 0;
    this.speakingPose = first.pose;
    this.speakingStepTicks = first.ticks;
    this.speakingNeutralTicks = 0;
  }

  private pickDriftTarget(): void {
    this.driftFromX = this.driftX;
    this.driftFromY = this.driftY;
    const span = SPEAKING_DRIFT_PX * 2 + 1;
    let toX = (this.nextRandom() % span) - SPEAKING_DRIFT_PX;
    const toY = (this.nextRandom() % span) - SPEAKING_DRIFT_PX;
    if (toX === this.driftFromX && toY === this.driftFromY) toX = toX === SPEAKING_DRIFT_PX ? toX - 1 : toX + 1;
    this.driftToX = toX;
    this.driftToY = toY;
    this.driftDuration = SPEAKING_DRIFT_MIN_TICKS + (this.nextRandom() % (SPEAKING_DRIFT_MAX_TICKS - SPEAKING_DRIFT_MIN_TICKS + 1));
    this.driftElapsed = 0;
  }

  /** Whole-pixel smoothstep toward a new target every 3-6 s. */
  private tickDrift(held: boolean): void {
    if (!this.speakingDriftEnabled || this.animationProfile === AnimationProfile.REDUCED || held) {
      this.driftStarted = false;
      this.driftX = 0;
      this.driftY = 0;
      return;
    }
    if (!this.driftStarted) {
      this.driftStarted = true;
      this.pickDriftTarget();
    }
    this.driftElapsed++;
    const t = Math.floor((this.driftElapsed * 1024) / this.driftDuration); // Q10, 0..1024
    const ease = (t * t * (3072 - 2 * t)) >> 20; // t^2 (3 - 2t), Q10
    this.driftX = Math.floor((this.driftFromX * 1024 + (this.driftToX - this.driftFromX) * ease + 512) / 1024);
    this.driftY = Math.floor((this.driftFromY * 1024 + (this.driftToY - this.driftFromY) * ease + 512) / 1024);
    if (this.driftElapsed >= this.driftDuration) this.pickDriftTarget();
  }

  private speakingMotion(): boolean {
    return !!this.pack.speakingPoses && this.phase === Phase.TALK && !this.actionCursors[0];
  }

  // ---- Data-driven effect and gesture actions ---------------------------
  private currentExpressionBit(): number {
    return this.currentEmotion === 0 ? 1 : 1 << this.currentEmotion;
  }

  private currentProfileBit(): number {
    return 1 << (this.animationProfile + 1);
  }

  private currentPerformanceBit(): number {
    if (this.phase !== Phase.MICRO) return 0;
    const index = this.pack.idle.micro.findIndex((entry) => entry.clip === this.clipIndex);
    return index < 0 ? 0 : 1 << index;
  }

  private tiltSemantic(): string | null {
    const absX = Math.abs(this.tiltX);
    const absY = Math.abs(this.tiltY);
    if (Math.max(absX, absY) < 50) return null;
    if (absX >= absY) return this.tiltX < 0 ? "tilt-left" : "tilt-right";
    return this.tiltY < 0 ? "tilt-up" : "tilt-down";
  }

  private actionContextMatches(index: number, includeActivation: boolean): boolean {
    const action = this.pack.actions[index]!;
    if ((action.profileMask & this.currentProfileBit()) === 0) return false;
    if ((action.stateMask & (1 << this.sysState)) === 0) return false;
    if ((action.expressionMask & this.currentExpressionBit()) === 0) return false;
    if ((action.performanceMask ?? 0) !== 0 && ((action.performanceMask ?? 0) & this.currentPerformanceBit()) === 0) return false;
    if (
      this.optionalSuppressionTicks > 0 &&
      !action.essential &&
      action.semantic !== "touch" &&
      action.semantic !== "shake" && !action.semantic.startsWith("gesture-")
    ) return false;
    if (!includeActivation) return true;
    if(action.activationKind==="manual")return this.requestedAction===index;
    if (action.activationKind === "ambient-loop") return this.animationProfile !== AnimationProfile.REDUCED;
    if (action.activationKind === "ambient-event") {
      return this.animationProfile !== AnimationProfile.REDUCED && this.actionEventCountdown[index] === 0;
    }
    switch (action.semantic) {
      case "touch": return this.tapPending;
      case "shake": return this.shakePending;
      case "listening": return this.sysState === SysState.LISTENING;
      case "thinking": return this.sysState === SysState.THINKING;
      case "speaking": return this.sysState === SysState.SPEAKING;
      case "booting": return this.sysState === SysState.BOOTING;
      case "provisioning": return this.sysState === SysState.PROVISIONING;
      case "connecting": return this.sysState === SysState.CONNECTING;
      case "offline": return this.sysState === SysState.OFFLINE;
      case "error": return this.sysState === SysState.ERROR;
      case "gesture-nod":
      case "gesture-focus":
      case "gesture-heartbeat":
      case "gesture-bounce":
      case "gesture-wobble":
      case "gesture-pop": return this.gesturePending === action.semantic;
      case "tilt-left":
      case "tilt-right":
      case "tilt-up":
      case "tilt-down": return this.tiltSemantic() === action.semantic && this.animationProfile !== AnimationProfile.REDUCED;
      default: return false;
    }
  }

  private baseActionAllowed(index: number): boolean {
    const action = this.pack.actions[index]!;
    if (action.plane !== "base") return true;
    if (this.sysState === SysState.BOOTING) return action.semantic === "booting";
    if (this.sysState === SysState.PROVISIONING) return action.semantic === "provisioning";
    if (this.sysState === SysState.CONNECTING) return action.semantic === "connecting";
    if (this.sysState === SysState.OFFLINE) return action.semantic === "offline";
    if (this.sysState === SysState.ERROR) return action.semantic === "error";
    if (this.sysState === SysState.SPEAKING) return false;
    if (this.sysState === SysState.LISTENING) return action.semantic === "listening";
    if (this.sysState === SysState.THINKING) return action.semantic === "thinking";
    return true;
  }

  private drawActionCountdown(index: number): void {
    const action = this.pack.actions[index]!;
    const span = action.intervalMaxTicks - action.intervalMinTicks + 1;
    this.actionEventCountdown[index] = action.intervalMinTicks + (this.nextRandom() % Math.max(1, span));
  }

  private actionScheduleMatches(index: number): boolean {
    const action = this.pack.actions[index]!;
    if ((action.profileMask & this.currentProfileBit()) === 0) return false;
    if ((action.stateMask & (1 << this.sysState)) === 0) return false;
    if (this.optionalSuppressionTicks > 0 && !action.essential) return false;
    return this.baseActionAllowed(index);
  }

  private updateActionSchedules(): void {
    for (let i = 0; i < this.pack.actions.length; i++) {
      const action = this.pack.actions[i]!;
      if (action.activationKind !== "ambient-event") continue;
      // The interval belongs to the action's state/profile context, not to a
      // fleeting facial expression. Count through expression performances and
      // let selection wait at zero until the allowed expression returns.
      const eligible = this.actionScheduleMatches(i);
      if (!eligible) {
        this.actionWasEligible[i] = false;
        this.actionEventCountdown[i] = -1;
        continue;
      }
      if (!this.actionWasEligible[i]) {
        this.actionWasEligible[i] = true;
        this.drawActionCountdown(i);
      } else if (this.actionEventCountdown[i]! > 0) {
        this.actionEventCountdown[i] = this.actionEventCountdown[i]! - 1;
      }
    }
  }

  /** IdleMode.NATURAL: an ambient loop that another action or a state
   * interrupts keeps the step and ticks it would have shown next, and resumes
   * there when it returns, so a long idle loop plays every moment. A loop
   * bound to an idle performance starts with its performance. Mirrors
   * fp_keep_loop(). */
  private keepLoop(cursor: ActionCursor): void {
    const action = this.pack.actions[cursor.action]!;
    if (this.idleMode !== IdleMode.NATURAL || action.activationKind !== "ambient-loop" ||
        (action.performanceMask ?? 0) !== 0 || cursor.entering) return;
    this.loopResumeStep[cursor.action] = cursor.step;
    this.loopResumeTicks[cursor.action] = cursor.ticksLeft;
  }

  /** The main clip continues where keepLoop left it, once. */
  private resumeLoop(cursor: ActionCursor): void {
    const ticks = this.loopResumeTicks[cursor.action]!;
    if (ticks <= 0) return;
    cursor.step = this.loopResumeStep[cursor.action]!;
    cursor.ticksLeft = ticks;
    this.loopResumeTicks[cursor.action] = 0;
  }

  private startAction(index: number): ActionCursor {
    const action = this.pack.actions[index]!;
    const enterClip = action.enterClip ?? ACTION_NO_CLIP;
    const clipIndex = enterClip !== ACTION_NO_CLIP ? enterClip : action.clip;
    const clip = this.pack.clips[clipIndex]!;
    const cursor: ActionCursor = {
      action: index,
      clip: clipIndex,
      step: 0,
      ticksLeft: clip.steps[0]!.durationTicks,
      entering: enterClip !== ACTION_NO_CLIP,
      exiting: false,
      complete: false,
    };
    if (action.activationKind === "ambient-event") this.actionEventCountdown[index] = -2;
    this.actionCooldownTicks[index] = action.cooldownTicks;
    if (!cursor.entering) this.resumeLoop(cursor);
    return cursor;
  }

  private advanceAction(cursor: ActionCursor): void {
    if (cursor.complete) return;
    const clip = this.pack.clips[cursor.clip]!;
    cursor.ticksLeft--;
    if (cursor.ticksLeft > 0) return;
    if (cursor.step + 1 < clip.steps.length) {
      cursor.step++;
      cursor.ticksLeft = clip.steps[cursor.step]!.durationTicks;
      return;
    }
    const action = this.pack.actions[cursor.action]!;
    const loopMode = !cursor.entering && !cursor.exiting && isTriggeredOneShot(action) ? LOOP_ONCE : clip.loopMode;
    if (loopMode === LOOP_LOOP) {
      cursor.step = 0;
      cursor.ticksLeft = clip.steps[0]!.durationTicks;
      return;
    }
    if (loopMode === LOOP_HOLD_LAST) {
      cursor.ticksLeft = clip.steps[cursor.step]!.durationTicks;
      return;
    }
    if (cursor.entering) {
      cursor.clip = action.clip;
      cursor.step = 0;
      cursor.ticksLeft = this.pack.clips[action.clip]!.steps[0]!.durationTicks;
      cursor.entering = false;
      cursor.complete = false;
      this.resumeLoop(cursor);
      return;
    }
    cursor.complete = true;
  }

  private beginActionExit(cursor: ActionCursor): boolean {
    const action = this.pack.actions[cursor.action]!;
    if (!cursor.exiting && action.exitClip !== ACTION_NO_CLIP) {
      cursor.clip = action.exitClip;
      cursor.step = 0;
      cursor.ticksLeft = this.pack.clips[action.exitClip]!.steps[0]!.durationTicks;
      cursor.exiting = true;
      cursor.entering = false;
      cursor.complete = false;
      return true;
    }
    return false;
  }

  private actionContinuationMatches(index: number): boolean {
    const action = this.pack.actions[index]!;
    if(action.activationKind==="manual")return this.baseActionAllowed(index)&&this.actionContextMatches(index,true);
    const oneShot = action.activationKind === "ambient-event" || action.semantic === "touch" ||
      action.semantic === "shake" || action.semantic.startsWith("gesture-");
    return this.baseActionAllowed(index) && this.actionContextMatches(index, !oneShot);
  }

  private selectActionForPlane(plane: number): number {
    let best = -1;
    let priority = -1;
    for (let i = 0; i < this.pack.actions.length; i++) {
      const action = this.pack.actions[i]!;
      const actionPlane = action.plane === "base" ? 0 : action.plane === "characterFx" ? 1 : action.plane === "stateFx" ? 2 : action.plane === "gestureFx" ? 3 : 4;
      if (actionPlane !== plane || this.actionCooldownTicks[i]! > 0 || !this.baseActionAllowed(i) || !this.actionContextMatches(i, true)) continue;
      if (action.priority > priority) {
        best = i;
        priority = action.priority;
      }
    }
    // A requested manual action outranks an ambient loop: the loop is what the
    // pet does when nothing is requested. Its own cooldown, set when it
    // started, does not count while it runs. This reads the cursor as of the
    // start of the tick, where C reads it as updated this tick; they agree
    // because an action that ends always clears its own request first.
    const r = this.requestedAction;
    if (r >= 0 && best >= 0 && best !== r && this.pack.actions[best]!.activationKind === "ambient-loop" &&
        this.planeIndex(r) === plane && (this.actionCooldownTicks[r]! <= 0 || this.actionCursors[plane]?.action === r) &&
        this.baseActionAllowed(r) && this.actionContextMatches(r, true)) best = r;
    return best;
  }

  private planeIndex(index: number): number {
    const plane = this.pack.actions[index]!.plane;
    return plane === "base" ? 0 : plane === "characterFx" ? 1 : plane === "stateFx" ? 2 : plane === "gestureFx" ? 3 : 4;
  }

  private updateActions(): void {
    if(this.requestedAction>=0&&(!this.baseActionAllowed(this.requestedAction)||!this.actionContextMatches(this.requestedAction,false)))this.requestedAction=-1;
    if (this.optionalSuppressionTicks > 0) this.optionalSuppressionTicks--;
    if (this.tapPending) this.fallbackTouchTicks = 8;
    else if (this.fallbackTouchTicks > 0) this.fallbackTouchTicks--;
    if (this.shakePending) this.fallbackShakeTicks = 12;
    else if (this.fallbackShakeTicks > 0) this.fallbackShakeTicks--;
    this.updateActionSchedules();
    for (let i = 0; i < this.actionCooldownTicks.length; i++) {
      if (this.actionCooldownTicks[i]! > 0) this.actionCooldownTicks[i] = this.actionCooldownTicks[i]! - 1;
    }
    for (let plane = 0; plane < this.actionCursors.length; plane++) {
      let cursor = this.actionCursors[plane] ?? null;
      if (cursor) {
        this.advanceAction(cursor);
        const action = this.pack.actions[cursor.action]!;
        if (cursor.complete) {
          if(this.requestedAction===cursor.action)this.requestedAction=-1;
          if (action.activationKind === "ambient-event") this.drawActionCountdown(cursor.action);
          cursor = null;
        } else if (!cursor.exiting && !this.actionContinuationMatches(cursor.action)) {
          this.keepLoop(cursor);
          if (!this.beginActionExit(cursor)) cursor = null;
        }
      }
      const selected = this.selectActionForPlane(plane);
      if (!cursor?.exiting && selected >= 0 && (!cursor || selected !== cursor.action)) {
        const selectedPriority = this.pack.actions[selected]!.priority;
        const currentPriority = cursor ? this.pack.actions[cursor.action]!.priority : -1;
        if (!cursor || selectedPriority >= currentPriority ||
            (selected === this.requestedAction && this.pack.actions[cursor.action]!.activationKind === "ambient-loop")) {
          if (cursor && this.pack.actions[cursor.action]!.activationKind === "ambient-event") {
            this.drawActionCountdown(cursor.action);
          }
          if(cursor&&this.requestedAction===cursor.action)this.requestedAction=-1;
          if (cursor) this.keepLoop(cursor);
          cursor = this.startAction(selected);
        }
      }
      this.actionCursors[plane] = cursor;
      if(plane===0&&this.requestedAction>=0&&cursor?.action!==this.requestedAction)this.requestedAction=-1;
    }
    // A tick whose profile turns a loop off also forgets where it stopped.
    for (let i = 0; i < this.loopResumeTicks.length; i++) {
      if ((this.pack.actions[i]!.profileMask & this.currentProfileBit()) === 0 || this.animationProfile === AnimationProfile.REDUCED) this.loopResumeTicks[i] = 0;
    }
    this.tapPending = false;
    this.shakePending = false;
    this.gesturePending = null;
  }

  // ---- Rendering ---------------------------------------------------------
  private currentFrame(): number {
    const baseAction = this.actionCursors[0];
    if (baseAction) return this.pack.clips[baseAction.clip]!.steps[baseAction.step]!.frame;
    if (this.phase === Phase.TALK) {
      const speaking = this.pack.speakingPoses;
      return speaking ? speaking.frames[this.speakingPose]![this.talkStage]! : this.pack.talk.stageFrames[this.talkStage]!;
    }
    const clip = this.pack.clips[this.clipIndex]!;
    return clip.steps[this.clipStep]!.frame;
  }

  private currentOffsetY(): number {
    if (this.speakingMotion()) return this.driftY;
    const parallax = this.parallaxOffsetY();
    if (this.actionCursors[0]) return parallax;
    const { bobAmplitudePx, bobPeriodTicks } = this.pack.idle;
    if (bobAmplitudePx === 0 || bobPeriodTicks === 0) return parallax;
    // An authored bob continues while the pet talks (mirrors frame_director.c).
    if (this.phase !== Phase.IDLE && this.phase !== Phase.EMO_HOLD && this.phase !== Phase.ATTEND &&
        this.phase !== Phase.TALK) return parallax;
    const phase = this.bobTick % bobPeriodTicks;
    return parallax + (phase * 2 >= bobPeriodTicks ? bobAmplitudePx : 0);
  }

  private facialCompatible(): boolean {
    return !!this.pack.facialRegions && !this.actionCursors[0] && (this.phase===Phase.IDLE||this.phase===Phase.TALK||this.phase===Phase.ATTEND);
  }

  private randomRange(min:number,max:number):number { return min + (this.nextRandom()%Math.max(1,max-min+1)); }

  private updateFacialRegions(): void {
    const facial=this.pack.facialRegions; if(!facial)return;
    const stateBit=1<<this.sysState;
    if(!this.facialCompatible()) { this.facialGroup=facial.centerGroup;this.facialBlinkStage=0;if(facial.independentBlink){this.facialBlinkTicks=0;this.facialPoseTicks=facial.gazeStageTicks![0]!;}this.facialPosePhase=0;return; }
    if((facial.blinkStateMask&stateBit)!==0){
      if(this.facialBlinkTicks>0){if(--this.facialBlinkTicks===0){this.facialBlinkStage++;if(this.facialBlinkStage>=5){this.facialBlinkStage=0;const o=this.animationProfile*2;this.facialBlinkCountdown=this.randomRange(facial.blinkGaps[o]!,facial.blinkGaps[o+1]!);}else this.facialBlinkTicks=facial.blinkStageTicks[this.facialBlinkStage]!;}}
      else if(--this.facialBlinkCountdown<=0){this.facialBlinkStage=facial.independentBlink?0:1;this.facialBlinkTicks=facial.blinkStageTicks[this.facialBlinkStage]!;}
    } else {this.facialBlinkStage=0;if(facial.independentBlink)this.facialBlinkTicks=0;}
    const centerOnly=this.actionCursors[1] && this.pack.actions[this.actionCursors[1]!.action]!.posePolicy==="center-only";
    if(centerOnly||this.animationProfile===AnimationProfile.REDUCED||(facial.poseStateMask&stateBit)===0){this.facialGroup=facial.centerGroup;this.facialPosePhase=0;if(facial.independentBlink)this.facialPoseTicks=facial.gazeStageTicks![0]!;return;}
    if(facial.independentBlink){
      const ticks=facial.gazeStageTicks!,ax=Math.abs(this.tiltX),ay=Math.abs(this.tiltY);
      if(ax>=50||ay>=50){const role=ax>=ay?(this.tiltX<0?1:3):(this.tiltY<0?2:4);
        this.facialGroup=facial.groups.findIndex(g=>g.role===role);this.facialPosePhase=role;this.facialPoseTicks=ticks[role]!;return;}
      if(--this.facialPoseTicks>0)return;
      this.facialPosePhase=(this.facialPosePhase+1)%5;
      this.facialGroup=facial.groups.findIndex(g=>g.role===this.facialPosePhase);
      this.facialPoseTicks=ticks[this.facialPosePhase]!;return;
    }
    if(Math.abs(this.tiltX)>=50){this.facialGroup=this.tiltX<0?facial.groups.findIndex(g=>g.role===2):facial.groups.findIndex(g=>g.role===4);this.facialPosePhase=0;return;}
    if(--this.facialPoseTicks>0)return;
    const base=this.animationProfile===AnimationProfile.FULL?0:4;
    if(this.facialPosePhase===0){this.facialPoseSide=-this.facialPoseSide;this.facialPosePhase=1;this.facialGroup=facial.groups.findIndex(g=>g.role===(this.facialPoseSide<0?1:3));this.facialPoseTicks=5;}
    else if(this.facialPosePhase===1){this.facialPosePhase=2;this.facialGroup=facial.groups.findIndex(g=>g.role===(this.facialPoseSide<0?2:4));this.facialPoseTicks=this.randomRange(facial.poseTimings[base+2]!,facial.poseTimings[base+3]!);}
    else if(this.facialPosePhase===2){this.facialPosePhase=3;this.facialGroup=facial.groups.findIndex(g=>g.role===(this.facialPoseSide<0?1:3));this.facialPoseTicks=5;}
    else {this.facialPosePhase=0;this.facialGroup=facial.centerGroup;this.facialPoseTicks=this.randomRange(facial.poseTimings[base]!,facial.poseTimings[base+1]!);}
  }

  private facialOffsetY():number { const f=this.pack.facialRegions;if(!f||!this.facialCompatible()||this.animationProfile===AnimationProfile.REDUCED)return 0;const amp=this.animationProfile===AnimationProfile.FULL?f.bobFullAmplitude:f.bobBalancedAmplitude;if(!amp||!(f.bobStateMask&(1<<this.sysState)))return 0;const p=this.bobTick%f.bobPeriodTicks;return p*4<f.bobPeriodTicks||p*4>=f.bobPeriodTicks*3?0:amp; }

  private currentOffsetX(): number {
    if (this.speakingMotion()) return this.driftX;
    if (!this.pack.idle.parallaxSafe || this.animationProfile === AnimationProfile.REDUCED) return 0;
    const limit = this.pack.idle.maxParallaxPx ?? 0;
    if (limit === 0 || Math.abs(this.tiltX) < 15) return 0;
    return this.tiltX < 0 ? -limit : limit;
  }

  private parallaxOffsetY(): number {
    if (!this.pack.idle.parallaxSafe || this.animationProfile === AnimationProfile.REDUCED) return 0;
    const limit = this.pack.idle.maxParallaxPx ?? 0;
    if (limit === 0 || Math.abs(this.tiltY) < 15) return 0;
    return this.tiltY < 0 ? -limit : limit;
  }

  private applyMaskedFrame(frameIndex: number): void {
    const entry = this.pack.frames[frameIndex]!;
    if (!isMaskedCodec(entry.codec)) return;
    const data = this.pack.decodeFrame(frameIndex);
    const x0 = data[0]!;
    const y0 = data[1]!;
    const width = data[2]!;
    const height = data[3]!;
    const maskBytes = Math.ceil((width * height) / 8);
    let colorAt = 4 + maskBytes;
    for (let p = 0; p < width * height; p++) {
      if (((data[4 + (p >> 3)]! >> (p & 7)) & 1) === 0) continue;
      const x = x0 + (p % width);
      const y = y0 + Math.floor(p / width);
      this.framebuffer[y * this.pack.info.width + x] = this.pack.paletteRgb565[data[colorAt++]!]!;
    }
  }

  private applyDenseFrame(frameIndex:number,offsetX:number,offsetY:number):void { const entry=this.pack.frames[frameIndex]!;if(!isDenseCodec(entry.codec))return;const data=this.pack.decodeFrame(frameIndex),x0=data[0]!,y0=data[1]!,w=data[2]!,h=data[3]!;for(let p=0;p<w*h;p++){const x=x0+p%w+offsetX,y=y0+Math.floor(p/w)+offsetY;if(x>=0&&x<this.pack.info.width&&y>=0&&y<this.pack.info.width)this.framebuffer[y*this.pack.info.width+x]=this.pack.paletteRgb565[data[4+p]!]!;} }

  private activeCustomSemantic(semantic: string): boolean {
    return this.actionCursors.some((cursor) => cursor !== null && this.pack.actions[cursor.action]!.semantic === semantic);
  }

  private setFallbackPixel(x: number, y: number, color: number): void {
    if (x < 0 || x >= 120 || y < 0 || y >= 120) return;
    const scale = this.pack.info.width / 120;
    for (let dy = 0; dy < scale; dy++) for (let dx = 0; dx < scale; dx++) {
      this.framebuffer[(y * scale + dy) * this.pack.info.width + x * scale + dx] = color;
    }
  }

  private drawFallbackStar(cx: number, cy: number, color: number): void {
    this.setFallbackPixel(cx, cy, color);
    this.setFallbackPixel(cx - 1, cy, color);
    this.setFallbackPixel(cx + 1, cy, color);
    this.setFallbackPixel(cx, cy - 1, color);
    this.setFallbackPixel(cx, cy + 1, color);
    this.setFallbackPixel(cx - 2, cy, 0xffff);
    this.setFallbackPixel(cx + 2, cy, 0xffff);
    this.setFallbackPixel(cx, cy - 2, 0xffff);
    this.setFallbackPixel(cx, cy + 2, 0xffff);
  }

  private drawFallbacks(): void {
    if (!this.pack.idle.fallbacksEnabled) return;
    const phase = this.bobTick & 3;
    if (this.sysState === SysState.LISTENING && !this.activeCustomSemantic("listening")) {
      const radius = phase < 2 ? 3 : 4;
      for (let x = 60 - radius; x <= 60 + radius; x++) {
        this.setFallbackPixel(x, 8 - radius, 0x07ff);
        this.setFallbackPixel(x, 8 + radius, 0x07ff);
      }
      for (let y = 8 - radius; y <= 8 + radius; y++) {
        this.setFallbackPixel(60 - radius, y, 0x07ff);
        this.setFallbackPixel(60 + radius, y, 0x07ff);
      }
    }
    if (this.sysState === SysState.THINKING && !this.activeCustomSemantic("thinking")) {
      const active = this.bobTick % 3;
      for (let i = 0; i < 3; i++) {
        const color = i === active ? 0xffff : 0x8410;
        this.setFallbackPixel(54 + i * 6, 9, color);
        this.setFallbackPixel(55 + i * 6, 9, color);
        this.setFallbackPixel(54 + i * 6, 10, color);
        this.setFallbackPixel(55 + i * 6, 10, color);
      }
    }
    if (this.fallbackTouchTicks > 0 && !this.activeCustomSemantic("touch")) {
      const spread = 1 + ((8 - this.fallbackTouchTicks) >> 1);
      this.drawFallbackStar(27 - spread, 42 - spread, 0xffe0);
      this.drawFallbackStar(93 + spread, 39 - spread, 0xffe0);
      this.drawFallbackStar(82 + spread, 75 + spread, 0xf81f);
    }
    if (this.fallbackShakeTicks > 0 && !this.activeCustomSemantic("shake")) {
      const dx = (this.fallbackShakeTicks & 1) === 0 ? 2 : -2;
      this.drawFallbackStar(23 + dx, 32, 0xffe0);
      this.drawFallbackStar(97 - dx, 32, 0x07ff);
      this.setFallbackPixel(19 - dx, 56, 0xf81f);
      this.setFallbackPixel(101 + dx, 56, 0xf81f);
    }
  }

  private updateDirtyRect(): void {
    let minX = this.pack.info.width;
    let minY = this.pack.info.width;
    let maxX = -1;
    let maxY = -1;
    for (let y = 0; y < this.pack.info.width; y++) {
      for (let x = 0; x < this.pack.info.width; x++) {
        const p = y * this.pack.info.width + x;
        if (this.framebuffer[p] === this.previousFramebuffer[p]) continue;
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
        if (y < minY) minY = y;
        if (y > maxY) maxY = y;
      }
    }
    if (maxX < minX) {
      this.dirtyRect = null;
      return;
    }
    this.dirtyRect = { x: minX, y: minY, width: maxX - minX + 1, height: maxY - minY + 1 };
    this.visualRevision++;
  }

  private render(updateActions = true): void {
    if (updateActions) this.updateActions();
    this.previousFramebuffer.set(this.framebuffer);
    const facial=this.facialCompatible()?this.pack.facialRegions:undefined;
    const group=facial?.groups[this.facialGroup];
    const frame = this.pack.decodeFrame(group?.baseFrame ?? this.currentFrame());
    const palette = this.pack.paletteRgb565;
    const bg = palette[this.pack.info.bgPaletteIndex]!;
    const offsetX = this.currentOffsetX();
    const offsetY = facial ? this.facialOffsetY() : this.currentOffsetY();
    // Drifting speech frames sit on the unshifted frame, so the exposed edge
    // shows the character's own background instead of an empty strip.
    const underlay = this.speakingMotion() && (offsetX !== 0 || offsetY !== 0);
    const fb = this.framebuffer;
    const width = this.pack.info.width;
    for (let y = 0; y < width; y++) {
      const srcY = y - offsetY;
      const row = y * width;
      if (!underlay && (srcY < 0 || srcY >= width)) {
        fb.fill(bg, row, row + width);
        continue;
      }
      for (let x = 0; x < width; x++) {
        const srcX = x - offsetX;
        const inside = srcX >= 0 && srcX < width && srcY >= 0 && srcY < width;
        fb[row + x] = inside ? palette[frame[srcY * width + srcX]!]! : underlay ? palette[frame[row + x]!]! : bg;
      }
    }
    if(group){this.applyDenseFrame(group.mouthFrames[this.phase===Phase.TALK?this.talkStage:0]!,offsetX,offsetY);if(!this.pack.facialRegions!.independentBlink||this.facialBlinkTicks>0)this.applyDenseFrame(group.eyeFrames[this.facialBlinkStage]!,offsetX,offsetY);}
    for (let plane = 1; plane < this.actionCursors.length; plane++) {
      const cursor = this.actionCursors[plane];
      if (!cursor) continue;
      const frameIndex = this.pack.clips[cursor.clip]!.steps[cursor.step]!.frame;
      this.applyMaskedFrame(frameIndex);
    }
    this.drawFallbacks();
    this.updateDirtyRect();
  }
}
