// Minimal binding for the frame_player wasm build. Mirrors the packaging of
// One freestanding frame-player module with no host imports; the
// pack and the player arena are placed manually above __heap_base.

export interface WasmPlayerExports {
  fp_request_action(player:number,action:number):number;
  memory: WebAssembly.Memory;
  __heap_base: WebAssembly.Global;
  fp_validate(pack: number, bytes: number, info: number): number;
  fp_validation_workspace_size(): number;
  fp_validate_with_workspace(pack: number, bytes: number, info: number, workspace: number, workspaceBytes: number): number;
  fp_debug_base_decode_count(player: number): number;
  fp_arena_size(): number;
  fp_player_init(arena: number, arenaBytes: number, pack: number, packBytes: number, seed: number, error: number): number;
  fp_set_sys_state(player: number, state: number): void;
  fp_set_emotion(player: number, emotion: number): void;
  fp_set_audio_level(player: number, level: number): void;
  fp_set_animation_profile(player: number, profile: number): void;
  fp_set_idle_showcase_enabled(player: number, enabled: number): void;
  fp_set_idle_mode(player: number, mode: number): void;
  fp_set_tilt(player: number, x: number, y: number): void;
  fp_set_speaking_drift(player: number, enabled: number): void;
  fp_notify_tap(player: number): void;
  fp_notify_touch(player: number): void;
  fp_notify_shake(player: number): void;
  fp_notify_gesture(player: number, gesture: number): void;
  fp_report_health(player: number, audioHealthy: number, presentationMs: number): void;
  fp_tick(player: number): void;
  fp_framebuffer(player: number): number;
  fp_canvas_width(player: number): number;
  fp_canvas_height(player: number): number;
  fp_frame_crc32(player: number): number;
  fp_visual_revision(player: number): number;
  fp_debug_phase(player: number): number;
  fp_debug_frame(player: number): number;
  fp_debug_offset_y(player: number): number;
  fp_debug_offset_x(player: number): number;
  fp_debug_facial_group(player:number):number;
  fp_debug_mouth_stage(player:number):number;
  fp_debug_blink_stage(player:number):number;
  fp_debug_speaking_pose(player: number): number;
  fp_debug_speaking_gesture(player: number): number;
  fp_debug_compose_facial(player:number,group:number,mouth:number,blink:number,bob:number):void;
  fp_active_action(player: number, plane: number): number;
  fp_debug_dirty_x(player: number): number;
  fp_debug_dirty_y(player: number): number;
  fp_debug_dirty_width(player: number): number;
  fp_debug_dirty_height(player: number): number;
}

export class WasmFramePlayer {
  private constructor(
    private readonly exports: WasmPlayerExports,
    private readonly playerPtr: number,
  ) {}

  static create(wasmBytes: Uint8Array, pack: Uint8Array, seed: number): WasmFramePlayer {
    const module = new WebAssembly.Module(wasmBytes as BufferSource);
    const instance = new WebAssembly.Instance(module, {});
    const exports = instance.exports as unknown as WasmPlayerExports;
    const heapBase = Number(exports.__heap_base.value);
    const align16 = (n: number): number => (n + 15) & ~15;
    const packPtr = align16(heapBase);
    const arenaPtr = align16(packPtr + pack.length);
    const arenaBytes = exports.fp_arena_size();
    const errorPtr = align16(arenaPtr + arenaBytes);
    WasmFramePlayer.ensureMemory(exports, errorPtr + 4);
    const memory = new Uint8Array(exports.memory.buffer);
    memory.set(pack, packPtr);
    const playerPtr = exports.fp_player_init(arenaPtr, arenaBytes, packPtr, pack.length, seed >>> 0, errorPtr);
    if (playerPtr === 0) {
      const errorCode = new DataView(exports.memory.buffer).getInt32(errorPtr, true);
      throw new Error(`fp_player_init failed with error ${errorCode}`);
    }
    return new WasmFramePlayer(exports, playerPtr);
  }

  static validate(wasmBytes: Uint8Array, pack: Uint8Array): number {
    const module = new WebAssembly.Module(wasmBytes as BufferSource);
    const instance = new WebAssembly.Instance(module, {});
    const exports = instance.exports as unknown as WasmPlayerExports;
    const heapBase = Number(exports.__heap_base.value);
    const packPtr = (heapBase + 15) & ~15;
    const workspacePtr = (packPtr + pack.length + 15) & ~15;
    const workspaceBytes = exports.fp_validation_workspace_size();
    WasmFramePlayer.ensureMemory(exports, workspacePtr + workspaceBytes);
    new Uint8Array(exports.memory.buffer).set(pack, packPtr);
    return exports.fp_validate_with_workspace(packPtr, pack.length, 0, workspacePtr, workspaceBytes);
  }

  private static ensureMemory(exports: WasmPlayerExports, bytes: number): void {
    if (!Number.isSafeInteger(bytes) || bytes > 16 * 1024 * 1024) throw new Error("wasm memory limit exceeded");
    const missing = bytes - exports.memory.buffer.byteLength;
    if (missing > 0) exports.memory.grow(Math.ceil(missing / 65536));
  }

  dimensions(): { width: number; height: number } {
    return { width: this.exports.fp_canvas_width(this.playerPtr), height: this.exports.fp_canvas_height(this.playerPtr) };
  }

  baseDecodeCount(): number { return this.exports.fp_debug_base_decode_count(this.playerPtr); }

  setSysState(state: number): void {
    this.exports.fp_set_sys_state(this.playerPtr, state);
  }

  setEmotion(id: number): void {
    this.exports.fp_set_emotion(this.playerPtr, id);
  }

  setAudioLevel(level: number): void {
    this.exports.fp_set_audio_level(this.playerPtr, level);
  }

  notifyTap(): void {
    this.exports.fp_notify_tap(this.playerPtr);
  }

  notifyTouch(): void {
    this.exports.fp_notify_touch(this.playerPtr);
  }
  requestAction(index:number):boolean {
    if(!Number.isInteger(index)||index< -1||index>32767)return false;
    return this.exports.fp_request_action(this.playerPtr,index)!==0;
  }

  notifyShake(): void {
    this.exports.fp_notify_shake(this.playerPtr);
  }

  notifyGesture(gesture: number): void {
    this.exports.fp_notify_gesture(this.playerPtr, gesture);
  }

  setTilt(x: number, y: number): void {
    this.exports.fp_set_tilt(this.playerPtr, x, y);
  }

  setSpeakingDrift(enabled: boolean): void {
    this.exports.fp_set_speaking_drift(this.playerPtr, enabled ? 1 : 0);
  }

  setAnimationProfile(profile: number): void {
    this.exports.fp_set_animation_profile(this.playerPtr, profile);
  }

  setIdleShowcaseEnabled(enabled: boolean): void {
    this.exports.fp_set_idle_showcase_enabled(this.playerPtr, enabled ? 1 : 0);
  }

  setIdleMode(mode: number): void {
    this.exports.fp_set_idle_mode(this.playerPtr, mode);
  }

  reportHealth(audioHealthy: boolean, presentationMs: number): void {
    this.exports.fp_report_health(this.playerPtr, audioHealthy ? 1 : 0, presentationMs);
  }

  tick(): void {
    this.exports.fp_tick(this.playerPtr);
  }

  frameCrc32(): number {
    return this.exports.fp_frame_crc32(this.playerPtr) >>> 0;
  }

  visualRevision(): number {
    return this.exports.fp_visual_revision(this.playerPtr) >>> 0;
  }

  framebuffer(): Uint16Array {
    const ptr = this.exports.fp_framebuffer(this.playerPtr);
    const { width, height } = this.dimensions();
    return new Uint16Array(this.exports.memory.buffer, ptr, width * height);
  }

  debugPhase(): number {
    return this.exports.fp_debug_phase(this.playerPtr);
  }

  debugFrame(): number {
    return this.exports.fp_debug_frame(this.playerPtr);
  }

  debugOffsetY(): number {
    return this.exports.fp_debug_offset_y(this.playerPtr);
  }

  debugOffsetX(): number {
    return this.exports.fp_debug_offset_x(this.playerPtr);
  }
  debugFacialGroup():number{return this.exports.fp_debug_facial_group(this.playerPtr);}
  debugMouthStage():number{return this.exports.fp_debug_mouth_stage(this.playerPtr);}
  debugBlinkStage():number{return this.exports.fp_debug_blink_stage(this.playerPtr);}
  debugSpeakingPose(): number { return this.exports.fp_debug_speaking_pose(this.playerPtr); }
  debugSpeakingGesture(): number { return this.exports.fp_debug_speaking_gesture(this.playerPtr); }
  debugComposeFacial(group:number,mouth:number,blink:number,bob:number):void{this.exports.fp_debug_compose_facial(this.playerPtr,group,mouth,blink,bob);}

  activeAction(plane: number): number {
    return this.exports.fp_active_action(this.playerPtr, plane);
  }

  dirtyRect(): { x: number; y: number; width: number; height: number } {
    return {
      x: this.exports.fp_debug_dirty_x(this.playerPtr), y: this.exports.fp_debug_dirty_y(this.playerPtr),
      width: this.exports.fp_debug_dirty_width(this.playerPtr), height: this.exports.fp_debug_dirty_height(this.playerPtr),
    };
  }
}
