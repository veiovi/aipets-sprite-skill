// Browser-safe reference decoder. Actual device review uses the pinned C/WASM
// decoder; low-level pako is an independent validation/parity oracle. Never use
// an auto-growing or concatenated-stream convenience inflate API here.
import zlib from "pako/lib/zlib/inflate.js";
import ZStream from "pako/lib/zlib/zstream.js";
import {
  FRAME_CODEC_INDEX8_FULL, FRAME_CODEC_INDEX8_FULL_RLE,
  FRAME_CODEC_INDEX8_MASKED_RECT, FRAME_CODEC_INDEX8_MASKED_RECT_RLE,
  FRAME_CODEC_INDEX8_DENSE_RECT, FRAME_CODEC_INDEX8_FULL_ZLIB,
  FRAME_CODEC_INDEX8_MASKED_RECT_ZLIB, FRAME_CODEC_INDEX8_DENSE_RECT_ZLIB,
} from "./constants.js";

export function isFullCodec(codec: number): boolean {
  return codec === FRAME_CODEC_INDEX8_FULL || codec === FRAME_CODEC_INDEX8_FULL_RLE || codec === FRAME_CODEC_INDEX8_FULL_ZLIB;
}
export function isMaskedCodec(codec: number): boolean {
  return codec === FRAME_CODEC_INDEX8_MASKED_RECT || codec === FRAME_CODEC_INDEX8_MASKED_RECT_RLE || codec === FRAME_CODEC_INDEX8_MASKED_RECT_ZLIB;
}
export function isDenseCodec(codec: number): boolean {
  return codec === FRAME_CODEC_INDEX8_DENSE_RECT || codec === FRAME_CODEC_INDEX8_DENSE_RECT_ZLIB;
}
export function isZlibCodec(codec: number): boolean { return codec >= 5 && codec <= 7; }

export function inflateExact(data: Uint8Array, expected: number): Uint8Array {
  if (!Number.isInteger(expected) || expected < 1 || expected > 64800) throw new Error("invalid bounded inflate length");
  if (data.length > 65828) throw new Error("compressed frame input limit exceeded");
  if (data.length < 6 || (data[0]! & 15) !== 8 || (data[0]! >>> 4) > 7 ||
      (data[1]! & 32) !== 0 || ((data[0]! * 256 + data[1]!) % 31) !== 0) throw new Error("invalid zlib header");
  const stream = new ZStream();
  // pako bounds distance by the requested window, not header CINFO. Bind the
  // request to the already-validated header so a smaller window cannot lie.
  if (zlib.inflateInit2(stream, 8 + (data[0]! >>> 4)) !== 0) throw new Error("inflate initialization failed");
  try {
    stream.input = data; stream.next_in = 0; stream.avail_in = data.length;
    stream.output = new Uint8Array(expected); stream.next_out = 0; stream.avail_out = expected;
    const status = zlib.inflate(stream, 4); // Z_FINISH; one bounded call, no growth
    if (status !== 1 || stream.total_out !== expected || stream.avail_in !== 0) throw new Error("invalid zlib stream, decoded length or trailing data");
    return stream.output;
  } finally { zlib.inflateEnd(stream); }
}

/** Compressed rects leave geometry clear so bounds precede allocation/inflate.
 * Masked rect: x,y,w,h + u32 LE decoded(mask+indices) length + zlib payload.
 * Dense rect: x,y,w,h + zlib indices. Full: one zlib index stream. */
export function decodeZlibResource(codec: number, data: Uint8Array, canvas: number): Uint8Array {
  if (canvas !== 120 && canvas !== 240) throw new Error("invalid canvas");
  if (codec === FRAME_CODEC_INDEX8_FULL_ZLIB) return inflateExact(data, canvas * canvas);
  if (codec !== FRAME_CODEC_INDEX8_MASKED_RECT_ZLIB && codec !== FRAME_CODEC_INDEX8_DENSE_RECT_ZLIB) throw new Error("not a zlib codec");
  if (data.length < 10) throw new Error("truncated compressed rect");
  const x = data[0]!, y = data[1]!, w = data[2]!, h = data[3]!;
  if (!w || !h || x + w > canvas || y + h > canvas) throw new Error("invalid compressed rect bounds");
  let expected = w * h, at = 4;
  if (codec === FRAME_CODEC_INDEX8_MASKED_RECT_ZLIB) {
    expected = new DataView(data.buffer, data.byteOffset, data.byteLength).getUint32(4, true); at = 8;
    const maskBytes = Math.ceil(w * h / 8);
    if (expected < maskBytes || expected > maskBytes + w * h) throw new Error("invalid compressed mask length");
  }
  const result = new Uint8Array(4 + expected);
  result.set(data.subarray(0, 4)); result.set(inflateExact(data.subarray(at), expected), 4);
  return result;
}
