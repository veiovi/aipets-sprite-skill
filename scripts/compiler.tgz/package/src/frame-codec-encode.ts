import { deflate } from "pako";
import type { FrameResource } from "./binary.js";
import { FRAME_CODEC_INDEX8_FULL_ZLIB, FRAME_CODEC_INDEX8_MASKED_RECT_ZLIB, FRAME_CODEC_INDEX8_DENSE_RECT_ZLIB } from "./constants.js";

/** Independently wrapped streams from pinned, pure-JS pako. Node's bundled
 * zlib changes encoded bytes across runtimes even when decoded pixels match;
 * exact pack hashes must not depend on the build host's Node/zlib version.
 * The format never compresses across frames or introduces new quantization. */
export function deflateResource(data: Uint8Array, kind: "full" | "masked" | "dense"): FrameResource {
  const header = kind === "full" ? 0 : kind === "masked" ? 8 : 4;
  const source = kind === "full" ? data : data.subarray(4);
  const compressed = deflate(source, { level: 9, windowBits: 15, memLevel: 8 });
  const out = new Uint8Array(header + compressed.length);
  if (header) out.set(data.subarray(0, 4));
  if (kind === "masked") new DataView(out.buffer).setUint32(4, source.length, true);
  out.set(compressed, header);
  return { codec: kind === "full" ? FRAME_CODEC_INDEX8_FULL_ZLIB : kind === "masked" ? FRAME_CODEC_INDEX8_MASKED_RECT_ZLIB : FRAME_CODEC_INDEX8_DENSE_RECT_ZLIB, data: out };
}

/** Ties retain the earlier, simpler codec. */
export function smallestFrameResource(...candidates: FrameResource[]): FrameResource {
  return candidates.reduce((best, next) => next.data.length < best.data.length ? next : best);
}
