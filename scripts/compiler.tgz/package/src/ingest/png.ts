import { readFileSync, writeFileSync } from "node:fs";
import { PNG } from "pngjs";

export interface RgbaImage {
  width: number;
  height: number;
  /** RGBA, 4 bytes per pixel. */
  data: Buffer;
}

export function loadPng(path: string): RgbaImage {
  const png = PNG.sync.read(readFileSync(path));
  return { width: png.width, height: png.height, data: png.data };
}

export function savePng(path: string, width: number, height: number, rgba: Uint8Array): void {
  const png = new PNG({ width, height });
  png.data.set(rgba);
  writeFileSync(path, PNG.sync.write(png, { colorType: 6 }));
}

export type Rgb = [number, number, number];

/**
 * Read a full-canvas image that is already on the 120x120 device grid.
 * Every pixel must be fully opaque — these are complete portraits, not layers.
 */
export function readDeviceGrid(img: RgbaImage, canvas: number, label: string): Rgb[] {
  if (img.width !== canvas || img.height !== canvas) {
    throw new Error(`${label}: expected ${canvas}x${canvas} device-grid image, got ${img.width}x${img.height}`);
  }
  const out: Rgb[] = new Array(canvas * canvas);
  for (let i = 0; i < canvas * canvas; i++) {
    const at = i * 4;
    if (img.data[at + 3]! !== 255) {
      throw new Error(`${label}: full frames must be fully opaque (pixel ${i % canvas},${(i / canvas) | 0} has alpha ${img.data[at + 3]})`);
    }
    out[i] = [img.data[at]!, img.data[at + 1]!, img.data[at + 2]!];
  }
  return out;
}
