// Rectification of high-resolution renders onto the 120x120 device grid.
// Ported from claudetest/ingest-demo.mjs (`rectify`, `detectGrid`) — the
// pipeline that produced the approved Pablo talk frames. Mode color per cell
// (not averaging) keeps art outlines crisp; see docs/face-forge-learnings.md.

import type { Rgb, RgbaImage } from "./png.js";

const EDGE_THRESHOLD = 60;
const GRID_MIN = 5;
const GRID_MAX = 24;

export interface GridAxisReport {
  s: number;
  conc: number;
  phase: number;
  lift: number;
}

export interface GridReport {
  x: GridAxisReport;
  y: GridAxisReport;
}

/**
 * Edge-phase histogram grid detection. Report-only: the pipeline never snaps
 * to the detected grid, it just records cell size + lift as a diagnostic.
 */
export function detectGrid(img: RgbaImage): GridReport {
  const positionsX: number[] = [];
  const positionsY: number[] = [];
  const stride = 7;
  for (let y = 3; y < img.height - 3; y += stride) {
    for (let x = 1; x < img.width; x++) {
      const a = (y * img.width + x - 1) * 4;
      const b = (y * img.width + x) * 4;
      const d = Math.max(
        Math.abs(img.data[a]! - img.data[b]!),
        Math.abs(img.data[a + 1]! - img.data[b + 1]!),
        Math.abs(img.data[a + 2]! - img.data[b + 2]!),
      );
      if (d > EDGE_THRESHOLD) positionsX.push(x);
    }
  }
  for (let x = 3; x < img.width - 3; x += stride) {
    for (let y = 1; y < img.height; y++) {
      const a = ((y - 1) * img.width + x) * 4;
      const b = (y * img.width + x) * 4;
      const d = Math.max(
        Math.abs(img.data[a]! - img.data[b]!),
        Math.abs(img.data[a + 1]! - img.data[b + 1]!),
        Math.abs(img.data[a + 2]! - img.data[b + 2]!),
      );
      if (d > EDGE_THRESHOLD) positionsY.push(y);
    }
  }
  const score = (positions: number[], s: number): { conc: number; phase: number } => {
    if (!positions.length) return { conc: 0, phase: 0 };
    const hist = new Array<number>(s).fill(0);
    for (const p of positions) hist[p % s]!++;
    let best = 0;
    let bestPhase = 0;
    for (let phase = 0; phase < s; phase++) {
      const c = hist[(phase + s - 1) % s]! + hist[phase]! + hist[(phase + 1) % s]!;
      if (c > best) {
        best = c;
        bestPhase = phase;
      }
    }
    return { conc: best / positions.length, phase: bestPhase };
  };
  const pick = (positions: number[]): GridAxisReport => {
    // lift = concentration relative to the 3/s random baseline, so small s
    // (whose +-1 window covers most of the cycle) cannot win by default
    let chosen: GridAxisReport | null = null;
    for (let s = GRID_MIN; s <= GRID_MAX; s++) {
      const r = { s, ...score(positions, s), lift: 0 };
      r.lift = r.conc / (3 / s);
      if (!chosen || r.lift > chosen.lift) chosen = r;
    }
    return chosen!;
  };
  return { x: pick(positionsX), y: pick(positionsY) };
}

/**
 * Rectify an arbitrary-resolution render to `canvas` x `canvas` pixels using
 * uniform cell bins and the mode color of each cell: pixels are binned at
 * 4 bits/channel, the most populous bin wins, and the output is the mean of
 * that bin only. Pixels with alpha < 128 are skipped.
 */
export function rectify(img: RgbaImage, canvas: number): Rgb[] {
  const out: Rgb[] = new Array(canvas * canvas);
  for (let j = 0; j < canvas; j++) {
    const y0 = Math.floor((j * img.height) / canvas);
    const y1 = Math.floor(((j + 1) * img.height) / canvas);
    for (let i = 0; i < canvas; i++) {
      const x0 = Math.floor((i * img.width) / canvas);
      const x1 = Math.floor(((i + 1) * img.width) / canvas);
      const bins = new Map<number, { count: number; sr: number; sg: number; sb: number }>();
      for (let y = y0; y < y1; y++) {
        for (let x = x0; x < x1; x++) {
          const at = (y * img.width + x) * 4;
          if (img.data[at + 3]! < 128) continue;
          const r = img.data[at]!;
          const g = img.data[at + 1]!;
          const b = img.data[at + 2]!;
          const key = ((r >> 4) << 8) | ((g >> 4) << 4) | (b >> 4);
          let bin = bins.get(key);
          if (!bin) {
            bin = { count: 0, sr: 0, sg: 0, sb: 0 };
            bins.set(key, bin);
          }
          bin.count++;
          bin.sr += r;
          bin.sg += g;
          bin.sb += b;
        }
      }
      let top: { count: number; sr: number; sg: number; sb: number } | null = null;
      for (const bin of bins.values()) if (!top || bin.count > top.count) top = bin;
      out[j * canvas + i] = top
        ? [Math.round(top.sr / top.count), Math.round(top.sg / top.count), Math.round(top.sb / top.count)]
        : [0, 0, 0];
    }
  }
  return out;
}
