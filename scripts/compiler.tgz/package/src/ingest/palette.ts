// Shared-palette construction: median cut in RGB565 space, no dithering
// (dither noise inflates size and shimmers between frames — claudetest/
// README.md). Ported from claudetest/ingest-demo.mjs (`buildPalette`) with a
// per-frame weight parameter so approved talk art dominates the cut.

export type Rgb = [number, number, number];

export const to565 = ([r, g, b]: Rgb): number => ((r >> 3) << 11) | ((g >> 2) << 5) | (b >> 3);

export const from565 = (v: number): Rgb => {
  const r5 = (v >> 11) & 31;
  const g6 = (v >> 5) & 63;
  const b5 = v & 31;
  return [(r5 << 3) | (r5 >> 2), (g6 << 2) | (g6 >> 4), (b5 << 3) | (b5 >> 2)];
};

/**
 * Weighted squared distance used for nearest-palette projection. Green is
 * weighted heaviest (matches the deployed full-frame builder's metric).
 */
export const weightedDistance = (a: Rgb, b: Rgb): number => {
  const dr = a[0] - b[0];
  const dg = a[1] - b[1];
  const db = a[2] - b[2];
  return 2 * dr * dr + 3 * dg * dg + 2 * db * db;
};

export interface PaletteResult {
  palette: Rgb[];
  indexOf: (px: Rgb) => number;
  uniqueBefore: number;
}

export interface WeightedFrame {
  pixels: Rgb[];
  /** Integer census weight for every pixel of this frame (>= 1). */
  weight: number;
}

/** RGB565 census over frames: value -> weighted pixel count, first-seen order. */
export function censusOf(frames: WeightedFrame[]): Map<number, number> {
  const counts = new Map<number, number>();
  for (const f of frames) {
    for (const px of f.pixels) {
      const v = to565(px);
      counts.set(v, (counts.get(v) ?? 0) + f.weight);
    }
  }
  return counts;
}

/** Median cut over an RGB565 census down to at most `maxPalette` entries. */
export function medianCutCensus(counts: Map<number, number>, maxPalette: number): Rgb[] {
  if (maxPalette <= 0) return [];
  let entries = [...counts.entries()].map(([v, count]) => ({ rgb: from565(v), count }));
  if (entries.length > maxPalette) {
    let boxes: { rgb: Rgb; count: number }[][] = [entries];
    while (boxes.length < maxPalette) {
      let boxIndex = -1;
      let boxRange = -1;
      let boxAxis = 0;
      for (let i = 0; i < boxes.length; i++) {
        if (boxes[i]!.length < 2) continue;
        for (let axis = 0; axis < 3; axis++) {
          let lo = 255;
          let hi = 0;
          for (const e of boxes[i]!) {
            lo = Math.min(lo, e.rgb[axis]!);
            hi = Math.max(hi, e.rgb[axis]!);
          }
          if (hi - lo > boxRange) {
            boxRange = hi - lo;
            boxIndex = i;
            boxAxis = axis;
          }
        }
      }
      if (boxIndex < 0) break;
      const box = boxes[boxIndex]!.sort((a, b) => a.rgb[boxAxis]! - b.rgb[boxAxis]!);
      const total = box.reduce((n, e) => n + e.count, 0);
      let acc = 0;
      let cut = 1;
      for (let i = 0; i < box.length - 1; i++) {
        acc += box[i]!.count;
        if (acc * 2 >= total) {
          cut = i + 1;
          break;
        }
      }
      boxes.splice(boxIndex, 1, box.slice(0, cut), box.slice(cut));
    }
    entries = boxes.map((box) => {
      const total = box.reduce((n, e) => n + e.count, 0);
      const rgb = [0, 1, 2].map((axis) =>
        Math.round(box.reduce((n, e) => n + e.rgb[axis]! * e.count, 0) / total),
      ) as Rgb;
      return { rgb: from565(to565(rgb)), count: total };
    });
  }
  return entries.map((e) => e.rgb);
}

/** Memoized nearest-entry lookup for a fixed palette. Exact colors win (d=0). */
export function paletteIndexer(palette: Rgb[]): (px: Rgb) => number {
  const cache = new Map<number, number>();
  return (px: Rgb): number => {
    const v = to565(px);
    const cached = cache.get(v);
    if (cached !== undefined) return cached;
    let best = 0;
    let bestD = Infinity;
    const snapped = from565(v);
    for (let i = 0; i < palette.length; i++) {
      const d = weightedDistance(palette[i]!, snapped);
      if (d < bestD) {
        bestD = d;
        best = i;
      }
    }
    cache.set(v, best);
    return best;
  };
}

export function buildPalette(frames: WeightedFrame[], maxPalette: number): PaletteResult {
  const counts = censusOf(frames);
  const uniqueBefore = counts.size;
  const palette = medianCutCensus(counts, maxPalette);
  return { palette, indexOf: paletteIndexer(palette), uniqueBefore };
}

export interface ReservedPaletteResult extends PaletteResult {
  /**
   * "reserved-exact": every talk color fit inside the reserve budget and
   * ships bit-identical. "reserved-topk": the most-populated talk colors are
   * reserved verbatim and rare talk colors snap to their nearest reserved
   * neighbor (measured on Pablo: mean weighted error 0.11 at budget 180).
   */
  strategy: "reserved-exact" | "reserved-topk";
  reservedCount: number;
}

/**
 * Palette strategy for full-frame banks: the approved talk frames' colors are
 * reserved (all of them if they fit the reserve budget, else the top-budget
 * by pixel population), and the emotion frames' remaining colors are
 * median-cut into whatever entries are left. Emotion pixels reuse reserved
 * face colors via nearest lookup, which is why a modest emotion budget works.
 */
export function buildReservedPalette(
  reservedFrames: Rgb[][],
  otherFrames: Rgb[][],
  maxPalette: number,
  reserveBudget: number,
): ReservedPaletteResult {
  const reservedCensus = censusOf(reservedFrames.map((pixels) => ({ pixels, weight: 1 })));
  const otherCensus = censusOf(otherFrames.map((pixels) => ({ pixels, weight: 1 })));
  return buildReservedPaletteFromCensus(reservedCensus, otherCensus, maxPalette, reserveBudget);
}

/** Reserve a bounded slice of the shared 240px palette for tiny facial and
 * overlay resources. A full-frame census otherwise overwhelms their colors,
 * even when the resulting small patches are visibly wrong. The greedy choice
 * is deterministic and targets the worst source-relative resource first. */
export function buildNativeProtectedPalette(
  reservedFrames: Rgb[][],
  otherFrames: Rgb[][],
  criticalResources: Rgb[][],
  maxPalette: number,
  reserveBudget: number,
  protectedSlots = 48,
): ReservedPaletteResult {
  if (!Number.isInteger(protectedSlots) || protectedSlots < 0 || protectedSlots >= maxPalette || protectedSlots > reserveBudget)
    throw new Error("invalid protected palette slots");
  const base = buildReservedPalette(reservedFrames, otherFrames, maxPalette - protectedSlots, reserveBudget - protectedSlots);
  const full = buildReservedPalette(reservedFrames, otherFrames, maxPalette, reserveBudget);
  const palette = [...base.palette];
  const present = new Set(palette.map(to565));
  const nearest = (color: Rgb): number => palette.reduce((best, entry) => Math.min(best, weightedDistance(color, entry)), Infinity);
  // A hostile but structurally valid set of high-color overlays must not make
  // compilation allocate one RGB/distance object per resource-color pair or
  // run an unbounded greedy search. All resources share the RGB565 lattice.
  const MAX_CRITICAL_RESOURCES = 2048;
  const MAX_CRITICAL_CENSUS_ENTRIES = 250_000;
  const distances = new Map<number, { rgb: Rgb; distance: number }>();
  const resources: { count: number; entries: { v: number; n: number }[] }[] = [];
  let censusEntries = 0;
  for (const colors of criticalResources) {
    if (colors.length === 0) continue;
    if (resources.length >= MAX_CRITICAL_RESOURCES) throw new Error("NATIVE_PALETTE_WORK_LIMIT");
    const census = censusOf([{ pixels: colors, weight: 1 }]);
    censusEntries += census.size;
    if (censusEntries > MAX_CRITICAL_CENSUS_ENTRIES) throw new Error("NATIVE_PALETTE_WORK_LIMIT");
    const entries = [...census.entries()].map(([v, n]) => {
      if (!distances.has(v)) {
        const rgb = from565(v);
        distances.set(v, { rgb, distance: nearest(rgb) });
      }
      return { v, n };
    });
    resources.push({ count: colors.length, entries });
  }
  const limit = 7 * 255 * 255 / 1000; // same 30 dB floor as the native compiler gates
  for (let slot = 0; slot < protectedSlots; slot++) {
    let worst: typeof resources[number] | undefined;
    let worstMean = limit;
    for (const resource of resources) {
      const mean = resource.entries.reduce((sum, entry) => sum + entry.n * distances.get(entry.v)!.distance, 0) / resource.count;
      if (mean > worstMean) { worst = resource; worstMean = mean; }
    }
    if (!worst) break;
    let selected: { v: number; score: number } | undefined;
    for (const entry of worst.entries) {
      if (present.has(entry.v)) continue;
      const score = entry.n * distances.get(entry.v)!.distance;
      if (!selected || score > selected.score || score === selected.score && entry.v < selected.v)
        selected = { v: entry.v, score };
    }
    if (!selected) break;
    present.add(selected.v);
    const color = from565(selected.v);
    palette.push(color);
    for (const entry of distances.values())
      entry.distance = Math.min(entry.distance, weightedDistance(entry.rgb, color));
  }
  for (const color of full.palette) {
    if (palette.length >= maxPalette) break;
    const v = to565(color);
    if (present.has(v)) continue;
    present.add(v);
    palette.push(color);
  }
  return { palette, indexOf: paletteIndexer(palette), uniqueBefore: full.uniqueBefore,
    strategy: base.strategy, reservedCount: base.reservedCount };
}

/** Same palette policy, with bounded-memory census input for large native banks. */
export function buildReservedPaletteFromCensus(
  reservedCensus: ReadonlyMap<number, number>,
  otherCensus: ReadonlyMap<number, number>,
  maxPalette: number,
  reserveBudget: number,
): ReservedPaletteResult {
  const uniqueBefore = new Set([...reservedCensus.keys(), ...otherCensus.keys()]).size;
  const budget = Math.min(reserveBudget, maxPalette);
  // Deterministic order: population desc, RGB565 value asc as the tie-break.
  const byPopulation = [...reservedCensus.entries()].sort((a, b) => b[1] - a[1] || a[0] - b[0]);
  const strategy = byPopulation.length <= budget ? "reserved-exact" : "reserved-topk";
  const reservedValues = byPopulation.slice(0, budget).map(([v]) => v);
  const reserved = reservedValues.map((v) => from565(v));
  const reservedSet = new Set(reservedValues);
  const remainderCensus = new Map<number, number>();
  for (const [v, count] of otherCensus) {
    if (!reservedSet.has(v)) remainderCensus.set(v, count);
  }
  const emotionEntries = medianCutCensus(remainderCensus, maxPalette - reserved.length);
  const seen = new Set(reservedValues);
  const palette = [...reserved];
  for (const rgb of emotionEntries) {
    const v = to565(rgb);
    if (seen.has(v)) continue;
    seen.add(v);
    palette.push(rgb);
  }
  return {
    palette,
    indexOf: paletteIndexer(palette),
    uniqueBefore,
    strategy,
    reservedCount: reserved.length,
  };
}
