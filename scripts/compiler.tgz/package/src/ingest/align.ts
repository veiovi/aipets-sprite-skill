// Integer-translation alignment of a rectified frame against the neutral
// base. Ported from claudetest/ingest-demo.mjs (`align`, `samePixel`).
// Runs on rectified RGB BEFORE any quantization — diffing after quantization
// was the documented v0 failure (claudetest/README.md).

import type { Rgb } from "./png.js";

export const ALIGN_RADIUS = 4;
export const DIFF_TOLERANCE = 28;

export const within = (a: Rgb, b: Rgb, tol: number): boolean =>
  Math.abs(a[0] - b[0]) <= tol && Math.abs(a[1] - b[1]) <= tol && Math.abs(a[2] - b[2]) <= tol;

export const samePixel = (a: Rgb, b: Rgb): boolean => within(a, b, DIFF_TOLERANCE);

export interface AlignResult {
  dx: number;
  dy: number;
  cost: number;
  aligned: Rgb[];
}

export function align(statePx: Rgb[], basePx: Rgb[], canvas: number): AlignResult {
  let best = { dx: 0, dy: 0, cost: Infinity };
  for (let dy = -ALIGN_RADIUS; dy <= ALIGN_RADIUS; dy++) {
    for (let dx = -ALIGN_RADIUS; dx <= ALIGN_RADIUS; dx++) {
      let cost = 0;
      for (let y = 0; y < canvas; y++) {
        const sy = y + dy;
        if (sy < 0 || sy >= canvas) continue;
        for (let x = 0; x < canvas; x++) {
          const sx = x + dx;
          if (sx < 0 || sx >= canvas) continue;
          if (!samePixel(statePx[sy * canvas + sx]!, basePx[y * canvas + x]!)) cost++;
        }
      }
      if (cost < best.cost) best = { dx, dy, cost };
    }
  }
  const aligned: Rgb[] = new Array(canvas * canvas);
  for (let y = 0; y < canvas; y++) {
    for (let x = 0; x < canvas; x++) {
      const sx = x + best.dx;
      const sy = y + best.dy;
      aligned[y * canvas + x] =
        sx >= 0 && sx < canvas && sy >= 0 && sy < canvas ? statePx[sy * canvas + sx]! : basePx[y * canvas + x]!;
    }
  }
  return { ...best, aligned };
}
