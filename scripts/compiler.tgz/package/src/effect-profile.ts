import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import { dirname, isAbsolute, join, normalize, relative, resolve, sep } from "node:path";
import { z } from "zod";
import { loadPng } from "./ingest/png.js";
import { actionSchema, characterSchema, requiredEffectRoleSchema } from "./schema.js";

export const REQUIRED_EFFECT_ROLES = [
  "listening", "thinking", "speaking", "touch", "booting",
  "provisioning", "connecting", "offline", "error",
] as const;

export type RequiredEffectRole = (typeof REQUIRED_EFFECT_ROLES)[number];

export const REQUIRED_EFFECT_BINDINGS: Record<RequiredEffectRole, { plane: "stateFx" | "touchFx"; semantic: string; states: string[] }> = {
  listening: { plane: "stateFx", semantic: "listening", states: ["listening"] },
  thinking: { plane: "stateFx", semantic: "thinking", states: ["thinking"] },
  speaking: { plane: "stateFx", semantic: "speaking", states: ["speaking"] },
  touch: { plane: "touchFx", semantic: "touch", states: ["idle", "listening", "thinking", "speaking"] },
  booting: { plane: "stateFx", semantic: "booting", states: ["booting"] },
  provisioning: { plane: "stateFx", semantic: "provisioning", states: ["provisioning"] },
  connecting: { plane: "stateFx", semantic: "connecting", states: ["connecting"] },
  offline: { plane: "stateFx", semantic: "offline", states: ["offline"] },
  error: { plane: "stateFx", semantic: "error", states: ["error"] },
};

const hash = z.string().regex(/^[a-f0-9]{64}$/);
const baselineRoleSchema = z.object({
  role: requiredEffectRoleSchema,
  actionId: z.string().min(1),
  action: actionSchema,
  approval: z.object({
    status: z.literal("approved"),
    reviewer: z.string().min(1),
    artifact: z.string().min(1),
    sha256: hash,
  }),
  frames: z.array(z.object({ path: z.string().min(1), sha256: hash })).min(1),
});

export const stateFxBaselineSchema = z.object({
  schemaVersion: z.literal(1),
  id: z.string().min(1),
  version: z.string().regex(/^\d+\.\d+\.\d+$/),
  sourceRun: z.object({ path: z.string().min(1), sha256: hash }),
  roles: z.array(baselineRoleSchema).length(REQUIRED_EFFECT_ROLES.length),
});

type JsonObject = Record<string, unknown>;
type Action = z.infer<typeof actionSchema>;

export interface EffectiveEffectProfile {
  manifest: JsonObject;
  lockFiles: Record<string, { sha256: string; bytes: number }>;
  roles: Record<RequiredEffectRole, { source: "baseline" | "custom"; actionId: string }>;
  baselineManifest: string;
  baselineManifestSha256: string;
}

const digest = (bytes: Uint8Array): string => createHash("sha256").update(bytes).digest("hex");
const sameStrings = (a: string[], b: string[]): boolean => a.length === b.length && a.every((value, index) => value === b[index]);

function repositoryRoot(characterDir: string): string {
  const charactersDir = dirname(resolve(characterDir));
  if (charactersDir.split(sep).at(-1) !== "characters") throw new Error("EFFECT_PROFILE_CHARACTER_PATH");
  return dirname(charactersDir);
}

function inside(root: string, candidate: string, code: string): string {
  const target = resolve(root, candidate);
  const rel = relative(root, target);
  if (rel.startsWith(`..${sep}`) || rel === ".." || isAbsolute(rel)) throw new Error(code);
  return target;
}

function verifyEvidence(characterDir: string, evidence: { path: string; sha256: string }, code: string): void {
  const target = inside(characterDir, evidence.path, code);
  const bytes = readFileSync(target);
  if (digest(bytes) !== evidence.sha256) throw new Error(`${code}_HASH`);
}

function validateBinding(role: RequiredEffectRole, action: Action, prefix: string): void {
  const binding = REQUIRED_EFFECT_BINDINGS[role];
  if (action.plane !== binding.plane || action.semantic !== binding.semantic) throw new Error(`${prefix}_BINDING`);
  if (action.activation.kind !== "semantic" || !sameStrings(action.activation.states, binding.states)) throw new Error(`${prefix}_ACTIVATION`);
  if (!action.essential || !["full", "balanced", "reduced"].every((profile) => action.profiles.includes(profile as never))) {
    throw new Error(`${prefix}_PROFILES`);
  }
}

function actionFrames(action: Action): string[] {
  const steps = "enterSteps" in action
    ? [...action.enterSteps, ...action.holdSteps, ...action.exitSteps]
    : [...action.steps, ...(action.exitSteps ?? [])];
  return [...new Set(steps.map((step) => step.frame.file))];
}

function rewriteAction(action: Action, prefix: string): Action {
  const copy = structuredClone(action);
  const rewrite = (steps: { frame: { file: string } }[]): void => {
    for (const step of steps) step.frame.file = normalize(join(prefix, step.frame.file)).replaceAll("\\", "/");
  };
  if ("enterSteps" in copy) {
    rewrite(copy.enterSteps); rewrite(copy.holdSteps); rewrite(copy.exitSteps);
  } else {
    rewrite(copy.steps); if (copy.exitSteps) rewrite(copy.exitSteps);
  }
  return copy;
}

function validateFacialSafety(character: z.infer<typeof characterSchema>, characterDir: string, action: Action, allowShared: boolean, guard = 2): void {
  if (!character.facialRegions) throw new Error("EFFECT_PROFILE_MISSING_FACIAL_REGIONS");
  for (const file of actionFrames(action)) {
    const target = resolve(characterDir, file);
    const root = allowShared ? repositoryRoot(characterDir) : resolve(characterDir);
    const checked = inside(root, relative(root, target), "EFFECT_PROFILE_FRAME_PATH");
    const image = loadPng(checked);
    if (image.width !== 120 || image.height !== 120) throw new Error(`EFFECT_PROFILE_FRAME_SIZE:${file}`);
    for (let offset = 0; offset < image.width * image.height; offset++) {
      const alpha = image.data[offset * 4 + 3]!;
      if (alpha !== 0 && alpha !== 255) throw new Error(`EFFECT_PROFILE_SOFT_ALPHA:${file}`);
      if (alpha === 0 && (image.data[offset * 4]! || image.data[offset * 4 + 1]! || image.data[offset * 4 + 2]!)) {
        throw new Error(`EFFECT_PROFILE_HIDDEN_RGB:${file}`);
      }
    }
    for (const group of character.facialRegions.groups) {
      for (const feature of [group.eyes.rect, group.mouth.rect]) {
        const x0 = Math.max(0, feature.x - guard), y0 = Math.max(0, feature.y - guard);
        const x1 = Math.min(120, feature.x + feature.width + guard), y1 = Math.min(120, feature.y + feature.height + guard);
        for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) {
          if (image.data[(y * 120 + x) * 4 + 3] === 255) throw new Error(`EFFECT_PROFILE_FACIAL_OVERLAP:${file}:${group.id}`);
        }
      }
    }
  }
}

export function resolveEffectiveEffectProfile(characterDir: string, raw: unknown): EffectiveEffectProfile {
  const character = characterSchema.parse(raw);
  const profile = character.effectProfile;
  if (!profile) throw new Error("EFFECT_PROFILE_REQUIRED");
  verifyEvidence(characterDir, profile.speakingApproval, "EFFECT_PROFILE_SPEAKING_APPROVAL");
  const root = repositoryRoot(characterDir);
  const baselineCandidate = resolve(characterDir, profile.baseline.manifest);
  const baselinePath = inside(root, relative(root, baselineCandidate), "EFFECT_PROFILE_BASELINE_PATH");
  const baselineBytes = readFileSync(baselinePath);
  if (digest(baselineBytes) !== profile.baseline.manifestSha256) throw new Error("EFFECT_PROFILE_BASELINE_HASH");
  const baseline = stateFxBaselineSchema.parse(JSON.parse(baselineBytes.toString("utf8")));
  if (baseline.id !== profile.baseline.id || baseline.version !== profile.baseline.version) throw new Error("EFFECT_PROFILE_BASELINE_IDENTITY");
  const baselineDir = dirname(baselinePath);
  const sourceRun = inside(baselineDir, baseline.sourceRun.path, "EFFECT_PROFILE_SOURCE_RUN");
  if (digest(readFileSync(sourceRun)) !== baseline.sourceRun.sha256) throw new Error("EFFECT_PROFILE_SOURCE_RUN_HASH");
  const prefix = relative(resolve(characterDir), baselineDir).replaceAll("\\", "/");
  const actions = [...character.actions];
  const lockFiles: Record<string, { sha256: string; bytes: number }> = {};
  const roles = {} as EffectiveEffectProfile["roles"];

  for (const role of REQUIRED_EFFECT_ROLES) {
    const override = profile.overrides[role];
    if (override) {
      verifyEvidence(characterDir, override.approval, `EFFECT_PROFILE_${role.toUpperCase()}_APPROVAL`);
      const matches = actions.filter((action) => action.id === override.actionId);
      if (matches.length !== 1) throw new Error(`EFFECT_PROFILE_${role.toUpperCase()}_OWNER`);
      validateBinding(role, matches[0]!, `EFFECT_PROFILE_${role.toUpperCase()}`);
      roles[role] = { source: "custom", actionId: override.actionId };
      continue;
    }
    const candidates = baseline.roles.filter((entry) => entry.role === role);
    if (candidates.length !== 1) throw new Error(`EFFECT_PROFILE_${role.toUpperCase()}_BASELINE_OWNER`);
    const entry = candidates[0]!;
    if (entry.action.id !== entry.actionId) throw new Error(`EFFECT_PROFILE_${role.toUpperCase()}_ACTION_ID`);
    validateBinding(role, entry.action, `EFFECT_PROFILE_${role.toUpperCase()}`);
    const approvalPath = inside(baselineDir, entry.approval.artifact, `EFFECT_PROFILE_${role.toUpperCase()}_BASELINE_APPROVAL`);
    if (digest(readFileSync(approvalPath)) !== entry.approval.sha256) throw new Error(`EFFECT_PROFILE_${role.toUpperCase()}_BASELINE_APPROVAL_HASH`);
    const expected = new Map(entry.frames.map((frame) => [frame.path, frame.sha256]));
    for (const file of actionFrames(entry.action)) {
      const expectedHash = expected.get(file);
      if (!expectedHash) throw new Error(`EFFECT_PROFILE_${role.toUpperCase()}_FRAME_LEDGER`);
      const source = inside(baselineDir, file, `EFFECT_PROFILE_${role.toUpperCase()}_FRAME_PATH`);
      const bytes = readFileSync(source);
      if (digest(bytes) !== expectedHash) throw new Error(`EFFECT_PROFILE_${role.toUpperCase()}_FRAME_HASH`);
      const rewritten = normalize(join(prefix, file)).replaceAll("\\", "/");
      lockFiles[rewritten] = { sha256: expectedHash, bytes: bytes.length };
    }
    const rewritten = rewriteAction(entry.action, prefix);
    if (actions.some((action) => action.id === rewritten.id)) throw new Error(`EFFECT_PROFILE_DUPLICATE_ACTION:${rewritten.id}`);
    actions.push(rewritten);
    roles[role] = { source: "baseline", actionId: rewritten.id };
  }

  for (const role of REQUIRED_EFFECT_ROLES) {
    const binding = REQUIRED_EFFECT_BINDINGS[role];
    const owners = actions.filter((action) => action.plane === binding.plane && action.semantic === binding.semantic && action.activation.kind === "semantic");
    if (owners.length !== 1 || owners[0]!.id !== roles[role].actionId) throw new Error(`EFFECT_PROFILE_${role.toUpperCase()}_MULTIPLE_OWNERS`);
  }

  const resolved = { ...(raw as JsonObject), actions };
  const parsedResolved = characterSchema.parse(resolved);
  for (const role of REQUIRED_EFFECT_ROLES) {
    const action = parsedResolved.actions.find((candidate) => candidate.id === roles[role].actionId)!;
    validateFacialSafety(parsedResolved, characterDir, action, roles[role].source === "baseline");
  }
  return {
    manifest: resolved,
    lockFiles,
    roles,
    baselineManifest: relative(root, baselinePath).replaceAll("\\", "/"),
    baselineManifestSha256: profile.baseline.manifestSha256,
  };
}
