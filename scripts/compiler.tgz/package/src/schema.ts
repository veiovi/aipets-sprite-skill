import { z } from "zod";
import {
  ACTION_PLANES,
  ACTION_SEMANTICS,
  ACTIVATION_KINDS,
  ANIMATION_PROFILES,
  EMOTION_IDS,
  FRAME_PACK_CANVAS,
  FRAME_PACK_MAX_BYTES,
  FRAME_PACK_MAX_BYTES_240,
  FRAME_PACK_MAX_ACTIONS_240,
  FRAME_PACK_MAX_OVERLAYS,
  FRAME_PACK_MAX_PALETTE,
  TALK_LEVEL_MAX,
  FACIAL_GROUP_ROLES,
  SPEAKING_GESTURE_KINDS,
  SPEAKING_MAX_BREAK_TICKS,
  SPEAKING_MAX_GESTURES,
  SPEAKING_MAX_GESTURE_STEPS,
  SPEAKING_MAX_POSES,
  SPEAKING_MIN_GESTURE_STEPS,
} from "./constants.js";

/**
 * Authoring manifest (`character.json`) for a full-frame character. The
 * manifest plus the files it references are the complete, committed input of
 * a deterministic compile; future characters are a folder + manifest, no code.
 */

const idPattern = /^[a-z][a-z0-9_-]{0,63}$/;
const sha256Pattern = /^[a-f0-9]{64}$/;

export const requiredEffectRoleSchema = z.enum([
  "listening", "thinking", "speaking", "touch", "booting",
  "provisioning", "connecting", "offline", "error",
]);

const approvalEvidenceSchema = z.object({
  kind: z.enum(["h3-speaking-handoff", "legacy-reviewed", "statefx-review"]),
  path: z.string().min(1),
  sha256: z.string().regex(sha256Pattern),
  reviewer: z.string().min(1),
});

export const effectProfileSchema = z.object({
  baseline: z.object({
    id: z.string().regex(idPattern),
    version: z.string().regex(/^\d+\.\d+\.\d+$/),
    manifest: z.string().min(1),
    manifestSha256: z.string().regex(sha256Pattern),
  }),
  speakingApproval: approvalEvidenceSchema,
  overrides: z.record(requiredEffectRoleSchema, z.object({
    actionId: z.string().regex(idPattern),
    approval: approvalEvidenceSchema,
  })).default({}),
  additionalEffects: z.array(z.string().regex(idPattern)).default([]),
});

export const sourceRefSchema = z.object({
  /** Path relative to the character directory. */
  file: z.string().min(1),
  /**
   * "device-grid": already 120x120, read verbatim.
   * "render": arbitrary resolution, rectified via mode-color cell binning and
   * aligned to the neutral base.
   */
  kind: z.enum(["device-grid", "render"]),
});

export const legacyEmotionSchema = z.object({
  onset: sourceRefSchema,
  full: sourceRefSchema,
  /** Ticks (33 ms) the onset and full frames show during the enter clip. */
  enterTicks: z.tuple([z.number().int().min(1).max(30), z.number().int().min(1).max(30)]).default([3, 1]),
  /** Ticks the onset frame shows during the exit clip. */
  exitTicks: z.tuple([z.number().int().min(1).max(30)]).default([3]),
  /** Emotion is held at least this long even if cleared earlier. */
  minHoldMs: z.number().int().min(0).max(60000).default(1200),
  /** Emotion auto-exits after this long without a refresh. */
  maxHoldMs: z.number().int().min(500).max(60000).default(7000),
  /**
   * Weight in the idle micro-expression lottery (0 = never used as an idle
   * micro). Micros play the onset only, never the full frame.
   */
  microWeight: z.number().int().min(0).max(100).default(0),
});

const detailedEmotionStepSchema = z.object({
  frame: sourceRefSchema,
  durationMs: z.number().int().min(33).max(65535 * 33),
});

export const detailedEmotionSchema = z.object({
  enterSteps: z.array(detailedEmotionStepSchema).min(1).max(256),
  holdSteps: z.array(detailedEmotionStepSchema).min(1).max(256),
  exitSteps: z.array(detailedEmotionStepSchema).min(1).max(256),
  holdMode: z.enum(["loop", "hold-last"]).default("loop"),
  minHoldMs: z.number().int().min(0).max(60000).default(1200),
  maxHoldMs: z.number().int().min(500).max(60000).default(7000),
  microWeight: z.number().int().min(0).max(100).default(0),
});

export const emotionSchema = z.union([legacyEmotionSchema, detailedEmotionSchema]);

export const idlePerformanceSchema = z.object({
  id: z.string().regex(idPattern),
  /** Complete-frame keys played once from neutral and back to neutral. */
  steps: z
    .array(
      z.object({
        frame: sourceRefSchema,
        durationMs: z.number().int().min(33).max(10000),
      }),
    )
    .min(1)
    .max(32),
  /** Relative selection weight; the showcase walks entries deterministically. */
  weight: z.number().int().min(1).max(100).default(1),
  returnMs: z.number().int().min(33).max(1000).default(165),
});

const actionStepSchema = z.object({
  frame: sourceRefSchema,
  durationMs: z.number().int().min(33).max(65535 * 33),
});

const activationSchema = z
  .object({
    kind: z.enum(ACTIVATION_KINDS),
    states: z
      .array(z.enum(["booting", "provisioning", "connecting", "idle", "listening", "thinking", "speaking", "offline", "error"]))
      .min(1)
      .default(["idle"]),
    expressions: z
      .array(z.enum(["neutral", ...Object.keys(EMOTION_IDS)] as [string, ...string[]]))
      .min(1)
      .default(["neutral"]),
    performances: z.array(z.string().regex(idPattern)).max(16).default([]),
    intervalMs: z
      .object({ min: z.number().int().min(500).max(300000), max: z.number().int().min(500).max(300000) })
      .optional(),
  })
  .superRefine((activation, context) => {
    if (activation.kind === "ambient-event") {
      if (!activation.intervalMs) {
        context.addIssue({ code: z.ZodIssueCode.custom, message: "ambient-event requires intervalMs" });
      } else if (activation.intervalMs.min >= activation.intervalMs.max) {
        context.addIssue({ code: z.ZodIssueCode.custom, message: "ambient-event interval min must be < max" });
      }
    } else if (activation.intervalMs) {
      context.addIssue({ code: z.ZodIssueCode.custom, message: `${activation.kind} must not declare intervalMs` });
    }
  });

const actionBaseSchema = z.object({
  id: z.string().regex(idPattern),
  semantic: z.enum(ACTION_SEMANTICS),
  plane: z.enum(ACTION_PLANES),
  activation: activationSchema,
  priority: z.number().int().min(0).max(255).default(100),
  essential: z.boolean().default(false),
  profiles: z.array(z.enum(ANIMATION_PROFILES)).min(1).default(["full", "balanced"]),
  cooldownMs: z.number().int().min(0).max(60000).default(0),
  posePolicy: z.enum(["screen", "center-only"]).optional(),
});

const legacyActionSchema = actionBaseSchema.extend({
  steps: z.array(actionStepSchema).min(1).max(256),
  exitSteps: z.array(actionStepSchema).min(1).max(32).optional(),
  loop: z.enum(["once", "loop", "hold-last"]).default("once"),
});

const detailedActionSchema = actionBaseSchema.extend({
  enterSteps: z.array(actionStepSchema).min(1).max(32),
  holdSteps: z.array(actionStepSchema).min(1).max(32),
  exitSteps: z.array(actionStepSchema).min(1).max(32),
  holdMode: z.enum(["loop", "hold-last"]).default("loop"),
});

export const actionSchema = z.union([legacyActionSchema, detailedActionSchema]);

const timingRangeSchema = z.object({
  minMs: z.number().int().min(33).max(60000),
  maxMs: z.number().int().min(33).max(60000),
});
const facialGroupSchema = z.object({
  id: z.string().regex(idPattern),
  role: z.enum(FACIAL_GROUP_ROLES),
  base: sourceRefSchema,
  mouth: z.object({
    rect: z.object({ x: z.number().int().min(0).max(239), y: z.number().int().min(0).max(239), width: z.number().int().min(1).max(240), height: z.number().int().min(1).max(240) }),
    frames: z.array(z.string().min(1)).length(7),
  }),
  eyes: z.object({
    rect: z.object({ x: z.number().int().min(0).max(239), y: z.number().int().min(0).max(239), width: z.number().int().min(1).max(240), height: z.number().int().min(1).max(240) }),
    frames: z.array(z.string().min(1)).length(5),
  }),
});
const facialRegionsSchema = z.object({
  independentBlink: z.boolean().optional(),
  /** Facial v2 roles are center, left, up, right, down, with authored dwell. */
  gazeStageMs: z.array(z.number().int().min(33).max(60000)).length(5).optional(),
  groups: z.array(facialGroupSchema).length(5),
  blink: z.object({
    states: z.array(z.enum(["idle", "listening", "thinking", "speaking"])).min(1),
    stageMs: z.array(z.number().int().min(33).max(330)).length(5),
    gaps: z.object({ full: timingRangeSchema, balanced: timingRangeSchema, reduced: timingRangeSchema }),
  }),
  pose: z.object({
    states: z.array(z.enum(["idle", "listening", "thinking", "speaking"])).min(1),
    full: z.object({ gap: timingRangeSchema, hold: timingRangeSchema }),
    balanced: z.object({ gap: timingRangeSchema, hold: timingRangeSchema }),
  }),
  bob: z.object({
    states: z.array(z.enum(["idle", "listening", "thinking", "speaking"])).min(1),
    fullAmplitudePx: z.number().int().min(0).max(2),
    balancedAmplitudePx: z.number().int().min(0).max(2),
    periodMs: z.number().int().min(1000).max(10000),
  }),
});

export const characterSchema = z.object({
  schemaVersion: z.union([z.literal(1), z.literal(2), z.literal(3), z.literal(4), z.literal(5)]),
  id: z.string().regex(idPattern),
  name: z.string().min(1).max(48),
  version: z.string().regex(/^\d+\.\d+\.\d+$/),
  gender: z.enum(["unspecified", "neutral", "female", "male"]).default("neutral"),
  canvas: z.object({
    width: z.union([z.literal(FRAME_PACK_CANVAS), z.literal(240)]),
    height: z.union([z.literal(FRAME_PACK_CANVAS), z.literal(240)]),
  }),
  /** Soft ceiling checked by a gate; hard ceiling is one asset slot. */
  budgetBytes: z.number().int().min(1).max(FRAME_PACK_MAX_BYTES_240).default(614400),
  /** Actual selected-layout usable capacity, distinct from the soft review budget. */
  slotCapacityBytes: z.number().int().min(128).max(FRAME_PACK_MAX_BYTES_240).optional(),
  neutral: sourceRefSchema,
  /** Retained source plate, separately addressable in new packs. */
  cleanPlate: sourceRefSchema.optional(),
  talk: z.object({
    /** Stage 0 should be the neutral/closed mouth; frames dedupe by content. */
    stages: z.array(sourceRefSchema).min(2).max(16),
    /**
     * Ascending audio-level breakpoints (0..100), one per stage; stage(level)
     * = highest i with level >= breakpoints[i]. First entry must be 0.
     */
    levelBreakpoints: z.array(z.number().int().min(0).max(TALK_LEVEL_MAX)),
    /** Other head/eye poses while speaking, each with one complete frame per
     * talk stage. `stages` above is the upright pose. */
    poses: z.array(z.object({
      id: z.string().regex(/^[a-z][a-z0-9-]{0,31}$/),
      stages: z.array(sourceRefSchema).min(2).max(16),
    }).strict()).max(SPEAKING_MAX_POSES - 1).default([]),
    /** Played in a shuffled rotation while speaking, each after a neutral
     * break; a path starts and ends at "upright". */
    gestures: z.array(z.object({
      id: z.string().regex(/^[a-z][a-z0-9-]{0,31}$/),
      kind: z.enum(SPEAKING_GESTURE_KINDS),
      automatic: z.boolean().default(true),
      path: z.array(z.object({
        pose: z.string().min(1),
        durationMs: z.number().int().min(33).max(255 * 33),
      }).strict()).min(SPEAKING_MIN_GESTURE_STEPS).max(SPEAKING_MAX_GESTURE_STEPS),
    }).strict()).max(SPEAKING_MAX_GESTURES).default([]),
    breakMs: z.object({
      minMs: z.number().int().min(33).max(SPEAKING_MAX_BREAK_TICKS * 33),
      maxMs: z.number().int().min(33).max(SPEAKING_MAX_BREAK_TICKS * 33),
    }).strict().default({ minMs: 2000, maxMs: 5000 }),
  }),
  emotions: z.record(z.string(), emotionSchema),
  idle: z.object({
    bob: z.object({
      amplitudePx: z.number().int().min(0).max(2).default(1),
      periodMs: z.number().int().min(1000).max(10000).default(3168),
    }),
    micro: z.object({
      minGapMs: z.number().int().min(1000).max(120000).default(8000),
      maxGapMs: z.number().int().min(2000).max(300000).default(20000),
      /** Ticks the onset frame shows during a micro blip. */
      onsetTicks: z.number().int().min(1).max(30).default(5),
    }),
    performances: z.array(idlePerformanceSchema).max(16).default([]),
  }),
  palette: z
    .object({
      maxColors: z.number().int().min(2).max(FRAME_PACK_MAX_PALETTE).default(FRAME_PACK_MAX_PALETTE),
      /**
       * Palette entries reserved verbatim for the talk frames' most-populated
       * colors; the remainder goes to the emotion median cut.
       */
      talkReserve: z.number().int().min(16).max(FRAME_PACK_MAX_PALETTE).default(180),
    })
    .default({}),
  /** Full-frame and hard-alpha actions. Empty keeps the original binary byte-compatible. */
  actions: z.array(actionSchema).max(FRAME_PACK_MAX_ACTIONS_240).default([]),
  /** Hash-pinned authoring contract resolved into actions before pack construction. */
  effectProfile: effectProfileSchema.optional(),
  facialRegions: facialRegionsSchema.optional(),
  /** Removed authoring key retained only to reject stale V1 overlay manifests. */
  overlays: z.array(z.never()).max(0).optional(),
  motion: z
    .object({
      fallbacksEnabled: z.boolean().default(false),
      parallaxSafe: z.boolean().default(false),
      maxParallaxPx: z.number().int().min(0).max(1).default(0),
    })
    .default({}),
  provenance: z.object({
    origin: z.object({
      repoBranch: z.string().min(1),
      commit: z.string().min(1),
    }),
    generation: z.string().optional(),
    publicationRights: z.string().min(1),
  }),
  approval: z.object({
    status: z.enum(["pending", "approved", "rejected"]),
    reviewer: z.string().optional(),
    notes: z.string().optional(),
  }),
});

export type CharacterManifest = z.infer<typeof characterSchema>;
export type EmotionDef = z.infer<typeof emotionSchema>;
export type SourceRef = z.infer<typeof sourceRefSchema>;

export interface ManifestIssue {
  path: string;
  message: string;
}

/** Parse + cross-field validation that Zod alone cannot express. */
export function parseCharacterManifest(raw: unknown): { manifest: CharacterManifest; issues: ManifestIssue[] } {
  const manifest = characterSchema.parse(raw);
  const issues: ManifestIssue[] = [];
  if (manifest.cleanPlate && manifest.canvas.width !== 240) issues.push({path:"cleanPlate",message:"retained clean plate requires 240px schema5"});
  if (manifest.canvas.width === 240 && (manifest.actions.filter(a => a.plane === "base").length > 64 || manifest.actions.filter(a => a.plane !== "base").length > 8)) {
    issues.push({ path: "actions", message: "240px permits at most 64 movements and eight effects" });
  }
  if (manifest.canvas.width === 240 && manifest.slotCapacityBytes === undefined) {
    issues.push({ path: "slotCapacityBytes", message: "240px requires explicit selected-layout usable capacity" });
  }
  if (manifest.slotCapacityBytes !== undefined && manifest.budgetBytes > manifest.slotCapacityBytes) {
    issues.push({ path: "budgetBytes", message: "review budget exceeds selected layout capacity" });
  }
  if (manifest.canvas.width !== manifest.canvas.height ||
      (manifest.canvas.width === 240 && manifest.schemaVersion !== 5)) {
    issues.push({ path: "canvas", message: "240x240 requires schemaVersion 5; only square 120 or 240 canvases are supported" });
  }
  if (manifest.facialRegions?.independentBlink && manifest.canvas.width !== 240) issues.push({path:"facialRegions.independentBlink",message:"independent blink requires 240px schema5"});
  if (manifest.canvas.width === 120 && (manifest.budgetBytes > FRAME_PACK_MAX_BYTES || manifest.actions.length > FRAME_PACK_MAX_OVERLAYS)) {
    issues.push({ path: "budgetBytes", message: "legacy canvas exceeds its format capacity/actions" });
  }
  if (manifest.talk.levelBreakpoints.length !== manifest.talk.stages.length) {
    issues.push({
      path: "talk.levelBreakpoints",
      message: `expected ${manifest.talk.stages.length} breakpoints (one per stage), got ${manifest.talk.levelBreakpoints.length}`,
    });
  }
  if (manifest.talk.levelBreakpoints[0] !== 0) {
    issues.push({ path: "talk.levelBreakpoints", message: "first breakpoint must be 0" });
  }
  for (let i = 1; i < manifest.talk.levelBreakpoints.length; i++) {
    if (manifest.talk.levelBreakpoints[i]! <= manifest.talk.levelBreakpoints[i - 1]!) {
      issues.push({ path: `talk.levelBreakpoints[${i}]`, message: "breakpoints must be strictly ascending" });
    }
  }
  for (const name of Object.keys(manifest.emotions)) {
    if (!(name in EMOTION_IDS)) {
      issues.push({
        path: `emotions.${name}`,
        message: `unknown emotion "${name}"; known: ${Object.keys(EMOTION_IDS).join(", ")}`,
      });
    }
  }
  for (const [name, emotion] of Object.entries(manifest.emotions)) {
    if (emotion.minHoldMs > emotion.maxHoldMs) {
      issues.push({ path: `emotions.${name}`, message: "minHoldMs must be <= maxHoldMs" });
    }
  }
  if (manifest.idle.micro.minGapMs >= manifest.idle.micro.maxGapMs) {
    issues.push({ path: "idle.micro", message: "minGapMs must be < maxGapMs" });
  }
  const { poses, gestures, breakMs } = manifest.talk;
  if (poses.length > 0 || gestures.length > 0) {
    if (manifest.canvas.width !== 240 || manifest.facialRegions) {
      issues.push({ path: "talk.poses", message: "speaking poses require a 240px pack without facial regions" });
    }
    if (poses.length === 0 || gestures.length === 0) {
      issues.push({ path: "talk.gestures", message: "speaking poses need at least one pose and one gesture" });
    }
    const poseIds = new Set(["upright"]);
    for (const [index, pose] of poses.entries()) {
      if (poseIds.has(pose.id)) issues.push({ path: `talk.poses[${index}].id`, message: "pose ids must be unique and not \"upright\"" });
      poseIds.add(pose.id);
      if (pose.stages.length !== manifest.talk.stages.length) {
        issues.push({ path: `talk.poses[${index}].stages`, message: `expected ${manifest.talk.stages.length} frames, one per talk stage` });
      }
    }
    const gestureIds = new Set<string>();
    for (const [index, gesture] of gestures.entries()) {
      if (gestureIds.has(gesture.id)) issues.push({ path: `talk.gestures[${index}].id`, message: "gesture ids must be unique" });
      gestureIds.add(gesture.id);
      for (const [step, entry] of gesture.path.entries()) {
        if (!poseIds.has(entry.pose)) issues.push({ path: `talk.gestures[${index}].path[${step}].pose`, message: `unknown pose "${entry.pose}"` });
      }
      if (gesture.path[0]!.pose !== "upright" || gesture.path[gesture.path.length - 1]!.pose !== "upright") {
        issues.push({ path: `talk.gestures[${index}].path`, message: "a gesture starts and ends upright" });
      }
    }
    if (gestures.length > 0 && !gestures.some((gesture) => gesture.automatic)) {
      issues.push({ path: "talk.gestures", message: "at least one gesture must be automatic" });
    }
    if (breakMs.minMs > breakMs.maxMs) issues.push({ path: "talk.breakMs", message: "minMs must be <= maxMs" });
  }
  const performanceIds = new Set<string>();
  for (const [index, performance] of manifest.idle.performances.entries()) {
    if (performanceIds.has(performance.id)) {
      issues.push({ path: `idle.performances[${index}].id`, message: "performance ids must be unique" });
    }
    performanceIds.add(performance.id);
  }
  const actionIds = new Set<string>();
  const loopActions: Array<{ index: number; action: z.infer<typeof actionSchema> }> = [];
  for (const [index, action] of manifest.actions.entries()) {
    if(action.activation.kind==="manual"&&(manifest.canvas.width!==240||action.plane!=="base")) issues.push({path:`actions[${index}]`,message:"manual actions require a 240px base plane"});
    if (actionIds.has(action.id)) issues.push({ path: `actions[${index}].id`, message: "action ids must be unique" });
    actionIds.add(action.id);
    if (action.activation.kind === "ambient-loop") {
      for (const previous of loopActions) {
        if (previous.action.plane !== action.plane) continue;
        const statesOverlap = action.activation.states.some((value) => previous.action.activation.states.includes(value));
        const expressionsOverlap = action.activation.expressions.some((value) => previous.action.activation.expressions.includes(value));
        const aPerformances = action.activation.performances;
        const bPerformances = previous.action.activation.performances;
        const performancesOverlap = aPerformances.length === 0 || bPerformances.length === 0 ||
          aPerformances.some((value) => bPerformances.includes(value));
        if (statesOverlap && expressionsOverlap && performancesOverlap) {
          issues.push({ path: `actions[${index}].plane`, message: `ambient-loop overlaps actions[${previous.index}] on ${action.plane}` });
        }
      }
      loopActions.push({ index, action });
    }
    for (const [performanceIndex, performance] of action.activation.performances.entries()) {
      if (!performanceIds.has(performance)) {
        issues.push({ path: `actions[${index}].activation.performances[${performanceIndex}]`, message: `unknown idle performance "${performance}"` });
      }
    }
    if (action.activation.performances.length > 0 && !action.activation.states.includes("idle")) {
      issues.push({ path: `actions[${index}].activation.states`, message: "performance-bound actions must include idle" });
    }
    if (action.plane === "base" && action.semantic === "signature" && action.activation.kind !== "ambient-event" && action.activation.kind !== "manual") {
      issues.push({ path: `actions[${index}]`, message: "base signature actions must be ambient-event" });
    }
    if (action.essential && action.activation.kind !== "semantic") {
      issues.push({ path: `actions[${index}].essential`, message: "only semantic actions may be essential" });
    }
  }
  if (manifest.effectProfile) {
    if (!manifest.facialRegions) {
      issues.push({ path: "effectProfile", message: "effectProfile requires character-specific facialRegions" });
    }
    for (const [role, override] of Object.entries(manifest.effectProfile.overrides)) {
      if (!actionIds.has(override.actionId)) {
        issues.push({ path: `effectProfile.overrides.${role}.actionId`, message: "custom override action does not exist" });
      }
    }
    for (const [index, actionId] of manifest.effectProfile.additionalEffects.entries()) {
      if (!actionIds.has(actionId)) {
        issues.push({ path: `effectProfile.additionalEffects[${index}]`, message: "additional effect action does not exist" });
      }
    }
  }
  if (manifest.schemaVersion === 1 && manifest.actions.length > 0) {
    issues.push({ path: "schemaVersion", message: "actions require schemaVersion 2" });
  }
  if (manifest.facialRegions && manifest.schemaVersion < 3) {
    issues.push({ path: "schemaVersion", message: "facialRegions require schemaVersion 3 or 4" });
  }
  if (manifest.schemaVersion === 3 && !manifest.facialRegions) {
    issues.push({ path: "facialRegions", message: "schemaVersion 3 requires facialRegions" });
  }
  if (manifest.schemaVersion < 4) {
    for (const [name, emotion] of Object.entries(manifest.emotions)) {
      if ("enterSteps" in emotion) {
        issues.push({ path: `emotions.${name}`, message: "detailed enter/hold/exit emotions require schemaVersion 4" });
      }
    }
    for (const [index, action] of manifest.actions.entries()) {
      if ("enterSteps" in action) {
        issues.push({ path: `actions[${index}]`, message: "detailed enter/hold/exit actions require schemaVersion 4" });
      }
    }
  }
  if (manifest.facialRegions) {
    const roles = new Set<string>();
    for (const [index, group] of manifest.facialRegions.groups.entries()) {
      if (roles.has(group.role)) issues.push({ path: `facialRegions.groups[${index}].role`, message: "facial group roles must be unique" });
      roles.add(group.role);
      for (const [part, rect] of [["mouth", group.mouth.rect], ["eyes", group.eyes.rect]] as const) {
        if (rect.x + rect.width > manifest.canvas.width || rect.y + rect.height > manifest.canvas.height) issues.push({ path: `facialRegions.groups[${index}].${part}.rect`, message: "rectangle exceeds canvas" });
      }
      const a = group.mouth.rect, b = group.eyes.rect;
      if (a.x < b.x+b.width && a.x+a.width > b.x && a.y < b.y+b.height && a.y+a.height > b.y) issues.push({ path: `facialRegions.groups[${index}]`, message: "mouth and eye rectangles overlap" });
    }
    for (const role of FACIAL_GROUP_ROLES) if (!roles.has(role)) issues.push({ path: "facialRegions.groups", message: `missing required ${role} group` });
    const ranges = [manifest.facialRegions.blink.gaps.full, manifest.facialRegions.blink.gaps.balanced, manifest.facialRegions.blink.gaps.reduced, manifest.facialRegions.pose.full.gap, manifest.facialRegions.pose.full.hold, manifest.facialRegions.pose.balanced.gap, manifest.facialRegions.pose.balanced.hold];
    if (ranges.some((range) => range.minMs >= range.maxMs)) issues.push({ path: "facialRegions", message: "all timing ranges require minMs < maxMs" });
  }
  if (manifest.motion.maxParallaxPx > 0 && !manifest.motion.parallaxSafe) {
    issues.push({ path: "motion", message: "maxParallaxPx requires parallaxSafe" });
  }
  return { manifest, issues };
}
