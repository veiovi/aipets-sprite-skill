/**
 * Binary format constants for `.aipetframes` packs — the full-frame animation
 * system. This file is the single source of truth for the layout; the C loader
 * in firmware/components/frame_player mirrors it field for field.
 *
 * The format is independent from the V1 `.aipetface` layer format on purpose:
 * the two systems coexist on device and neither parses the other. The only
 * deliberate overlap is `fileLength` at byte offset 16, so slot-peek code can
 * read a declared length without knowing the magic.
 *
 * All integers little-endian. All sections start 4-byte aligned. The C loader
 * reads every multi-byte field byte-wise, so alignment is a convenience, not a
 * requirement.
 */

export const FRAME_PACK_MAGIC = new Uint8Array([0x41, 0x49, 0x50, 0x46, 0x52, 0x41, 0x4d, 0x45]); // "AIPFRAME"
export const FRAME_PACK_VERSION = 1;
export const FRAME_PACK_VERSION_240 = 2;
export const FRAME_PACK_CANVAS_240 = 240;
export const FRAME_PACK_MAX_FRAMES_240 = 2048;
export const FRAME_PACK_MAX_ACTIONS_240 = 72; // 64 movements + eight effects
/** Format ceiling; compilation additionally requires the selected layout capacity. */
export const FRAME_PACK_MAX_BYTES_240 = 0xbc0000 - 0x2000;
export const FRAME_PACK_HEADER_BYTES = 128;
export const FRAME_PACK_CANVAS = 120;
export const FRAME_PACK_PIXELS = FRAME_PACK_CANVAS * FRAME_PACK_CANVAS; // 14,400
export const FRAME_PACK_TICK_MS = 33;
export const FRAME_PACK_MAX_PALETTE = 256;
export const FRAME_PACK_MAX_FRAMES = 640;
export const FRAME_PACK_MAX_CLIPS = 256;
export const FRAME_PACK_MAX_CLIP_STEPS = 256;
export const FRAME_PACK_MAX_OVERLAYS = 32;
/** Fixed C arena caps — the C loader rejects packs above these, so must we. */
export const FRAME_PACK_MAX_EMOTIONS = 32;
/** Expression masks are 16 bits: bit 0 is neutral, bits 1..15 are emotion ids. */
export const FRAME_PACK_MAX_EMOTION_ID = 15;
export const FRAME_PACK_MAX_MICRO = 16;
/** Hard ceiling: one V1 asset slot, so slot/OTA delivery stays possible. */
export const FRAME_PACK_MAX_BYTES = 0x2a0000; // 2,752,512

/** Frame codecs (frame directory `codec` byte). */
export const FRAME_CODEC_INDEX8_FULL = 0; // flat u8 palette-index map, exactly 14,400 bytes
/** x,y,w,h + one-bit alpha mask + palette bytes for set mask bits. */
export const FRAME_CODEC_INDEX8_MASKED_RECT = 1;
/** x,y,w,h followed by w*h opaque palette indices. */
export const FRAME_CODEC_INDEX8_DENSE_RECT = 2;
/** Pairs of [runLength, paletteIndex], with runLength in 1..255. */
export const FRAME_CODEC_INDEX8_FULL_RLE = 3;
/** Masked-rect header + alpha mask + RLE palette-index pairs for opaque pixels. */
export const FRAME_CODEC_INDEX8_MASKED_RECT_RLE = 4;
/** Format v2 only: independent zlib-wrapped streams, <=32 KiB window, no dictionary. */
export const FRAME_CODEC_INDEX8_FULL_ZLIB = 5;
export const FRAME_CODEC_INDEX8_MASKED_RECT_ZLIB = 6;
export const FRAME_CODEC_INDEX8_DENSE_RECT_ZLIB = 7;

/** Header flags. Bit zero existed in the original format. */
export const FRAME_FLAG_APPROVED = 1 << 0;
export const FP_FEATURE_OVERLAY_ACTIONS = 1 << 1;
export const FP_FEATURE_FACIAL_REGIONS = 1 << 2;
/** Action directory bytes 20..21 contain an optional authored enter clip. */
export const FP_FEATURE_ACTION_LIFECYCLE = 1 << 3;
/** Action directory bytes 22..23 contain an idle-performance eligibility mask. */
export const FP_FEATURE_PERFORMANCE_ACTIONS = 1 << 4;
/** A speaking-poses section: complete speech frames for several head/eye poses
 * and the gestures that move between them (240px packs, not facial). */
export const FP_FEATURE_SPEAKING_POSES = 1 << 5;
export const ACTION_FLAG_CENTER_ONLY = 1 << 4;
export const FACIAL_SECTION_VERSION = 1;
export const FACIAL_HEADER_BYTES = 56;
export const FACIAL_GROUP_BYTES = 36;
/** A facial group carries seven mouth replacements, indexed by talk stage. */
export const FACIAL_MOUTH_STAGES = 7;
export const FACIAL_GROUP_ROLES = ["center", "left-onset", "left-hold", "right-onset", "right-hold"] as const;

/** Fixed presentation planes. Base is opaque; all other planes are hard-alpha. */
export const ACTION_PLANES = ["base", "characterFx", "stateFx", "gestureFx", "touchFx"] as const;
export const ACTION_PLANE_CODES = Object.fromEntries(ACTION_PLANES.map((name, index) => [name, index])) as Record<
  (typeof ACTION_PLANES)[number],
  number
>;

export const ACTIVATION_KINDS = ["semantic", "ambient-loop", "ambient-event", "manual"] as const;
export const ACTIVATION_CODES = Object.fromEntries(ACTIVATION_KINDS.map((name, index) => [name, index])) as Record<
  (typeof ACTIVATION_KINDS)[number],
  number
>;

export const ACTION_SEMANTICS = [
  "touch",
  "listening",
  "thinking",
  "speaking",
  "shake",
  "tilt-left",
  "tilt-right",
  "tilt-up",
  "tilt-down",
  "signature",
  "booting",
  "provisioning",
  "connecting",
  "offline",
  "error",
  "gesture-nod",
  "gesture-focus",
  "gesture-heartbeat",
  "gesture-bounce",
  "gesture-wobble",
  "gesture-pop",
] as const;
export const ACTION_SEMANTIC_CODES = Object.fromEntries(
  ACTION_SEMANTICS.map((name, index) => [name, index]),
) as Record<(typeof ACTION_SEMANTICS)[number], number>;

export const ANIMATION_PROFILES = ["full", "balanced", "reduced"] as const;
export const PROFILE_BITS = { full: 1 << 1, balanced: 1 << 2, reduced: 1 << 3 } as const;
export const ACTION_FLAG_ESSENTIAL = 1 << 0;
export const ACTION_FLAG_PROFILE_MASK = PROFILE_BITS.full | PROFILE_BITS.balanced | PROFILE_BITS.reduced;
export const ACTION_NO_CLIP = 0xffff;

/** Clip loop modes. */
export const LOOP_ONCE = 0;
export const LOOP_LOOP = 1;
export const LOOP_HOLD_LAST = 2;

/**
 * Fixed-position role table: 8 u16 clip indices, 0xFFFF = absent.
 * Firmware selects behavior by role slot, never by string matching.
 */
export const ROLE_IDLE_NEUTRAL = 0; // required
export const ROLE_IDLE_BLINK = 1;
export const ROLE_BOOTING = 2;
export const ROLE_OFFLINE = 3;
export const ROLE_ERROR = 4;
export const ROLE_LISTENING_BASE = 5;
export const ROLE_THINKING_BASE = 6;
export const ROLE_RESERVED_7 = 7;
export const ROLE_COUNT = 8;
export const ROLE_ABSENT = 0xffff;

/**
 * Stable emotion IDs (u8). Alphabetical at format birth; append-only forever.
 * These are the IDs the firmware's `fp_emotion_t` mirrors (0 = neutral is a
 * player concept, not a pack entry).
 */
export const EMOTION_IDS: Record<string, number> = {
  angry: 1,
  confused: 2,
  determined: 3,
  disgust: 4,
  embarrassed: 5,
  fear: 6,
  joy: 7,
  sad: 8,
  sleepy: 9,
  surprised: 10,
  curious: 11,
  concerned: 12,
  excited: 13,
  shy: 14,
};
export const EMOTION_NAMES: string[] = Object.keys(EMOTION_IDS);

/** Audio level domain for the talk look-up table (inclusive). */
export const TALK_LEVEL_MAX = 100;
export const TALK_LUT_BYTES = TALK_LEVEL_MAX + 1; // 101 entries

/** Record sizes (bytes). */
export const FRAME_DIR_ENTRY_BYTES = 12;
export const CLIP_DIR_ENTRY_BYTES = 16;
export const CLIP_STEP_BYTES = 4;
export const ROLES_TABLE_BYTES = ROLE_COUNT * 2;
export const EMOTION_ENTRY_BYTES = 20;
export const IDLE_PARAMS_BYTES = 16;
export const MICRO_ENTRY_BYTES = 4;
export const OVERLAY_DIR_ENTRY_BYTES = 24;

/** Header field offsets (bytes). */
export const HDR_MAGIC = 0; // u8[8]
export const HDR_VERSION = 8; // u16
export const HDR_HEADER_BYTES = 10; // u16
export const HDR_CANVAS_W = 12; // u16
export const HDR_CANVAS_H = 14; // u16
export const HDR_FILE_LENGTH = 16; // u32 (same offset as V1 .aipetface totalBytes)
export const HDR_PAYLOAD_CRC32 = 20; // u32 over bytes [128, fileLength)
export const HDR_HEADER_CRC32 = 24; // u32 over header with bytes 24..27 zeroed
export const HDR_FLAGS = 28; // u16, bit0 = approved
export const HDR_TICK_MS = 30; // u16, must be 33
export const HDR_PALETTE_OFFSET = 32; // u32
export const HDR_PALETTE_COUNT = 36; // u16
export const HDR_BG_PALETTE_INDEX = 38; // u8
export const HDR_GENDER = 39; // u8 (0 unspecified, 1 neutral, 2 female, 3 male — V1 encoding)
export const HDR_FRAME_DIR_OFFSET = 40; // u32
export const HDR_FRAME_COUNT = 44; // u16
export const HDR_CLIP_COUNT = 46; // u16
export const HDR_CLIP_DIR_OFFSET = 48; // u32
export const HDR_ROLES_OFFSET = 52; // u32
export const HDR_EMOTIONS_OFFSET = 56; // u32
export const HDR_EMOTION_COUNT = 60; // u16
export const HDR_OVERLAY_COUNT = 62; // u16
export const HDR_TALK_OFFSET = 64; // u32
export const HDR_OVERLAY_DIR_OFFSET = 68; // u32
export const HDR_IDLE_OFFSET = 72; // u32
export const HDR_STRINGS_OFFSET = 76; // u32
export const HDR_STRINGS_LENGTH = 80; // u32
export const HDR_META_OFFSET = 84; // u32
export const HDR_META_LENGTH = 88; // u32
export const HDR_ID_STR_OFFSET = 92; // u32
export const HDR_NAME_STR_OFFSET = 96; // u32
export const HDR_VERSION_STR_OFFSET = 100; // u32
export const HDR_ID_STR_LEN = 104; // u16
export const HDR_NAME_STR_LEN = 106; // u16
export const HDR_VERSION_STR_LEN = 108; // u16
export const HDR_FACIAL_OFFSET = 110; // u32, zero when feature absent
export const HDR_FACIAL_LENGTH = 114; // u32, zero when feature absent
export const HDR_SPEAKING_OFFSET = 118; // u32, zero when feature absent
export const HDR_SPEAKING_LENGTH = 122; // u16, zero when feature absent
// bytes 124..127 reserved, must be zero

/*
 * Speaking-poses section (FP_FEATURE_SPEAKING_POSES), little-endian:
 *   0 u8 version, 1 u8 pose count P, 2 u8 stage count (= talk stages),
 *   3 u8 gesture count G, 4 u8 automatic-gesture mask, 5 u8 reserved,
 *   6 u16 minimum break ticks, 8 u16 maximum break ticks, 10 u16 reserved,
 *  12 P x stages x u16 frames (pose-major; pose 0 is the talk table),
 *     padded to 4 bytes, then G x 20-byte gestures: u8 kind, u8 step count,
 *     then (u8 pose, u8 ticks) per step, zero-padded. A gesture starts and
 *     ends at pose 0.
 */
export const SPEAKING_SECTION_VERSION = 1;
export const SPEAKING_HEADER_BYTES = 12;
export const SPEAKING_GESTURE_BYTES = 20;
export const SPEAKING_MIN_POSES = 2;
export const SPEAKING_MAX_POSES = 16;
export const SPEAKING_MAX_GESTURES = 8;
export const SPEAKING_MIN_GESTURE_STEPS = 2;
export const SPEAKING_MAX_GESTURE_STEPS = 8;
export const SPEAKING_MAX_BREAK_TICKS = 900;
export const SPEAKING_GESTURE_KINDS = ["other", "look-left", "look-right", "look-up", "blink", "nod", "tilt", "lean"] as const;
/** Subtle speaking movement: while talking, the whole character drifts to a
 * new whole-pixel target within +/-2px every 90..180 ticks (3-6 s). */
export const SPEAKING_DRIFT_PX = 2;
export const SPEAKING_DRIFT_MIN_TICKS = 90;
export const SPEAKING_DRIFT_MAX_TICKS = 180;

/** Gender codes (mirror V1 so voice gating logic can be shared). */
export const GENDER_CODES: Record<string, number> = {
  unspecified: 0,
  neutral: 1,
  female: 2,
  male: 3,
};
