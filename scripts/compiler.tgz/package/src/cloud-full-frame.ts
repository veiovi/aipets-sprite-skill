/** Full-frame authoring adapter. Uses the canonical compiler and portable player. */
import {createHash} from "node:crypto";
import {mkdtempSync,writeFileSync,rmSync} from "node:fs";
import {tmpdir} from "node:os";
import {join} from "node:path";
import {PNG} from "pngjs";
import {z} from "zod";
import {compileCharacter} from "./compiler.js";
import {canonicalJson,parseFramePack} from "./binary.js";
import {FRAME_PACK_MAX_BYTES_240,EMOTION_IDS,SPEAKING_GESTURE_KINDS} from "./constants.js";
import {FramePlayer} from "./player.js";
import {WasmFramePlayer} from "./wasm-player.js";
import {bundledFramePlayerWasm} from "./cloud-animation-bundle.js";

const hash=z.string().regex(/^[a-f0-9]{64}$/),id=z.string().regex(/^[a-z][a-z0-9-]{0,62}$/);
const image=z.object({sha256:hash}).strict();
const step=z.object({image,durationMs:z.number().int().min(33).max(60000)}).strict();
const states=["booting","provisioning","connecting","idle","listening","thinking","speaking","offline","error"] as const;
const motionRoles=["foundation/idle-breathing",...states.filter(s=>s!=="idle"&&s!=="speaking").map(s=>`states/${s}`),
 "physical/touch-tap","physical/shake","physical/tilt-left","physical/tilt-right","physical/tilt-forward-up","physical/tilt-backward-down",
 "signature/signature-performance",...Object.keys(EMOTION_IDS).map(s=>`expressions/${s}`)] as [string,...string[]];
const clip=z.object({id,role:z.enum(motionRoles),sourceFingerprint:hash,mode:z.enum(["once","loop","ping-pong","hold-last"]),
 steps:z.array(step).min(1).max(256),enter:z.array(step).max(32).default([]),exit:z.array(step).max(32).default([])}).strict();
const effect=z.object({id,role:z.enum([...states,"touch","signature"]),plane:z.enum(["stateFx","characterFx","gestureFx","touchFx"]),
 sourceFingerprint:hash,steps:z.array(step).min(1).max(64),loop:z.boolean().default(true)}).strict();
export const fullFrameInputSchema=z.object({
 version:z.literal(4),presentation:z.literal("full-frame"),resolution:z.literal(240),
 id,name:z.string().trim().min(1).max(48),packVersion:z.string().regex(/^\d+\.\d+\.\d+$/),
 sourceHash:hash,approvalHash:hash.nullable(),readiness:z.enum(["candidate","approved-source"]),
 neutral:image,talk:z.object({frames:z.array(image).min(2).max(16),levelBreakpoints:z.array(z.number().int().min(0).max(100)).min(2).max(16),
  // Optional speaking poses (schema.ts talk.poses/gestures/breakMs); absent keeps existing inputs and evidence unchanged.
  poses:z.array(z.object({id,frames:z.array(image).min(2).max(16)}).strict()).max(15).optional(),
  gestures:z.array(z.object({id,kind:z.enum(SPEAKING_GESTURE_KINDS),automatic:z.boolean().default(true),
   path:z.array(z.object({pose:z.string().min(1),durationMs:z.number().int().min(33).max(255*33)}).strict()).min(2).max(8)}).strict()).max(8).optional(),
  breakMs:z.object({minMs:z.number().int().min(33).max(29700),maxMs:z.number().int().min(33).max(29700)}).strict().optional()}).strict(),
 motions:z.array(clip).max(64),effects:z.array(effect).max(8).default([]),
 protectedRegions:z.array(z.object({x:z.number().int().min(0).max(239),y:z.number().int().min(0).max(239),width:z.number().int().min(1).max(240),height:z.number().int().min(1).max(240)}).strict()).max(8).default([]),
 maxBytes:z.number().int().min(1024).max(FRAME_PACK_MAX_BYTES_240),slotCapacityBytes:z.number().int().min(1024).max(FRAME_PACK_MAX_BYTES_240),
}).strict().superRefine((v,c)=>{
 const fail=(message:string)=>c.addIssue({code:"custom",message});
 if(v.maxBytes>v.slotCapacityBytes)fail("Review budget exceeds device capacity");
 if(v.readiness==="approved-source"&&!v.approvalHash)fail("Approved source requires an approval receipt");
 if(v.sourceHash!==v.neutral.sha256||v.talk.frames[0]?.sha256!==v.neutral.sha256)fail("Stage zero must be the canonical neutral");
 if(v.talk.frames.length!==v.talk.levelBreakpoints.length||v.talk.levelBreakpoints[0]!==0||v.talk.levelBreakpoints.some((n,i)=>i>0&&n<=v.talk.levelBreakpoints[i-1]!))fail("Speech thresholds must increase from zero, one per frame");
 if(new Set([...v.motions,...v.effects].map(a=>a.id)).size!==v.motions.length+v.effects.length||new Set(v.motions.map(a=>a.role)).size!==v.motions.length||new Set(v.effects.map(a=>a.role)).size!==v.effects.length)fail("Duplicate action or role");
 if(v.effects.length&&!v.protectedRegions.length)fail("Effects require reviewed facial guards");
 if(v.protectedRegions.some(r=>r.x+r.width>240||r.y+r.height>240))fail("Facial guard exceeds canvas");
 if(v.effects.some(e=>e.role==="touch"?e.plane!=="touchFx":e.plane==="touchFx"))fail("Touch effects must own the touch plane");
 if(v.effects.some(e=>e.role==="touch"&&e.loop))fail("Touch effects must finish after one tap");
 if(v.effects.some(e=>["idle","signature"].includes(e.role)?e.plane!=="characterFx":e.role!=="touch"&&e.plane!=="stateFx"))fail("State effects use stateFx; ambient effects use characterFx");
 // The existing player deliberately finishes action exits after activation
 // clears. A base exit would therefore obscure audio-reactive speech. Keep
 // continuous sprite actions immediately interruptible; one-shot phases are
 // flattened, preserving every authored step without changing the runtime.
 if(v.motions.some(m=>!m.role.startsWith("expressions/")&&m.mode!=="once"&&(m.enter.length||m.exit.length)))fail("Continuous full-frame actions cannot have separate phases; use a looping sequence or a phased one-shot");
 if(v.motions.some(m=>["physical/touch-tap","physical/shake"].includes(m.role)&&m.mode!=="once"))fail("Touch and shake reactions must be one-shot");
});
export type FullFrameInput=z.infer<typeof fullFrameInputSchema>;
const sha=(v:Uint8Array|string)=>createHash("sha256").update(v).digest("hex");
const encode=(p:PNG)=>PNG.sync.write(p,{filterType:4,deflateLevel:9});
export function fullFrameTimeline(steps:readonly z.infer<typeof step>[],mode:string){
 const ordered=mode==="ping-pong"&&steps.length>2?[...steps,...steps.slice(1,-1).reverse()]:[...steps];
 let elapsed=0,used=0;
 return ordered.map(s=>{elapsed+=s.durationMs;const ticks=Math.max(1,Math.round(elapsed/33)-used);used+=ticks;return{...s,durationMs:ticks*33};});
}
export function compileCloudFullFramePack(raw:unknown,artifacts:ReadonlyMap<string,Uint8Array>,options:{compilerCommit:string;compilerVersion:string;compilerPackageSha256?:string;wasmBytes?:Uint8Array;emitPreviews?:boolean}){
 const input=fullFrameInputSchema.parse(raw);
 if(!/^[a-f0-9]{40}$/.test(options.compilerCommit)||options.compilerPackageSha256!==undefined&&!hash.safeParse(options.compilerPackageSha256).success)throw Error("DEVICE_COMPILER_PROVENANCE_INVALID");
 const root=mkdtempSync(join(tmpdir(),"sprite-pet-compile-")),files:Record<string,{sha256:string;bytes:number}>={},saved=new Map<string,string>();
 try{
  const source=(ref:z.infer<typeof image>,overlay=false)=>{
   const bytes=artifacts.get(ref.sha256);if(!bytes||sha(bytes)!==ref.sha256)throw Error("DEVICE_INPUT_HASH_MISMATCH");
   // Native normalization owns framing. Do not crop, resize or register again.
   if(bytes.length>4*1024*1024||bytes.length<24||Buffer.from(bytes).readUInt32BE(16)!==240||Buffer.from(bytes).readUInt32BE(20)!==240)throw Error("DEVICE_SOURCE_DIMENSIONS_INVALID");
   const p=PNG.sync.read(Buffer.from(bytes));
   for(let i=0;i<p.data.length;i+=4){const alpha=p.data[i+3]!;
    if(!overlay&&alpha!==255)throw Error("DEVICE_FULL_FRAME_NOT_OPAQUE");
    if(overlay){if(alpha!==0&&alpha!==255)throw Error("DEVICE_EFFECT_ALPHA_INVALID");
     if(alpha===0&&(p.data[i]||p.data[i+1]||p.data[i+2]))throw Error("DEVICE_EFFECT_HIDDEN_RGB");
     const x=i/4%240,y=Math.floor(i/4/240);if(alpha&&input.protectedRegions.some(r=>x>=r.x&&x<r.x+r.width&&y>=r.y&&y<r.y+r.height))throw Error("DEVICE_EFFECT_FACE_OVERLAP");}}
   let file=saved.get(ref.sha256);if(!file){file=`frame-${saved.size}.png`;writeFileSync(join(root,file),bytes);files[file]={sha256:ref.sha256,bytes:bytes.length};saved.set(ref.sha256,file);}
   return{file,kind:"device-grid" as const};
  };
  const neutral=source(input.neutral),talk=input.talk.frames.map(f=>source(f));
  const convert=(steps:readonly z.infer<typeof step>[],mode="once",overlay=false)=>fullFrameTimeline(steps,mode).map(s=>({frame:source(s.image,overlay),durationMs:s.durationMs}));
  const actions:any[]=[],emotions:Record<string,unknown>={},mappings:Array<{id:string;role:string;plane:string;state:number|null;emotion:number|null;actionId:string|null}>=[];
  const physical:Record<string,string>={"physical/touch-tap":"touch","physical/shake":"shake","physical/tilt-left":"tilt-left","physical/tilt-right":"tilt-right","physical/tilt-forward-up":"tilt-up","physical/tilt-backward-down":"tilt-down"};
  for(const motion of input.motions){
   const state=motion.role==="foundation/idle-breathing"?"idle":motion.role.startsWith("states/")?motion.role.slice(7):null;
   const emotion=motion.role.startsWith("expressions/")?motion.role.slice(12):null;
   const steps=convert(motion.steps,motion.mode),enter=convert(motion.enter),exit=convert(motion.exit);
   if(emotion){emotions[emotion]={enterSteps:enter.length?enter:[{frame:neutral,durationMs:33}],holdSteps:steps,exitSteps:exit.length?exit:[{frame:neutral,durationMs:33}],holdMode:motion.mode==="hold-last"||motion.mode==="once"?"hold-last":"loop",minHoldMs:0,maxHoldMs:7000,microWeight:0};}
   else{
    const semantic=physical[motion.role]??(state==="idle"?"gesture-heartbeat":state??"signature");
    const base={id:motion.id,semantic,plane:"base",priority:state==="idle"?10:100,essential:!!state&&state!=="idle"||semantic==="touch",profiles:["full","balanced","reduced"],cooldownMs:0,
     // A full-frame gesture cannot replace the amplitude bank during speech.
     activation:{kind:state==="idle"?"ambient-loop":state||physical[motion.role]?"semantic":"manual",states:state?[state]:["idle","listening","thinking"],expressions:["neutral"]}};
    actions.push({...base,steps:[...enter,...steps,...exit],loop:motion.mode==="ping-pong"?"loop":motion.mode});
   }
   mappings.push({id:motion.id,role:motion.role,plane:"base",state:state?states.indexOf(state as typeof states[number]):null,emotion:emotion?EMOTION_IDS[emotion]!:null,actionId:emotion?null:motion.id});
  }
  for(const effect of input.effects){
   const ambient=effect.role==="idle"||effect.role==="signature",semantic=ambient?"gesture-heartbeat":effect.role;
   actions.push({id:effect.id,semantic,plane:effect.plane,priority:100,essential:!ambient,profiles:["full","balanced","reduced"],cooldownMs:0,
    activation:{kind:ambient?"ambient-loop":"semantic",states:effect.role==="touch"?["idle","listening","thinking","speaking"]:ambient?["idle"]:[effect.role],expressions:["neutral"]},steps:convert(effect.steps,"once",true),loop:effect.loop?"loop":"once"});
   mappings.push({id:effect.id,role:effect.role,plane:effect.plane,state:states.includes(effect.role as any)?states.indexOf(effect.role as any):null,emotion:null,actionId:effect.id});
  }
  const manifest={schemaVersion:5,id:input.id,name:input.name,version:input.packVersion,canvas:{width:240,height:240},budgetBytes:input.maxBytes,slotCapacityBytes:input.slotCapacityBytes,
   neutral,talk:{stages:talk,levelBreakpoints:input.talk.levelBreakpoints,
    poses:(input.talk.poses??[]).map(pose=>({id:pose.id,stages:pose.frames.map(f=>source(f))})),
    gestures:input.talk.gestures??[],...(input.talk.breakMs?{breakMs:input.talk.breakMs}:{})},emotions,actions,
   idle:{bob:{amplitudePx:0,periodMs:3168},micro:{minGapMs:120000,maxGapMs:120100,onsetTicks:5},performances:[]},
   provenance:{origin:{repoBranch:"cloud-full-frame",commit:options.compilerCommit},publicationRights:"Private experimental sprite pet; not Studio Complete."},
   approval:{status:input.readiness==="candidate"?"pending":"approved",...(input.readiness==="candidate"?{}:{approvedBy:"cloud-device-compiler",approvedAt:"1970-01-01T00:00:00.000Z"}),notes:"Exact compiled bytes require separate human approval; source receipt: "+(input.approvalHash??"pending")}};
  writeFileSync(join(root,"character.json"),JSON.stringify(manifest));writeFileSync(join(root,"SOURCES.lock.json"),JSON.stringify({files}));
  const compiled=compileCharacter(root,"character.json",{reviewCandidate:true,preserveDevicePixels:true});
  if(compiled.pack.length>input.maxBytes)throw Error("DEVICE_PACK_TOO_LARGE");
  const pack=parseFramePack(compiled.pack),wasm=options.wasmBytes??bundledFramePlayerWasm();
  const trace:Array<{profile:number;tick:number;state:number;audio:number;actions:number[];crc32:number}>=[],previews:Array<{role:string;png:Uint8Array}>=[];
  for(let profile=0;profile<3;profile++){
   const ts=new FramePlayer(pack,424242),c=WasmFramePlayer.create(wasm,compiled.pack,424242);ts.setAnimationProfile(profile);c.setAnimationProfile(profile);
   for(let tick=0;tick<384;tick++){
    const state=tick<24?0:tick<48?1:tick<72?2:tick<120?3:tick<150?4:tick<180?5:tick<310?6:tick<330?3:tick<354?7:8;
    const audio=state===6?tick>=294?0:Math.min(100,Math.floor((tick-180)/7)*7):0;
    ts.setSysState(state);c.setSysState(state);ts.setAudioLevel(audio);c.setAudioLevel(audio);
    if(tick===100||tick===165||tick===240){ts.notifyTouch();c.notifyTouch();}
    ts.tick();c.tick();if(ts.frameCrc32()!==c.frameCrc32())throw Error(`DEVICE_RUNTIME_PARITY_FAILED:${profile}:${tick}`);
    const active=Array.from({length:5},(_,p)=>ts.debugActiveAction(p));if(active.some((a,p)=>a!==c.activeAction(p)))throw Error("DEVICE_ACTION_PARITY_FAILED");
    trace.push({profile,tick,state,audio,actions:active,crc32:c.frameCrc32()});
    if(profile===0&&options.emitPreviews!==false){const p=new PNG({width:240,height:240});c.framebuffer().forEach((v,i)=>p.data.set([((v>>11)&31)*255/31,((v>>5)&63)*255/63,(v&31)*255/31,255],i*4));previews.push({role:`tick-${tick}`,png:encode(p)});}
   }
  }
  const evidence={version:1,inputVersion:4,presentation:"full-frame",resolution:240,readiness:input.readiness,
   compiler:{version:options.compilerVersion,commit:options.compilerCommit,wasmSha256:sha(wasm),...(options.compilerPackageSha256?{packageSha256:options.compilerPackageSha256}:{})},
   sourceHash:input.sourceHash,approvalHash:input.approvalHash,selectedInputSha256:sha(canonicalJson(input)),packSha256:sha(compiled.pack),bytes:compiled.pack.length,frameCount:pack.frames.length,
   slotCapacityBytes:input.slotCapacityBytes,movementSampling:null,mappings,facialSources:undefined,movements:input.motions,effects:input.effects.map(e=>({...e,approvalSha256:input.approvalHash})),compositions:[],
   warnings:[input.talk.poses?.length?"Full-frame speaking poses use the canonical director; mouth timing remains independent.":"Eyes and mouth are baked into complete speech frames; no independent speech blink.",...compiled.gates.filter(g=>g.verdict!=="pass").map(g=>g.detail)],gates:compiled.gates,trace};
  return{pack:compiled.pack,sha256:sha(compiled.pack),evidence,evidenceSha256:sha(canonicalJson(evidence)),previews,wasm};
 }finally{rmSync(root,{recursive:true,force:true});}
}
