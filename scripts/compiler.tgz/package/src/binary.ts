import {
  ACTION_FLAG_ESSENTIAL,
  ACTION_FLAG_PROFILE_MASK,
  ACTION_NO_CLIP,
  ACTION_PLANES,
  ACTION_SEMANTICS,
  ACTIVATION_KINDS,
  CLIP_DIR_ENTRY_BYTES,
  CLIP_STEP_BYTES,
  EMOTION_ENTRY_BYTES,
  FRAME_CODEC_INDEX8_FULL,
  FRAME_CODEC_INDEX8_MASKED_RECT,
  FRAME_CODEC_INDEX8_DENSE_RECT,
  FRAME_CODEC_INDEX8_FULL_RLE,
  FRAME_CODEC_INDEX8_MASKED_RECT_RLE,
  FRAME_FLAG_APPROVED,
  FRAME_DIR_ENTRY_BYTES,
  FRAME_PACK_CANVAS,
  FRAME_PACK_HEADER_BYTES,
  FRAME_PACK_MAGIC,
  FRAME_PACK_MAX_BYTES,
  FRAME_PACK_MAX_CLIPS,
  FRAME_PACK_MAX_CLIP_STEPS,
  FRAME_PACK_MAX_EMOTIONS,
  FRAME_PACK_MAX_EMOTION_ID,
  FRAME_PACK_MAX_FRAMES,
  FRAME_PACK_MAX_MICRO,
  FRAME_PACK_MAX_PALETTE,
  FRAME_PACK_PIXELS,
  FRAME_PACK_TICK_MS,
  FRAME_PACK_VERSION,
  FRAME_PACK_VERSION_240,
  FRAME_PACK_MAX_FRAMES_240,
  FRAME_PACK_MAX_ACTIONS_240,
  FRAME_PACK_MAX_BYTES_240,
  FP_FEATURE_OVERLAY_ACTIONS,
  FP_FEATURE_FACIAL_REGIONS,
  FP_FEATURE_ACTION_LIFECYCLE,
  FP_FEATURE_PERFORMANCE_ACTIONS,
  FP_FEATURE_SPEAKING_POSES,
  ACTION_FLAG_CENTER_ONLY,
  FACIAL_SECTION_VERSION,
  FACIAL_HEADER_BYTES,
  FACIAL_GROUP_BYTES,
  FACIAL_MOUTH_STAGES,
  HDR_BG_PALETTE_INDEX,
  HDR_CANVAS_H,
  HDR_CANVAS_W,
  HDR_CLIP_COUNT,
  HDR_CLIP_DIR_OFFSET,
  HDR_EMOTIONS_OFFSET,
  HDR_EMOTION_COUNT,
  HDR_FILE_LENGTH,
  HDR_FLAGS,
  HDR_FRAME_COUNT,
  HDR_FRAME_DIR_OFFSET,
  HDR_GENDER,
  HDR_HEADER_BYTES,
  HDR_HEADER_CRC32,
  HDR_ID_STR_LEN,
  HDR_ID_STR_OFFSET,
  HDR_IDLE_OFFSET,
  HDR_MAGIC,
  HDR_META_LENGTH,
  HDR_META_OFFSET,
  HDR_NAME_STR_LEN,
  HDR_NAME_STR_OFFSET,
  HDR_OVERLAY_COUNT,
  HDR_OVERLAY_DIR_OFFSET,
  HDR_PALETTE_COUNT,
  HDR_PALETTE_OFFSET,
  HDR_PAYLOAD_CRC32,
  HDR_ROLES_OFFSET,
  HDR_STRINGS_LENGTH,
  HDR_STRINGS_OFFSET,
  HDR_TALK_OFFSET,
  HDR_TICK_MS,
  HDR_VERSION,
  HDR_VERSION_STR_LEN,
  HDR_VERSION_STR_OFFSET,
  HDR_FACIAL_OFFSET,
  HDR_FACIAL_LENGTH,
  HDR_SPEAKING_OFFSET,
  HDR_SPEAKING_LENGTH,
  IDLE_PARAMS_BYTES,
  LOOP_HOLD_LAST,
  LOOP_ONCE,
  MICRO_ENTRY_BYTES,
  OVERLAY_DIR_ENTRY_BYTES,
  ROLE_ABSENT,
  ROLE_COUNT,
  ROLE_IDLE_NEUTRAL,
  ROLES_TABLE_BYTES,
  SPEAKING_GESTURE_BYTES,
  SPEAKING_GESTURE_KINDS,
  SPEAKING_HEADER_BYTES,
  SPEAKING_MAX_BREAK_TICKS,
  SPEAKING_MAX_GESTURES,
  SPEAKING_MAX_GESTURE_STEPS,
  SPEAKING_MAX_POSES,
  SPEAKING_MIN_GESTURE_STEPS,
  SPEAKING_MIN_POSES,
  SPEAKING_SECTION_VERSION,
  TALK_LUT_BYTES,
} from "./constants.js";
import { crc32 } from "./crc32.js";
import { decodeZlibResource, isZlibCodec, isFullCodec, isMaskedCodec, isDenseCodec } from "./frame-codec.js";
import { from565, type Rgb } from "./ingest/palette.js";

/** Error codes mirror the C loader's fp_error_t one for one. */
export type FramePackErrorCode =
  | "BAD_MAGIC"
  | "UNSUPPORTED_VERSION"
  | "BAD_HEADER"
  | "BAD_CHECKSUM"
  | "BAD_BOUNDS"
  | "BAD_FRAME"
  | "BAD_CLIP"
  | "BAD_ROLE"
  | "BAD_EMOTION"
  | "BAD_TALK"
  | "BAD_IDLE"
  | "BAD_OVERLAY"
  | "BAD_FACIAL"
  | "BAD_SPEAKING"
  | "TRUNCATED";

export class FramePackError extends Error {
  constructor(
    public readonly code: FramePackErrorCode,
    message: string,
  ) {
    super(`${code}: ${message}`);
    this.name = "FramePackError";
  }
}

export interface ClipStep {
  frame: number;
  durationTicks: number;
}

export interface Clip {
  name: string;
  loopMode: number;
  steps: ClipStep[];
}

export interface EmotionEntry {
  id: number;
  name: string;
  enterClip: number;
  holdClip: number;
  exitClip: number;
  minHoldMs: number;
  maxHoldMs: number;
}

export interface TalkTable {
  stageFrames: number[];
  /** 101 entries, audio level 0..100 -> stage index. */
  levelToStage: Uint8Array;
}

export interface IdleParams {
  bobAmplitudePx: number;
  bobPeriodTicks: number;
  microGapMinTicks: number;
  microGapMaxTicks: number;
  micro: { clip: number; weight: number }[];
  fallbacksEnabled?: boolean;
  parallaxSafe?: boolean;
  maxParallaxPx?: number;
}

export interface FrameResource {
  codec: number;
  data: Uint8Array;
}

export interface ActionEntry {
  id: string;
  semantic: (typeof ACTION_SEMANTICS)[number];
  plane: (typeof ACTION_PLANES)[number];
  activationKind: (typeof ACTIVATION_KINDS)[number];
  clip: number;
  enterClip?: number;
  exitClip: number;
  priority: number;
  essential: boolean;
  profileMask: number;
  stateMask: number;
  expressionMask: number;
  performanceMask?: number;
  intervalMinTicks: number;
  intervalMaxTicks: number;
  cooldownTicks: number;
  posePolicy?: "screen" | "center-only";
}

export interface FacialRect { x: number; y: number; width: number; height: number }
export interface FacialGroupEntry {
  role: number;
  baseFrame: number;
  mouthRect: FacialRect;
  eyeRect: FacialRect;
  mouthFrames: number[];
  eyeFrames: number[];
}
export interface FacialRegionsEntry {
  /** Facial v2: gaze lives in each base; all five blink images are independent. */
  independentBlink?: boolean;
  /** Facial v2 reuses the pose timing words for center/left/up/right/down dwell. */
  gazeStageTicks?: number[];
  groups: FacialGroupEntry[];
  centerGroup: number;
  blinkStateMask: number;
  blinkGaps: [number, number, number, number, number, number];
  blinkStageTicks: number[];
  poseStateMask: number;
  bobStateMask: number;
  bobFullAmplitude: number;
  bobBalancedAmplitude: number;
  bobPeriodTicks: number;
  poseTimings: [number, number, number, number, number, number, number, number];
}

export interface SpeakingGestureStep { pose: number; ticks: number }
export interface SpeakingGesture {
  kind: (typeof SPEAKING_GESTURE_KINDS)[number];
  /** Starts and ends at pose 0; ticks are 33 ms. */
  steps: SpeakingGestureStep[];
  /** Part of the shuffled rotation that plays between breaks while talking. */
  automatic: boolean;
}
/** Complete speech frames for several head/eye poses, and the gestures that
 * move between them while the pet talks. */
export interface SpeakingPoses {
  /** frames[pose][stage]; row 0 is the talk table. */
  frames: number[][];
  gestures: SpeakingGesture[];
  /** Neutral pause after each automatic gesture, drawn from this range. */
  breakMinTicks: number;
  breakMaxTicks: number;
}

/** The compiler's output model; `writeFramePack` serializes it byte-exactly. */
export interface FramePackModel {
  /** Omitted only for legacy 120px callers. 240px always serializes format v2. */
  canvas?: 120 | 240;
  /** Required for 240px: usable bytes in the selected layout, excluding metadata. */
  maxBytes?: number;
  id: string;
  name: string;
  version: string;
  gender: number;
  approved: boolean;
  palette: Rgb[];
  bgPaletteIndex: number;
  /** Legacy callers may still provide raw full-frame bytes. */
  frames: (Uint8Array | FrameResource)[];
  clips: Clip[];
  /** 8 role slots, each a clip index or ROLE_ABSENT. */
  roles: number[];
  emotions: EmotionEntry[];
  talk: TalkTable;
  idle: IdleParams;
  actions?: ActionEntry[];
  facialRegions?: FacialRegionsEntry;
  speakingPoses?: SpeakingPoses;
  /** Canonical-JSON-serializable provenance blob; device never parses it. */
  meta: unknown;
}

const encoder = new TextEncoder();
const decoder = new TextDecoder();

/** JSON.stringify with recursively sorted object keys — deterministic meta. */
export function canonicalJson(value: unknown): string {
  const sort = (v: unknown): unknown => {
    if (Array.isArray(v)) return v.map(sort);
    if (v && typeof v === "object") {
      const out: Record<string, unknown> = {};
      for (const key of Object.keys(v as Record<string, unknown>).sort()) {
        out[key] = sort((v as Record<string, unknown>)[key]);
      }
      return out;
    }
    return v;
  };
  return JSON.stringify(sort(value));
}

const align4 = (n: number): number => (n + 3) & ~3;

function to565Word([r, g, b]: Rgb): number {
  return (((r >> 3) & 31) << 11) | (((g >> 2) & 63) << 5) | ((b >> 3) & 31);
}

function asFrameResource(frame: Uint8Array | FrameResource): FrameResource {
  return frame instanceof Uint8Array ? { codec: FRAME_CODEC_INDEX8_FULL, data: frame } : frame;
}

function maskedRectInfo(data: Uint8Array, canvas = FRAME_PACK_CANVAS): { x: number; y: number; width: number; height: number; maskBytes: number } {
  if (data.length < 5) throw new Error("masked rectangle is shorter than its header");
  const x = data[0]!;
  const y = data[1]!;
  const width = data[2]!;
  const height = data[3]!;
  if (width < 1 || height < 1 || x + width > canvas || y + height > canvas) {
    throw new Error(`masked rectangle ${x},${y} ${width}x${height} is outside the canvas`);
  }
  const maskBytes = Math.ceil((width * height) / 8);
  if (data.length < 4 + maskBytes) throw new Error("masked rectangle alpha mask is truncated");
  return { x, y, width, height, maskBytes };
}

function validateFrameResource(frame: FrameResource, paletteLength: number, index: number, canvas = FRAME_PACK_CANVAS): void {
  if (isZlibCodec(frame.codec)) {
    if (canvas !== 240) throw new Error("compressed codecs require format v2");
    const codec = frame.codec === 5 ? FRAME_CODEC_INDEX8_FULL : frame.codec === 6 ? FRAME_CODEC_INDEX8_MASKED_RECT : FRAME_CODEC_INDEX8_DENSE_RECT;
    return validateFrameResource({ codec, data: decodeZlibResource(frame.codec, frame.data, canvas) }, paletteLength, index, canvas);
  }
  const pixels = canvas * canvas;
  if (frame.codec === FRAME_CODEC_INDEX8_FULL) {
    if (frame.data.length !== pixels) {
      throw new Error(`frame ${index} must be exactly ${pixels} bytes, got ${frame.data.length}`);
    }
    for (let p = 0; p < frame.data.length; p++) {
      if (frame.data[p]! >= paletteLength) throw new Error(`frame ${index} pixel ${p} palette index out of range`);
    }
    return;
  }
  if (frame.codec === FRAME_CODEC_INDEX8_FULL_RLE) {
    if (frame.data.length < 2 || (frame.data.length & 1) !== 0) throw new Error(`frame ${index} invalid full RLE length`);
    let pixels = 0;
    for (let p = 0; p < frame.data.length; p += 2) {
      const run = frame.data[p]!, color = frame.data[p + 1]!;
      if (run === 0 || color >= paletteLength) throw new Error(`frame ${index} invalid full RLE pair`);
      pixels += run;
    }
    if (pixels !== canvas * canvas) throw new Error(`frame ${index} full RLE expands to ${pixels} pixels`);
    return;
  }
  if (frame.codec === FRAME_CODEC_INDEX8_DENSE_RECT) {
    const x=frame.data[0]!, y=frame.data[1]!, width=frame.data[2]!, height=frame.data[3]!;
    if (frame.data.length < 5 || frame.data.length !== 4 + width*height || !width || !height || x+width>canvas || y+height>canvas) throw new Error(`frame ${index} invalid dense rectangle`);
    for (let p=4;p<frame.data.length;p++) if (frame.data[p]! >= paletteLength) throw new Error(`frame ${index} dense pixel palette index out of range`);
    return;
  }
  if (frame.codec !== FRAME_CODEC_INDEX8_MASKED_RECT && frame.codec !== FRAME_CODEC_INDEX8_MASKED_RECT_RLE) throw new Error(`frame ${index} codec ${frame.codec} unsupported`);
  const { width, height, maskBytes } = maskedRectInfo(frame.data, canvas);
  let opaque = 0;
  for (let p = 0; p < width * height; p++) opaque += (frame.data[4 + (p >> 3)]! >> (p & 7)) & 1;
  if (frame.codec === FRAME_CODEC_INDEX8_MASKED_RECT) {
    if (frame.data.length !== 4 + maskBytes + opaque) throw new Error(`frame ${index} masked payload length does not match ${opaque} opaque pixels`);
    for (let p = 4 + maskBytes; p < frame.data.length; p++) if (frame.data[p]! >= paletteLength) throw new Error(`frame ${index} masked pixel palette index out of range`);
  } else {
    const start = 4 + maskBytes;
    if (frame.data.length <= start || ((frame.data.length - start) & 1) !== 0) throw new Error(`frame ${index} invalid masked RLE length`);
    let pixels = 0;
    for (let p = start; p < frame.data.length; p += 2) {
      const run = frame.data[p]!, color = frame.data[p + 1]!;
      if (run === 0 || color >= paletteLength) throw new Error(`frame ${index} invalid masked RLE pair`);
      pixels += run;
    }
    if (pixels !== opaque) throw new Error(`frame ${index} masked RLE expands to ${pixels}, expected ${opaque}`);
  }
}

function validateSpeakingPoses(speaking: SpeakingPoses, model: FramePackModel, frames: FrameResource[], canvas: number): void {
  if (canvas !== 240 || model.facialRegions) throw new Error("speaking poses require a 240px pack without facial regions");
  const stages = model.talk.stageFrames.length;
  if (speaking.frames.length < SPEAKING_MIN_POSES || speaking.frames.length > SPEAKING_MAX_POSES) {
    throw new Error(`speaking poses need ${SPEAKING_MIN_POSES}..${SPEAKING_MAX_POSES} poses, got ${speaking.frames.length}`);
  }
  for (const [pose, row] of speaking.frames.entries()) {
    if (row.length !== stages) throw new Error(`speaking pose ${pose} needs ${stages} frames, one per talk stage`);
    for (const [stage, frame] of row.entries()) {
      if (!Number.isInteger(frame) || frame < 0 || frame >= frames.length || !isFullCodec(frames[frame]!.codec)) {
        throw new Error(`speaking pose ${pose} stage ${stage} must reference a complete frame`);
      }
      if (pose === 0 && frame !== model.talk.stageFrames[stage]) throw new Error("speaking pose 0 must be the talk table");
    }
  }
  if (speaking.gestures.length < 1 || speaking.gestures.length > SPEAKING_MAX_GESTURES) {
    throw new Error(`speaking poses need 1..${SPEAKING_MAX_GESTURES} gestures`);
  }
  if (!speaking.gestures.some((gesture) => gesture.automatic)) throw new Error("at least one speaking gesture must be automatic");
  for (const [index, gesture] of speaking.gestures.entries()) {
    if (!SPEAKING_GESTURE_KINDS.includes(gesture.kind)) throw new Error(`speaking gesture ${index} kind ${gesture.kind} is unknown`);
    if (gesture.steps.length < SPEAKING_MIN_GESTURE_STEPS || gesture.steps.length > SPEAKING_MAX_GESTURE_STEPS) {
      throw new Error(`speaking gesture ${index} needs ${SPEAKING_MIN_GESTURE_STEPS}..${SPEAKING_MAX_GESTURE_STEPS} steps`);
    }
    for (const step of gesture.steps) {
      if (!Number.isInteger(step.pose) || step.pose < 0 || step.pose >= speaking.frames.length ||
          !Number.isInteger(step.ticks) || step.ticks < 1 || step.ticks > 255) {
        throw new Error(`speaking gesture ${index} has an invalid step`);
      }
    }
    if (gesture.steps[0]!.pose !== 0 || gesture.steps[gesture.steps.length - 1]!.pose !== 0) {
      throw new Error(`speaking gesture ${index} must start and end at pose 0`);
    }
  }
  const { breakMinTicks: min, breakMaxTicks: max } = speaking;
  if (!Number.isInteger(min) || !Number.isInteger(max) || min < 1 || min > max || max > SPEAKING_MAX_BREAK_TICKS) {
    throw new Error(`speaking break must be 1..${SPEAKING_MAX_BREAK_TICKS} ticks`);
  }
}

/** Exact serialized length, measured before allocation. No oversized pack is
 * emitted; selectors may handle only this error, never arbitrary compile failures. */
export class FramePackCapacityError extends Error {
  constructor(readonly bytes:number,readonly capacityBytes:number){
    super(`pack is ${bytes} bytes, exceeding the ${capacityBytes}-byte slot ceiling`);
    this.name="FramePackCapacityError";
  }
}

export function writeFramePack(model: FramePackModel): Uint8Array {
  const canvas = model.canvas ?? 120;
  if (canvas !== 120 && canvas !== 240) throw new Error("unsupported canvas");
  const formatVersion = canvas === 240 ? FRAME_PACK_VERSION_240 : FRAME_PACK_VERSION;
  const formatMaxBytes = canvas === 240 ? FRAME_PACK_MAX_BYTES_240 : FRAME_PACK_MAX_BYTES;
  const maxBytes = model.maxBytes ?? (canvas === 120 ? formatMaxBytes : 0);
  if (!Number.isSafeInteger(maxBytes) || maxBytes < FRAME_PACK_HEADER_BYTES || maxBytes > formatMaxBytes) {
    throw new Error("valid selected layout pack capacity required");
  }
  const maxFrames = canvas === 240 ? FRAME_PACK_MAX_FRAMES_240 : FRAME_PACK_MAX_FRAMES;
  if (model.palette.length < 1 || model.palette.length > FRAME_PACK_MAX_PALETTE) {
    throw new Error(`palette must have 1..${FRAME_PACK_MAX_PALETTE} entries, got ${model.palette.length}`);
  }
  if (model.bgPaletteIndex >= model.palette.length) {
    throw new Error(`bgPaletteIndex ${model.bgPaletteIndex} out of range`);
  }
  if (model.frames.length < 1 || model.frames.length > maxFrames) {
    throw new Error(`frame count must be 1..${maxFrames}, got ${model.frames.length}`);
  }
  const frames = model.frames.map(asFrameResource);
  for (const [i, frame] of frames.entries()) validateFrameResource(frame, model.palette.length, i, canvas);
  const actions = model.actions ?? [];
  if(actions.some(a=>a.activationKind==="manual"&&(canvas!==240||a.plane!=="base")))throw new Error("manual actions require a 240px base plane");
  const hasActionLifecycle = actions.some((action) => (action.enterClip ?? ACTION_NO_CLIP) !== ACTION_NO_CLIP);
  const hasPerformanceActions = actions.some((action) => (action.performanceMask ?? 0) !== 0);
  const facial = model.facialRegions;
  if (facial?.independentBlink && canvas !== 240) throw new Error("independent blink requires format v2");
  if (facial?.independentBlink && facial.gazeStageTicks && (facial.gazeStageTicks.length!==5||facial.gazeStageTicks.some(t=>!Number.isInteger(t)||t<1||t>1818))) throw new Error("invalid five-direction gaze timing");
  if (actions.length > (canvas === 240 ? FRAME_PACK_MAX_ACTIONS_240 : 32)) throw new Error("action count exceeds format limit");
  if (canvas === 240 && (actions.filter(a => a.plane === "base").length > 64 || actions.filter(a => a.plane !== "base").length > 8)) {
    throw new Error("action count exceeds 64 movements/eight effects");
  }
  if (model.clips.length < 1 || model.clips.length > FRAME_PACK_MAX_CLIPS) {
    throw new Error(`clip count must be 1..${FRAME_PACK_MAX_CLIPS}, got ${model.clips.length}`);
  }
  for (const clip of model.clips) {
    if (clip.steps.length < 1 || clip.steps.length > FRAME_PACK_MAX_CLIP_STEPS) {
      throw new Error(`clip "${clip.name}" must have 1..${FRAME_PACK_MAX_CLIP_STEPS} steps`);
    }
    for (const step of clip.steps) {
      if (step.frame >= model.frames.length) throw new Error(`clip "${clip.name}" references frame ${step.frame}`);
      if (step.durationTicks < 1 || step.durationTicks > 0xffff) {
        throw new Error(`clip "${clip.name}" step duration ${step.durationTicks} out of range`);
      }
    }
  }
  const actionClips = new Set<number>();
  for (const action of actions) {
    const enterClip = action.enterClip ?? ACTION_NO_CLIP;
    if (action.clip >= model.clips.length) throw new Error(`action ${action.id} references clip ${action.clip}`);
    if (enterClip !== ACTION_NO_CLIP && enterClip >= model.clips.length) {
      throw new Error(`action ${action.id} references enter clip ${enterClip}`);
    }
    if (action.exitClip !== ACTION_NO_CLIP && action.exitClip >= model.clips.length) {
      throw new Error(`action ${action.id} references exit clip ${action.exitClip}`);
    }
    if (enterClip !== ACTION_NO_CLIP && model.clips[enterClip]!.loopMode !== LOOP_ONCE) {
      throw new Error(`action ${action.id} enter clip must be loop-once`);
    }
    if (action.exitClip !== ACTION_NO_CLIP && model.clips[action.exitClip]!.loopMode !== LOOP_ONCE) {
      throw new Error(`action ${action.id} exit clip must be loop-once`);
    }
    if (action.profileMask === 0 || (action.profileMask & ~ACTION_FLAG_PROFILE_MASK) !== 0) {
      throw new Error(`action ${action.id} has invalid profile mask`);
    }
    if (action.intervalMinTicks > action.intervalMaxTicks) throw new Error(`action ${action.id} interval is inverted`);
    actionClips.add(action.clip);
    if (enterClip !== ACTION_NO_CLIP) actionClips.add(enterClip);
    if (action.exitClip !== ACTION_NO_CLIP) actionClips.add(action.exitClip);
  }
  for (const clipIndex of actionClips) {
    const action = actions.find((candidate) => candidate.clip === clipIndex || candidate.enterClip === clipIndex || candidate.exitClip === clipIndex)!;
    for (const step of model.clips[clipIndex]!.steps) {
      const codec = frames[step.frame]!.codec;
      const expectsFull = action.plane === "base";
      const full = isFullCodec(codec);
      const masked = isMaskedCodec(codec);
      if ((expectsFull && !full) || (!expectsFull && !masked)) {
        throw new Error(`action ${action.id} plane ${action.plane} references the wrong frame codec`);
      }
    }
  }
  if (model.roles.length !== ROLE_COUNT) throw new Error(`roles table must have ${ROLE_COUNT} slots`);
  for (const role of model.roles) {
    if (role !== ROLE_ABSENT && role >= model.clips.length) throw new Error(`role references clip ${role}`);
  }
  if (model.roles[ROLE_IDLE_NEUTRAL] === ROLE_ABSENT) throw new Error("ROLE_IDLE_NEUTRAL is required");
  if (model.emotions.length > FRAME_PACK_MAX_EMOTIONS) {
    throw new Error(`at most ${FRAME_PACK_MAX_EMOTIONS} emotions (fixed C arena cap)`);
  }
  for (const emotion of model.emotions) {
    if (!Number.isInteger(emotion.id) || emotion.id < 1 || emotion.id > FRAME_PACK_MAX_EMOTION_ID) {
      throw new Error(`emotion "${emotion.name}" id ${emotion.id} must be 1..${FRAME_PACK_MAX_EMOTION_ID}`);
    }
    // Enter/exit clips must terminate or the director wedges in EMO_ENTER/EXIT.
    if (model.clips[emotion.enterClip]!.loopMode !== LOOP_ONCE) {
      throw new Error(`emotion "${emotion.name}" enter clip must be loop-once`);
    }
    if (model.clips[emotion.exitClip]!.loopMode !== LOOP_ONCE) {
      throw new Error(`emotion "${emotion.name}" exit clip must be loop-once`);
    }
  }
  if (model.idle.micro.length > FRAME_PACK_MAX_MICRO) {
    throw new Error(`at most ${FRAME_PACK_MAX_MICRO} micro entries (fixed C arena cap)`);
  }
  for (const micro of model.idle.micro) {
    if (model.clips[micro.clip]!.loopMode !== LOOP_ONCE) {
      throw new Error(`micro clip ${micro.clip} must be loop-once`);
    }
  }
  if (model.talk.levelToStage.length !== TALK_LUT_BYTES) {
    throw new Error(`talk LUT must have ${TALK_LUT_BYTES} entries`);
  }
  if (facial && model.talk.stageFrames.length > FACIAL_MOUTH_STAGES) {
    throw new Error(`facial packs support at most ${FACIAL_MOUTH_STAGES} talk stages`);
  }
  const speaking = model.speakingPoses;
  if (speaking) validateSpeakingPoses(speaking, model, frames, canvas);

  // Strings pool (deduplicated, insertion order).
  const stringOffsets = new Map<string, { offset: number; length: number }>();
  const stringChunks: Uint8Array[] = [];
  let stringsLength = 0;
  const internString = (s: string): { offset: number; length: number } => {
    const existing = stringOffsets.get(s);
    if (existing) return existing;
    const bytes = encoder.encode(s);
    const ref = { offset: stringsLength, length: bytes.length };
    stringOffsets.set(s, ref);
    stringChunks.push(bytes);
    stringsLength += bytes.length;
    return ref;
  };
  const idRef = internString(model.id);
  const nameRef = internString(model.name);
  const versionRef = internString(model.version);
  const clipRefs = model.clips.map((clip) => internString(clip.name));
  const emotionRefs = model.emotions.map((emotion) => internString(emotion.name));

  const metaBytes = encoder.encode(canonicalJson(model.meta));

  // Section layout.
  let cursor = FRAME_PACK_HEADER_BYTES;
  const paletteOffset = cursor;
  cursor = align4(cursor + model.palette.length * 2);
  const frameDirOffset = cursor;
  cursor = align4(cursor + model.frames.length * FRAME_DIR_ENTRY_BYTES);
  const frameDataOffsets: number[] = [];
  for (const frame of frames) {
    frameDataOffsets.push(cursor);
    cursor = align4(cursor + frame.data.length);
  }
  const clipDirOffset = cursor;
  cursor = align4(cursor + model.clips.length * CLIP_DIR_ENTRY_BYTES);
  const clipStepOffsets: number[] = [];
  for (const clip of model.clips) {
    clipStepOffsets.push(cursor);
    cursor = align4(cursor + clip.steps.length * CLIP_STEP_BYTES);
  }
  const rolesOffset = cursor;
  cursor = align4(cursor + ROLES_TABLE_BYTES);
  const emotionsOffset = cursor;
  cursor = align4(cursor + model.emotions.length * EMOTION_ENTRY_BYTES);
  const talkOffset = cursor;
  const talkStageBytes = align4(4 + model.talk.stageFrames.length * 2);
  const talkLutBytes = align4(TALK_LUT_BYTES);
  cursor = talkOffset + talkStageBytes + talkLutBytes;
  const idleOffset = cursor;
  cursor = align4(cursor + IDLE_PARAMS_BYTES);
  const microListOffset = cursor;
  cursor = align4(cursor + model.idle.micro.length * MICRO_ENTRY_BYTES);
  const overlayDirOffset = cursor;
  cursor = align4(cursor + actions.length * OVERLAY_DIR_ENTRY_BYTES);
  const facialOffset = facial ? cursor : 0;
  if (facial) cursor = align4(cursor + FACIAL_HEADER_BYTES + facial.groups.length * FACIAL_GROUP_BYTES);
  const speakingOffset = speaking ? cursor : 0;
  const speakingFrameBytes = speaking ? align4(speaking.frames.length * model.talk.stageFrames.length * 2) : 0;
  const speakingLength = speaking ? SPEAKING_HEADER_BYTES + speakingFrameBytes + speaking.gestures.length * SPEAKING_GESTURE_BYTES : 0;
  if (speaking) cursor = align4(cursor + speakingLength);
  const stringsOffset = cursor;
  cursor = align4(cursor + stringsLength);
  const metaOffset = cursor;
  cursor = align4(cursor + metaBytes.length);
  const fileLength = cursor;
  if (fileLength > maxBytes) {
    throw new FramePackCapacityError(fileLength,maxBytes);
  }

  const out = new Uint8Array(fileLength);
  const view = new DataView(out.buffer);

  // Palette.
  for (const [i, rgb] of model.palette.entries()) {
    view.setUint16(paletteOffset + i * 2, to565Word(rgb), true);
  }
  // Frame directory + data.
  for (const [i, frame] of frames.entries()) {
    const at = frameDirOffset + i * FRAME_DIR_ENTRY_BYTES;
    view.setUint32(at, frameDataOffsets[i]!, true);
    view.setUint32(at + 4, frame.data.length, true);
    out[at + 8] = frame.codec;
    out.set(frame.data, frameDataOffsets[i]!);
  }
  // Clip directory + steps.
  for (const [i, clip] of model.clips.entries()) {
    const at = clipDirOffset + i * CLIP_DIR_ENTRY_BYTES;
    view.setUint32(at, stringsOffset + clipRefs[i]!.offset, true);
    view.setUint16(at + 4, clipRefs[i]!.length, true);
    out[at + 6] = clip.loopMode;
    view.setUint32(at + 8, clipStepOffsets[i]!, true);
    view.setUint16(at + 12, clip.steps.length, true);
    for (const [s, step] of clip.steps.entries()) {
      const stepAt = clipStepOffsets[i]! + s * CLIP_STEP_BYTES;
      view.setUint16(stepAt, step.frame, true);
      view.setUint16(stepAt + 2, step.durationTicks, true);
    }
  }
  // Roles.
  for (let i = 0; i < ROLE_COUNT; i++) {
    view.setUint16(rolesOffset + i * 2, model.roles[i]!, true);
  }
  // Emotions.
  for (const [i, emotion] of model.emotions.entries()) {
    const at = emotionsOffset + i * EMOTION_ENTRY_BYTES;
    out[at] = emotion.id;
    view.setUint16(at + 2, emotionRefs[i]!.length, true);
    view.setUint32(at + 4, stringsOffset + emotionRefs[i]!.offset, true);
    view.setUint16(at + 8, emotion.enterClip, true);
    view.setUint16(at + 10, emotion.holdClip, true);
    view.setUint16(at + 12, emotion.exitClip, true);
    view.setUint16(at + 14, emotion.minHoldMs, true);
    view.setUint16(at + 16, emotion.maxHoldMs, true);
  }
  // Talk table.
  out[talkOffset] = model.talk.stageFrames.length;
  for (const [i, frame] of model.talk.stageFrames.entries()) {
    view.setUint16(talkOffset + 4 + i * 2, frame, true);
  }
  out.set(model.talk.levelToStage, talkOffset + talkStageBytes);
  // Idle params + micro list.
  view.setUint16(idleOffset, model.idle.bobAmplitudePx, true);
  view.setUint16(idleOffset + 2, model.idle.bobPeriodTicks, true);
  view.setUint16(idleOffset + 4, model.idle.microGapMinTicks, true);
  view.setUint16(idleOffset + 6, model.idle.microGapMaxTicks, true);
  view.setUint32(idleOffset + 8, microListOffset, true);
  view.setUint16(idleOffset + 12, model.idle.micro.length, true);
  for (const [i, micro] of model.idle.micro.entries()) {
    const at = microListOffset + i * MICRO_ENTRY_BYTES;
    view.setUint16(at, micro.clip, true);
    view.setUint16(at + 2, micro.weight, true);
  }
  out[idleOffset + 14] = (model.idle.fallbacksEnabled ? 1 : 0) | (model.idle.parallaxSafe ? 2 : 0);
  out[idleOffset + 15] = model.idle.maxParallaxPx ?? 0;
  for (const [i, action] of actions.entries()) {
    const at = overlayDirOffset + i * OVERLAY_DIR_ENTRY_BYTES;
    out[at] = ACTION_SEMANTICS.indexOf(action.semantic);
    out[at + 1] = ACTION_PLANES.indexOf(action.plane);
    out[at + 2] = ACTIVATION_KINDS.indexOf(action.activationKind);
    out[at + 3] = action.priority;
    view.setUint16(at + 4, action.clip, true);
    view.setUint16(at + 6, action.exitClip, true);
    view.setUint16(at + 8, action.profileMask | (action.essential ? ACTION_FLAG_ESSENTIAL : 0), true);
    if (action.posePolicy === "center-only") view.setUint16(at + 8, view.getUint16(at + 8, true) | ACTION_FLAG_CENTER_ONLY, true);
    view.setUint16(at + 10, action.stateMask, true);
    view.setUint16(at + 12, action.expressionMask, true);
    view.setUint16(at + 14, action.intervalMinTicks, true);
    view.setUint16(at + 16, action.intervalMaxTicks, true);
    view.setUint16(at + 18, action.cooldownTicks, true);
    const enterClip = action.enterClip ?? ACTION_NO_CLIP;
    if (hasActionLifecycle) view.setUint16(at + 20, enterClip, true);
    if (hasPerformanceActions) view.setUint16(at + 22, action.performanceMask ?? 0, true);
  }
  if (facial) {
    view.setUint16(facialOffset, facial.independentBlink ? 2 : FACIAL_SECTION_VERSION, true);
    out[facialOffset+2]=facial.groups.length; out[facialOffset+3]=facial.centerGroup;
    view.setUint16(facialOffset+4,facial.blinkStateMask,true);
    for(let i=0;i<6;i++) view.setUint16(facialOffset+8+i*2,facial.blinkGaps[i]!,true);
    for(let i=0;i<5;i++) out[facialOffset+20+i]=facial.blinkStageTicks[i]!;
    view.setUint16(facialOffset+26,facial.poseStateMask,true); view.setUint16(facialOffset+30,facial.bobStateMask,true);
    out[facialOffset+32]=facial.bobFullAmplitude; out[facialOffset+33]=facial.bobBalancedAmplitude;
    view.setUint16(facialOffset+34,facial.bobPeriodTicks,true);
    const poseWords=facial.independentBlink?[...(facial.gazeStageTicks??[60,60,60,60,60]),0,0,0]:facial.poseTimings;
    for(let i=0;i<8;i++) view.setUint16(facialOffset+36+i*2,poseWords[i]!,true);
    view.setUint32(facialOffset+52,facialOffset+FACIAL_HEADER_BYTES,true);
    facial.groups.forEach((g,i)=>{ const at=facialOffset+FACIAL_HEADER_BYTES+i*FACIAL_GROUP_BYTES; out[at]=g.role; view.setUint16(at+2,g.baseFrame,true); const rs=[g.mouthRect,g.eyeRect]; rs.forEach((r,j)=>{const o=at+4+j*4;out[o]=r.x;out[o+1]=r.y;out[o+2]=r.width;out[o+3]=r.height;}); g.mouthFrames.forEach((f,j)=>view.setUint16(at+12+j*2,f,true));g.eyeFrames.forEach((f,j)=>view.setUint16(at+26+j*2,f,true)); });
  }
  if (speaking) {
    const stages = model.talk.stageFrames.length;
    out[speakingOffset] = SPEAKING_SECTION_VERSION;
    out[speakingOffset + 1] = speaking.frames.length;
    out[speakingOffset + 2] = stages;
    out[speakingOffset + 3] = speaking.gestures.length;
    out[speakingOffset + 4] = speaking.gestures.reduce((mask, gesture, i) => (gesture.automatic ? mask | (1 << i) : mask), 0);
    view.setUint16(speakingOffset + 6, speaking.breakMinTicks, true);
    view.setUint16(speakingOffset + 8, speaking.breakMaxTicks, true);
    for (const [pose, row] of speaking.frames.entries()) {
      for (const [stage, frame] of row.entries()) {
        view.setUint16(speakingOffset + SPEAKING_HEADER_BYTES + (pose * stages + stage) * 2, frame, true);
      }
    }
    for (const [i, gesture] of speaking.gestures.entries()) {
      const at = speakingOffset + SPEAKING_HEADER_BYTES + speakingFrameBytes + i * SPEAKING_GESTURE_BYTES;
      out[at] = SPEAKING_GESTURE_KINDS.indexOf(gesture.kind);
      out[at + 1] = gesture.steps.length;
      for (const [j, step] of gesture.steps.entries()) {
        out[at + 2 + j * 2] = step.pose;
        out[at + 3 + j * 2] = step.ticks;
      }
    }
  }
  // Strings + meta.
  let stringCursor = stringsOffset;
  for (const chunk of stringChunks) {
    out.set(chunk, stringCursor);
    stringCursor += chunk.length;
  }
  out.set(metaBytes, metaOffset);

  // Header.
  out.set(FRAME_PACK_MAGIC, HDR_MAGIC);
  view.setUint16(HDR_VERSION, formatVersion, true);
  view.setUint16(HDR_HEADER_BYTES, FRAME_PACK_HEADER_BYTES, true);
  view.setUint16(HDR_CANVAS_W, canvas, true);
  view.setUint16(HDR_CANVAS_H, canvas, true);
  view.setUint32(HDR_FILE_LENGTH, fileLength, true);
  view.setUint16(
    HDR_FLAGS,
    (model.approved ? FRAME_FLAG_APPROVED : 0) |
      (actions.length > 0 ? FP_FEATURE_OVERLAY_ACTIONS : 0) |
      (facial ? FP_FEATURE_FACIAL_REGIONS : 0) |
      (hasActionLifecycle ? FP_FEATURE_ACTION_LIFECYCLE : 0) |
      (hasPerformanceActions ? FP_FEATURE_PERFORMANCE_ACTIONS : 0) |
      (speaking ? FP_FEATURE_SPEAKING_POSES : 0),
    true,
  );
  view.setUint16(HDR_TICK_MS, FRAME_PACK_TICK_MS, true);
  view.setUint32(HDR_PALETTE_OFFSET, paletteOffset, true);
  view.setUint16(HDR_PALETTE_COUNT, model.palette.length, true);
  out[HDR_BG_PALETTE_INDEX] = model.bgPaletteIndex;
  out[HDR_GENDER] = model.gender;
  view.setUint32(HDR_FRAME_DIR_OFFSET, frameDirOffset, true);
  view.setUint16(HDR_FRAME_COUNT, model.frames.length, true);
  view.setUint16(HDR_CLIP_COUNT, model.clips.length, true);
  view.setUint32(HDR_CLIP_DIR_OFFSET, clipDirOffset, true);
  view.setUint32(HDR_ROLES_OFFSET, rolesOffset, true);
  view.setUint32(HDR_EMOTIONS_OFFSET, emotionsOffset, true);
  view.setUint16(HDR_EMOTION_COUNT, model.emotions.length, true);
  view.setUint16(HDR_OVERLAY_COUNT, actions.length, true);
  view.setUint32(HDR_TALK_OFFSET, talkOffset, true);
  view.setUint32(HDR_OVERLAY_DIR_OFFSET, overlayDirOffset, true);
  view.setUint32(HDR_IDLE_OFFSET, idleOffset, true);
  view.setUint32(HDR_STRINGS_OFFSET, stringsOffset, true);
  view.setUint32(HDR_STRINGS_LENGTH, stringsLength, true);
  view.setUint32(HDR_META_OFFSET, metaOffset, true);
  view.setUint32(HDR_META_LENGTH, metaBytes.length, true);
  view.setUint32(HDR_ID_STR_OFFSET, stringsOffset + idRef.offset, true);
  view.setUint32(HDR_NAME_STR_OFFSET, stringsOffset + nameRef.offset, true);
  view.setUint32(HDR_VERSION_STR_OFFSET, stringsOffset + versionRef.offset, true);
  view.setUint16(HDR_ID_STR_LEN, idRef.length, true);
  view.setUint16(HDR_NAME_STR_LEN, nameRef.length, true);
  view.setUint16(HDR_VERSION_STR_LEN, versionRef.length, true);
  view.setUint32(HDR_FACIAL_OFFSET, facialOffset, true);
  view.setUint32(HDR_FACIAL_LENGTH, facial ? FACIAL_HEADER_BYTES + facial.groups.length*FACIAL_GROUP_BYTES : 0, true);
  view.setUint32(HDR_SPEAKING_OFFSET, speakingOffset, true);
  view.setUint16(HDR_SPEAKING_LENGTH, speakingLength, true);

  // CRCs: payload first, then header (with its own CRC field zeroed).
  view.setUint32(HDR_PAYLOAD_CRC32, crc32(out.subarray(FRAME_PACK_HEADER_BYTES)), true);
  view.setUint32(HDR_HEADER_CRC32, 0, true);
  const headerCrc = crc32(out.subarray(0, FRAME_PACK_HEADER_BYTES));
  view.setUint32(HDR_HEADER_CRC32, headerCrc, true);
  return out;
}

export interface ParsedFramePack {
  info: {
    formatVersion: number;
    width: number;
    height: number;
    id: string;
    name: string;
    version: string;
    gender: number;
    approved: boolean;
    tickMs: number;
    paletteCount: number;
    bgPaletteIndex: number;
    frameCount: number;
    clipCount: number;
    emotionCount: number;
    overlayCount: number;
    features: number;
    fileLength: number;
    payloadCrc32: number;
  };
  paletteRgb565: Uint16Array;
  paletteRgb: Rgb[];
  frames: { offset: number; length: number; codec: number }[];
  clips: Clip[];
  roles: number[];
  emotions: EmotionEntry[];
  talk: TalkTable;
  idle: IdleParams;
  actions: ActionEntry[];
  facialRegions?: FacialRegionsEntry;
  speakingPoses?: SpeakingPoses;
  meta: unknown;
  bytes: Uint8Array;
  decodeFrame(index: number): Uint8Array;
}

/**
 * Parse + fully validate a pack. Mirrors the C loader's `fp_validate` checks
 * one for one; after a successful parse, rendering cannot fail.
 */
export function parseFramePack(bytes: Uint8Array): ParsedFramePack {
  if (bytes.length < FRAME_PACK_HEADER_BYTES) throw new FramePackError("TRUNCATED", "shorter than header");
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  for (let i = 0; i < 8; i++) {
    if (bytes[i] !== FRAME_PACK_MAGIC[i]) throw new FramePackError("BAD_MAGIC", "not an .aipetframes pack");
  }
  const formatVersion = view.getUint16(HDR_VERSION, true);
  if (formatVersion !== FRAME_PACK_VERSION && formatVersion !== FRAME_PACK_VERSION_240) {
    throw new FramePackError("UNSUPPORTED_VERSION", `version ${view.getUint16(HDR_VERSION, true)}`);
  }
  if (view.getUint16(HDR_HEADER_BYTES, true) !== FRAME_PACK_HEADER_BYTES) {
    throw new FramePackError("BAD_HEADER", "unexpected header size");
  }
  const canvas = formatVersion === FRAME_PACK_VERSION_240 ? 240 : 120;
  if (view.getUint16(HDR_CANVAS_W, true) !== canvas || view.getUint16(HDR_CANVAS_H, true) !== canvas) {
    throw new FramePackError("BAD_HEADER", "unsupported version/canvas pair");
  }
  const fileLength = view.getUint32(HDR_FILE_LENGTH, true);
  if (fileLength !== bytes.length) {
    throw new FramePackError("TRUNCATED", `declared ${fileLength} bytes, have ${bytes.length}`);
  }
  if (fileLength > (canvas === 240 ? FRAME_PACK_MAX_BYTES_240 : FRAME_PACK_MAX_BYTES)) throw new FramePackError("BAD_HEADER", "exceeds slot ceiling");
  if (view.getUint16(HDR_TICK_MS, true) !== FRAME_PACK_TICK_MS) {
    throw new FramePackError("BAD_HEADER", "tickMs must be 33");
  }
  const headerCrcStored = view.getUint32(HDR_HEADER_CRC32, true);
  /* Buffer.slice() aliases its source while Uint8Array.slice() copies. Always
   * make an explicit plain Uint8Array copy so validation never zeroes the
   * caller's pack header before a subsequent C/WASM validation. */
  const headerCopy = Uint8Array.from(bytes.subarray(0, FRAME_PACK_HEADER_BYTES));
  new DataView(headerCopy.buffer, headerCopy.byteOffset, headerCopy.byteLength).setUint32(HDR_HEADER_CRC32, 0, true);
  if (crc32(headerCopy) !== headerCrcStored) throw new FramePackError("BAD_CHECKSUM", "header CRC mismatch");
  const payloadCrc32 = view.getUint32(HDR_PAYLOAD_CRC32, true);
  if (crc32(bytes.subarray(FRAME_PACK_HEADER_BYTES)) !== payloadCrc32) {
    throw new FramePackError("BAD_CHECKSUM", "payload CRC mismatch");
  }
  const features = view.getUint16(HDR_FLAGS, true);
  if ((features & ~(FRAME_FLAG_APPROVED | FP_FEATURE_OVERLAY_ACTIONS | FP_FEATURE_FACIAL_REGIONS | FP_FEATURE_ACTION_LIFECYCLE | FP_FEATURE_PERFORMANCE_ACTIONS | FP_FEATURE_SPEAKING_POSES)) !== 0) {
    throw new FramePackError("BAD_HEADER", "unknown feature flag");
  }
  for (let i = HDR_SPEAKING_LENGTH + 2; i < FRAME_PACK_HEADER_BYTES; i++) {
    if (bytes[i] !== 0) throw new FramePackError("BAD_HEADER", `reserved header byte ${i} is nonzero`);
  }

  const inBounds = (offset: number, length: number): boolean =>
    offset >= FRAME_PACK_HEADER_BYTES && offset + length <= fileLength;
  const requireBounds = (offset: number, length: number, what: string): void => {
    if (!inBounds(offset, length)) throw new FramePackError("BAD_BOUNDS", `${what} out of bounds`);
  };

  const paletteOffset = view.getUint32(HDR_PALETTE_OFFSET, true);
  const paletteCount = view.getUint16(HDR_PALETTE_COUNT, true);
  if (paletteCount < 1 || paletteCount > FRAME_PACK_MAX_PALETTE) {
    throw new FramePackError("BAD_HEADER", `palette count ${paletteCount}`);
  }
  requireBounds(paletteOffset, paletteCount * 2, "palette");
  const paletteRgb565 = new Uint16Array(paletteCount);
  for (let i = 0; i < paletteCount; i++) paletteRgb565[i] = view.getUint16(paletteOffset + i * 2, true);
  const paletteRgb = [...paletteRgb565].map((v) => from565(v));
  const bgPaletteIndex = bytes[HDR_BG_PALETTE_INDEX]!;
  if (bgPaletteIndex >= paletteCount) throw new FramePackError("BAD_HEADER", "bgPaletteIndex out of range");
  const gender = bytes[HDR_GENDER]!;
  if (gender > 3) throw new FramePackError("BAD_HEADER", `gender code ${gender}`);

  const frameCount = view.getUint16(HDR_FRAME_COUNT, true);
  if (frameCount < 1 || frameCount > (canvas === 240 ? FRAME_PACK_MAX_FRAMES_240 : FRAME_PACK_MAX_FRAMES)) {
    throw new FramePackError("BAD_HEADER", `frame count ${frameCount}`);
  }
  const frameDirOffset = view.getUint32(HDR_FRAME_DIR_OFFSET, true);
  requireBounds(frameDirOffset, frameCount * FRAME_DIR_ENTRY_BYTES, "frame directory");
  const frames: { offset: number; length: number; codec: number }[] = [];
  for (let i = 0; i < frameCount; i++) {
    const at = frameDirOffset + i * FRAME_DIR_ENTRY_BYTES;
    const offset = view.getUint32(at, true);
    const length = view.getUint32(at + 4, true);
    const codec = bytes[at + 8]!;
    if (codec > 7 || (canvas === 120 && isZlibCodec(codec))) {
      throw new FramePackError("BAD_FRAME", `frame ${i} codec ${codec}`);
    }
    if (codec === FRAME_CODEC_INDEX8_FULL && length !== canvas * canvas) {
      throw new FramePackError("BAD_FRAME", `frame ${i} length ${length}`);
    }
    requireBounds(offset, length, `frame ${i}`);
    const data = bytes.subarray(offset, offset + length);
    if (codec === FRAME_CODEC_INDEX8_FULL) {
      for (let p = 0; p < length; p++) {
        if (data[p]! >= paletteCount) throw new FramePackError("BAD_FRAME", `frame ${i} palette index out of range`);
      }
    } else {
      try {
        validateFrameResource({ codec, data }, paletteCount, i, canvas);
      } catch (error) {
        throw new FramePackError("BAD_FRAME", String((error as Error).message));
      }
    }
    frames.push({ offset, length, codec });
  }

  const stringsOffset = view.getUint32(HDR_STRINGS_OFFSET, true);
  const stringsLength = view.getUint32(HDR_STRINGS_LENGTH, true);
  if (stringsLength > 0) requireBounds(stringsOffset, stringsLength, "strings");
  const readString = (offset: number, length: number, what: string): string => {
    if (length === 0) return "";
    if (offset < stringsOffset || offset + length > stringsOffset + stringsLength) {
      throw new FramePackError("BAD_BOUNDS", `${what} string out of bounds`);
    }
    return decoder.decode(bytes.subarray(offset, offset + length));
  };

  const clipCount = view.getUint16(HDR_CLIP_COUNT, true);
  if (clipCount < 1 || clipCount > FRAME_PACK_MAX_CLIPS) {
    throw new FramePackError("BAD_HEADER", `clip count ${clipCount}`);
  }
  const clipDirOffset = view.getUint32(HDR_CLIP_DIR_OFFSET, true);
  requireBounds(clipDirOffset, clipCount * CLIP_DIR_ENTRY_BYTES, "clip directory");
  const clips: Clip[] = [];
  for (let i = 0; i < clipCount; i++) {
    const at = clipDirOffset + i * CLIP_DIR_ENTRY_BYTES;
    const name = readString(view.getUint32(at, true), view.getUint16(at + 4, true), `clip ${i}`);
    const loopMode = bytes[at + 6]!;
    if (loopMode < LOOP_ONCE || loopMode > LOOP_HOLD_LAST) {
      throw new FramePackError("BAD_CLIP", `clip ${i} loop mode ${loopMode}`);
    }
    const stepsOffset = view.getUint32(at + 8, true);
    const stepCount = view.getUint16(at + 12, true);
    if (stepCount < 1 || stepCount > FRAME_PACK_MAX_CLIP_STEPS) {
      throw new FramePackError("BAD_CLIP", `clip ${i} step count ${stepCount}`);
    }
    requireBounds(stepsOffset, stepCount * CLIP_STEP_BYTES, `clip ${i} steps`);
    const steps: ClipStep[] = [];
    for (let s = 0; s < stepCount; s++) {
      const stepAt = stepsOffset + s * CLIP_STEP_BYTES;
      const frame = view.getUint16(stepAt, true);
      const durationTicks = view.getUint16(stepAt + 2, true);
      if (frame >= frameCount) throw new FramePackError("BAD_CLIP", `clip ${i} step ${s} frame ${frame}`);
      if (durationTicks < 1) throw new FramePackError("BAD_CLIP", `clip ${i} step ${s} zero duration`);
      steps.push({ frame, durationTicks });
    }
    clips.push({ name, loopMode, steps });
  }

  const fullFrame = (frame: number) => frames[frame] !== undefined && isFullCodec(frames[frame]!.codec);
  const fullClip = (clip: number) => clips[clip]?.steps.every(step => fullFrame(step.frame));
  const rolesOffset = view.getUint32(HDR_ROLES_OFFSET, true);
  requireBounds(rolesOffset, ROLES_TABLE_BYTES, "roles table");
  const roles: number[] = [];
  for (let i = 0; i < ROLE_COUNT; i++) {
    const role = view.getUint16(rolesOffset + i * 2, true);
    if (role !== ROLE_ABSENT && role >= clipCount) throw new FramePackError("BAD_ROLE", `role ${i} clip ${role}`);
    if (role !== ROLE_ABSENT && !fullClip(role)) throw new FramePackError("BAD_ROLE", "role requires opaque frames");
    roles.push(role);
  }
  if (roles[ROLE_IDLE_NEUTRAL] === ROLE_ABSENT) throw new FramePackError("BAD_ROLE", "ROLE_IDLE_NEUTRAL absent");

  const emotionCount = view.getUint16(HDR_EMOTION_COUNT, true);
  if (emotionCount > FRAME_PACK_MAX_EMOTIONS) {
    throw new FramePackError("BAD_EMOTION", `emotion count ${emotionCount} exceeds the C arena cap`);
  }
  const emotionsOffset = view.getUint32(HDR_EMOTIONS_OFFSET, true);
  if (emotionCount > 0) requireBounds(emotionsOffset, emotionCount * EMOTION_ENTRY_BYTES, "emotions");
  const emotions: EmotionEntry[] = [];
  const seenEmotionIds = new Set<number>();
  for (let i = 0; i < emotionCount; i++) {
    const at = emotionsOffset + i * EMOTION_ENTRY_BYTES;
    const id = bytes[at]!;
    if (id === 0) throw new FramePackError("BAD_EMOTION", `emotion ${i} id 0 is reserved for neutral`);
    if (id > FRAME_PACK_MAX_EMOTION_ID) {
      throw new FramePackError("BAD_EMOTION", `emotion ${i} id ${id} does not fit the 16-bit expression mask`);
    }
    if (seenEmotionIds.has(id)) throw new FramePackError("BAD_EMOTION", `duplicate emotion id ${id}`);
    seenEmotionIds.add(id);
    const name = readString(view.getUint32(at + 4, true), view.getUint16(at + 2, true), `emotion ${i}`);
    const enterClip = view.getUint16(at + 8, true);
    const holdClip = view.getUint16(at + 10, true);
    const exitClip = view.getUint16(at + 12, true);
    const minHoldMs = view.getUint16(at + 14, true);
    const maxHoldMs = view.getUint16(at + 16, true);
    for (const [what, clip] of [
      ["enter", enterClip],
      ["hold", holdClip],
      ["exit", exitClip],
    ] as const) {
      if (clip >= clipCount) throw new FramePackError("BAD_EMOTION", `emotion ${i} ${what} clip ${clip}`);
      if (!fullClip(clip)) throw new FramePackError("BAD_EMOTION", "emotion requires opaque frames");
    }
    if (minHoldMs > maxHoldMs) throw new FramePackError("BAD_EMOTION", `emotion ${i} minHold > maxHold`);
    if (clips[enterClip]!.loopMode !== LOOP_ONCE || clips[exitClip]!.loopMode !== LOOP_ONCE) {
      // Non-terminating enter/exit clips would wedge the director.
      throw new FramePackError("BAD_EMOTION", `emotion ${i} enter/exit clips must be loop-once`);
    }
    emotions.push({ id, name, enterClip, holdClip, exitClip, minHoldMs, maxHoldMs });
  }

  const talkOffset = view.getUint32(HDR_TALK_OFFSET, true);
  requireBounds(talkOffset, 4, "talk table");
  const stageCount = bytes[talkOffset]!;
  if (stageCount < 1 || stageCount > 16) throw new FramePackError("BAD_TALK", `stage count ${stageCount}`);
  const talkStageBytes = align4(4 + stageCount * 2);
  requireBounds(talkOffset, talkStageBytes + align4(TALK_LUT_BYTES), "talk table body");
  const stageFrames: number[] = [];
  for (let i = 0; i < stageCount; i++) {
    const frame = view.getUint16(talkOffset + 4 + i * 2, true);
    if (frame >= frameCount) throw new FramePackError("BAD_TALK", `stage ${i} frame ${frame}`);
    if (!fullFrame(frame)) throw new FramePackError("BAD_TALK", "talk requires opaque frames");
    stageFrames.push(frame);
  }
  const levelToStage = bytes.slice(talkOffset + talkStageBytes, talkOffset + talkStageBytes + TALK_LUT_BYTES);
  for (let level = 0; level < TALK_LUT_BYTES; level++) {
    if (levelToStage[level]! >= stageCount) {
      throw new FramePackError("BAD_TALK", `level ${level} maps to stage ${levelToStage[level]}`);
    }
  }

  const idleOffset = view.getUint32(HDR_IDLE_OFFSET, true);
  requireBounds(idleOffset, IDLE_PARAMS_BYTES, "idle params");
  const bobAmplitudePx = view.getUint16(idleOffset, true);
  const bobPeriodTicks = view.getUint16(idleOffset + 2, true);
  const microGapMinTicks = view.getUint16(idleOffset + 4, true);
  const microGapMaxTicks = view.getUint16(idleOffset + 6, true);
  const microListOffset = view.getUint32(idleOffset + 8, true);
  const microCount = view.getUint16(idleOffset + 12, true);
  const motionFlags = bytes[idleOffset + 14]!;
  const maxParallaxPx = bytes[idleOffset + 15]!;
  if ((motionFlags & ~3) !== 0 || maxParallaxPx > 1 || (maxParallaxPx > 0 && (motionFlags & 2) === 0)) {
    throw new FramePackError("BAD_IDLE", "invalid motion flags or parallax range");
  }
  if (bobAmplitudePx > 2) throw new FramePackError("BAD_IDLE", `bob amplitude ${bobAmplitudePx}`);
  if (bobAmplitudePx > 0 && bobPeriodTicks < 2) throw new FramePackError("BAD_IDLE", "bob period too short");
  if (microCount > 0 && microGapMinTicks >= microGapMaxTicks) {
    throw new FramePackError("BAD_IDLE", "micro gap range empty");
  }
  if (microCount > FRAME_PACK_MAX_MICRO) {
    throw new FramePackError("BAD_IDLE", `micro count ${microCount} exceeds the C arena cap`);
  }
  if (microCount > 0) requireBounds(microListOffset, microCount * MICRO_ENTRY_BYTES, "micro list");
  const micro: { clip: number; weight: number }[] = [];
  let microWeightTotal = 0;
  for (let i = 0; i < microCount; i++) {
    const at = microListOffset + i * MICRO_ENTRY_BYTES;
    const clip = view.getUint16(at, true);
    const weight = view.getUint16(at + 2, true);
    if (clip >= clipCount) throw new FramePackError("BAD_IDLE", `micro ${i} clip ${clip}`);
    if (!fullClip(clip)) throw new FramePackError("BAD_IDLE", "micro requires opaque frames");
    if (weight < 1) throw new FramePackError("BAD_IDLE", `micro ${i} zero weight`);
    if (clips[clip]!.loopMode !== LOOP_ONCE) {
      throw new FramePackError("BAD_IDLE", `micro ${i} clip must be loop-once`);
    }
    micro.push({ clip, weight });
    microWeightTotal += weight;
  }
  if (microWeightTotal > 0xffff) throw new FramePackError("BAD_IDLE", "micro weights overflow u16");

  const overlayCount = view.getUint16(HDR_OVERLAY_COUNT, true);
  if (overlayCount > (canvas === 240 ? FRAME_PACK_MAX_ACTIONS_240 : 32)) throw new FramePackError("BAD_OVERLAY", "too many actions");
  if (overlayCount > 0 && (features & FP_FEATURE_OVERLAY_ACTIONS) === 0) {
    throw new FramePackError("BAD_OVERLAY", "action table lacks its feature flag");
  }
  if (overlayCount === 0 && (features & FP_FEATURE_OVERLAY_ACTIONS) !== 0) {
    throw new FramePackError("BAD_OVERLAY", "action feature flag has an empty table");
  }
  const overlayDirOffset = view.getUint32(HDR_OVERLAY_DIR_OFFSET, true);
  if (overlayCount > 0) requireBounds(overlayDirOffset, overlayCount * OVERLAY_DIR_ENTRY_BYTES, "action directory");
  const actions: ActionEntry[] = [];
  for (let i = 0; i < overlayCount; i++) {
    const at = overlayDirOffset + i * OVERLAY_DIR_ENTRY_BYTES;
    const semantic = ACTION_SEMANTICS[bytes[at]!] as ActionEntry["semantic"] | undefined;
    const plane = ACTION_PLANES[bytes[at + 1]!] as ActionEntry["plane"] | undefined;
    const activationKind = ACTIVATION_KINDS[bytes[at + 2]!] as ActionEntry["activationKind"] | undefined;
    if (!semantic || !plane || !activationKind) throw new FramePackError("BAD_OVERLAY", `action ${i} enum out of range`);
    if(activationKind==="manual"&&(canvas!==240||plane!=="base"))throw new FramePackError("BAD_OVERLAY","manual actions require a 240px base plane");
    const clip = view.getUint16(at + 4, true);
    const exitClip = view.getUint16(at + 6, true);
    const enterClip = (features & FP_FEATURE_ACTION_LIFECYCLE) !== 0 ? view.getUint16(at + 20, true) : ACTION_NO_CLIP;
    const performanceMask = (features & FP_FEATURE_PERFORMANCE_ACTIONS) !== 0 ? view.getUint16(at + 22, true) : 0;
    const validPerformanceMask = microCount === 16 ? 0xffff : (1 << microCount) - 1;
    if ((performanceMask & ~validPerformanceMask) !== 0) {
      throw new FramePackError("BAD_OVERLAY", `action ${i} performance mask invalid`);
    }
    const flags = view.getUint16(at + 8, true);
    if (clip >= clipCount || (enterClip !== ACTION_NO_CLIP && enterClip >= clipCount) || (exitClip !== ACTION_NO_CLIP && exitClip >= clipCount)) {
      throw new FramePackError("BAD_OVERLAY", `action ${i} clip out of range`);
    }
    if ((flags & ACTION_FLAG_PROFILE_MASK) === 0 || (flags & ~(ACTION_FLAG_PROFILE_MASK | ACTION_FLAG_ESSENTIAL | ACTION_FLAG_CENTER_ONLY)) !== 0) {
      throw new FramePackError("BAD_OVERLAY", `action ${i} flags invalid`);
    }
    const stateMask = view.getUint16(at + 10, true);
    const expressionMask = view.getUint16(at + 12, true);
    const intervalMinTicks = view.getUint16(at + 14, true);
    const intervalMaxTicks = view.getUint16(at + 16, true);
    if (stateMask === 0 || expressionMask === 0 || intervalMinTicks > intervalMaxTicks) {
      throw new FramePackError("BAD_OVERLAY", `action ${i} activation invalid`);
    }
    const reservedAt = (features & FP_FEATURE_PERFORMANCE_ACTIONS) !== 0 ? 24 :
      (features & FP_FEATURE_ACTION_LIFECYCLE) !== 0 ? 22 : 20;
    for (let p = reservedAt; p < OVERLAY_DIR_ENTRY_BYTES; p++) {
      if (bytes[at + p] !== 0) throw new FramePackError("BAD_OVERLAY", `action ${i} reserved byte nonzero`);
    }
    const verifyClipCodec = (clipIndex: number): void => {
      if (clipIndex === ACTION_NO_CLIP) return;
      for (const step of clips[clipIndex]!.steps) {
        const codec = frames[step.frame]!.codec;
        const valid = plane === "base"
          ? isFullCodec(codec)
          : isMaskedCodec(codec);
        if (!valid) throw new FramePackError("BAD_OVERLAY", `action ${i} frame codec mismatch`);
      }
    };
    verifyClipCodec(clip);
    verifyClipCodec(enterClip);
    verifyClipCodec(exitClip);
    if (enterClip !== ACTION_NO_CLIP && clips[enterClip]!.loopMode !== LOOP_ONCE) {
      throw new FramePackError("BAD_OVERLAY", `action ${i} enter clip must be loop-once`);
    }
    // Nothing interrupts an exit clip, so one that never ends would hold its
    // plane forever.
    if (exitClip !== ACTION_NO_CLIP && clips[exitClip]!.loopMode !== LOOP_ONCE) {
      throw new FramePackError("BAD_OVERLAY", `action ${i} exit clip must be loop-once`);
    }
    actions.push({
      id: clips[clip]!.name.replace(/^action\./, ""), semantic, plane, activationKind, clip, enterClip, exitClip,
      priority: bytes[at + 3]!, essential: (flags & ACTION_FLAG_ESSENTIAL) !== 0,
      profileMask: flags & ACTION_FLAG_PROFILE_MASK, stateMask, expressionMask, intervalMinTicks,
      intervalMaxTicks, cooldownTicks: view.getUint16(at + 18, true),
      performanceMask,
      posePolicy: (flags & ACTION_FLAG_CENTER_ONLY) ? "center-only" : "screen",
    });
  }

  let facialRegions: FacialRegionsEntry | undefined;
  if (canvas === 240 && (actions.filter(a => a.plane === "base").length > 64 || actions.filter(a => a.plane !== "base").length > 8)) {
    throw new FramePackError("BAD_OVERLAY", "exceeds 64 movements/eight effects");
  }
  const facialOffset=view.getUint32(HDR_FACIAL_OFFSET,true), facialLength=view.getUint32(HDR_FACIAL_LENGTH,true);
  if ((features & FP_FEATURE_FACIAL_REGIONS) !== 0) {
    if (facialLength < FACIAL_HEADER_BYTES) throw new FramePackError("BAD_FACIAL","facial section too short");
    requireBounds(facialOffset,facialLength,"facial section");
    const facialVersion = view.getUint16(facialOffset,true);
    if (facialVersion !== FACIAL_SECTION_VERSION && !(canvas === 240 && facialVersion === 2)) throw new FramePackError("BAD_FACIAL","unsupported facial section");
    if (facialVersion === 2 && Array.from(bytes.subarray(facialOffset+20,facialOffset+25)).some(t=>t<1||t>10)) throw new FramePackError("BAD_FACIAL","invalid independent blink timing");
    // The talk stage selects one of the seven mouth replacements.
    if (stageCount > FACIAL_MOUTH_STAGES) throw new FramePackError("BAD_FACIAL",`${stageCount} talk stages exceed ${FACIAL_MOUTH_STAGES} mouth replacements`);
    const count=bytes[facialOffset+2]!, center=bytes[facialOffset+3]!;
    if(count!==5 || center>=count || facialLength!==FACIAL_HEADER_BYTES+count*FACIAL_GROUP_BYTES) throw new FramePackError("BAD_FACIAL","invalid group directory");
    const directory=view.getUint32(facialOffset+52,true); if(directory!==facialOffset+FACIAL_HEADER_BYTES) throw new FramePackError("BAD_FACIAL","invalid group offset");
    const groups:FacialGroupEntry[]=[]; const roles=new Set<number>();
    for(let i=0;i<count;i++){const at=directory+i*FACIAL_GROUP_BYTES, role=bytes[at]!; if(role>4||roles.has(role))throw new FramePackError("BAD_FACIAL","invalid/duplicate role");roles.add(role); const baseFrame=view.getUint16(at+2,true);if(baseFrame>=frameCount||!isFullCodec(frames[baseFrame]!.codec))throw new FramePackError("BAD_FACIAL","invalid base frame"); const readRect=(o:number):FacialRect=>({x:bytes[o]!,y:bytes[o+1]!,width:bytes[o+2]!,height:bytes[o+3]!});const mouthRect=readRect(at+4),eyeRect=readRect(at+8); const valid=(r:FacialRect)=>r.width&&r.height&&r.x+r.width<=canvas&&r.y+r.height<=canvas;if(!valid(mouthRect)||!valid(eyeRect)||mouthRect.x<eyeRect.x+eyeRect.width&&mouthRect.x+mouthRect.width>eyeRect.x&&mouthRect.y<eyeRect.y+eyeRect.height&&mouthRect.y+mouthRect.height>eyeRect.y)throw new FramePackError("BAD_FACIAL","invalid/overlapping region"); const readFrames=(o:number,n:number,r:FacialRect)=>Array.from({length:n},(_,j)=>{const f=view.getUint16(o+j*2,true);const e=frames[f];if(!e||!isDenseCodec(e.codec))throw new FramePackError("BAD_FACIAL","invalid replacement frame");const d=bytes.subarray(e.offset,e.offset+e.length);if(d[0]!==r.x||d[1]!==r.y||d[2]!==r.width||d[3]!==r.height)throw new FramePackError("BAD_FACIAL","replacement rectangle mismatch");return f;});groups.push({role,baseFrame,mouthRect,eyeRect,mouthFrames:readFrames(at+12,7,mouthRect),eyeFrames:readFrames(at+26,5,eyeRect)});}
    const blinkGaps=Array.from({length:6},(_,i)=>view.getUint16(facialOffset+8+i*2,true)) as FacialRegionsEntry["blinkGaps"];
    const poseTimings=Array.from({length:8},(_,i)=>view.getUint16(facialOffset+36+i*2,true)) as FacialRegionsEntry["poseTimings"];
    if(blinkGaps.some((v,i)=>i%2===0&&v>=blinkGaps[i+1]!)||(facialVersion===1?poseTimings.some((v,i)=>i%2===0&&v>=poseTimings[i+1]!):poseTimings.some((v,i)=>i<5?(v<1||v>1818):v!==0)))throw new FramePackError("BAD_FACIAL","invalid timing range");
    facialRegions={...(facialVersion===2?{independentBlink:true,gazeStageTicks:poseTimings.slice(0,5)}:{}),groups,centerGroup:center,blinkStateMask:view.getUint16(facialOffset+4,true),blinkGaps,blinkStageTicks:Array.from(bytes.subarray(facialOffset+20,facialOffset+25)),poseStateMask:view.getUint16(facialOffset+26,true),bobStateMask:view.getUint16(facialOffset+30,true),bobFullAmplitude:bytes[facialOffset+32]!,bobBalancedAmplitude:bytes[facialOffset+33]!,bobPeriodTicks:view.getUint16(facialOffset+34,true),poseTimings};
  } else if(facialOffset!==0||facialLength!==0) throw new FramePackError("BAD_FACIAL","facial offsets without feature");

  // Check order mirrors frame_player.c fp_check_pack.
  let speakingPoses: SpeakingPoses | undefined;
  const speakingOffset = view.getUint32(HDR_SPEAKING_OFFSET, true);
  const speakingLength = view.getUint16(HDR_SPEAKING_LENGTH, true);
  if ((features & FP_FEATURE_SPEAKING_POSES) !== 0) {
    const bad = (why: string): never => { throw new FramePackError("BAD_SPEAKING", why); };
    if (canvas !== 240 || (features & FP_FEATURE_FACIAL_REGIONS) !== 0) bad("speaking poses require a 240px pack without facial regions");
    if (speakingLength < SPEAKING_HEADER_BYTES) bad("speaking section too short");
    requireBounds(speakingOffset, speakingLength, "speaking section");
    const at = speakingOffset;
    const poseCount = bytes[at + 1]!, stages = bytes[at + 2]!, gestureCount = bytes[at + 3]!, autoMask = bytes[at + 4]!;
    if (bytes[at] !== SPEAKING_SECTION_VERSION) bad("unsupported speaking section");
    if (bytes[at + 5] !== 0 || view.getUint16(at + 10, true) !== 0) bad("reserved speaking bytes are nonzero");
    if (poseCount < SPEAKING_MIN_POSES || poseCount > SPEAKING_MAX_POSES) bad(`pose count ${poseCount}`);
    if (stages !== stageCount) bad("speaking stages differ from the talk table");
    if (gestureCount < 1 || gestureCount > SPEAKING_MAX_GESTURES) bad(`gesture count ${gestureCount}`);
    if (autoMask === 0 || (autoMask >> gestureCount) !== 0) bad("invalid automatic gesture mask");
    const breakMinTicks = view.getUint16(at + 6, true), breakMaxTicks = view.getUint16(at + 8, true);
    if (breakMinTicks < 1 || breakMinTicks > breakMaxTicks || breakMaxTicks > SPEAKING_MAX_BREAK_TICKS) bad("invalid break range");
    const frameBytes = align4(poseCount * stages * 2);
    if (speakingLength !== SPEAKING_HEADER_BYTES + frameBytes + gestureCount * SPEAKING_GESTURE_BYTES) bad("speaking section length");
    const speakingFrames: number[][] = [];
    for (let pose = 0; pose < poseCount; pose++) {
      const row: number[] = [];
      for (let stage = 0; stage < stages; stage++) {
        const frame = view.getUint16(at + SPEAKING_HEADER_BYTES + (pose * stages + stage) * 2, true);
        if (frame >= frameCount || !fullFrame(frame)) bad(`pose ${pose} stage ${stage} frame ${frame}`);
        if (pose === 0 && frame !== stageFrames[stage]) bad("pose 0 differs from the talk table");
        row.push(frame);
      }
      speakingFrames.push(row);
    }
    for (let i = SPEAKING_HEADER_BYTES + poseCount * stages * 2; i < SPEAKING_HEADER_BYTES + frameBytes; i++) {
      if (bytes[at + i] !== 0) bad("speaking padding is nonzero");
    }
    const gestures: SpeakingGesture[] = [];
    for (let g = 0; g < gestureCount; g++) {
      const base = at + SPEAKING_HEADER_BYTES + frameBytes + g * SPEAKING_GESTURE_BYTES;
      const kind = bytes[base]!, stepCount = bytes[base + 1]!;
      if (kind >= SPEAKING_GESTURE_KINDS.length || stepCount < SPEAKING_MIN_GESTURE_STEPS || stepCount > SPEAKING_MAX_GESTURE_STEPS) {
        bad(`gesture ${g} kind or step count`);
      }
      const steps: SpeakingGestureStep[] = [];
      for (let j = 0; j < SPEAKING_MAX_GESTURE_STEPS; j++) {
        const pose = bytes[base + 2 + j * 2]!, ticks = bytes[base + 3 + j * 2]!;
        if (j < stepCount ? pose >= poseCount || ticks < 1 : pose !== 0 || ticks !== 0) bad(`gesture ${g} step ${j}`);
        if (j < stepCount) steps.push({ pose, ticks });
      }
      if (steps[0]!.pose !== 0 || steps[stepCount - 1]!.pose !== 0) bad(`gesture ${g} must start and end at pose 0`);
      if (bytes[base + 18] !== 0 || bytes[base + 19] !== 0) bad(`gesture ${g} reserved bytes are nonzero`);
      gestures.push({ kind: SPEAKING_GESTURE_KINDS[kind]!, steps, automatic: ((autoMask >> g) & 1) !== 0 });
    }
    speakingPoses = { frames: speakingFrames, gestures, breakMinTicks, breakMaxTicks };
  } else if (speakingOffset !== 0 || speakingLength !== 0) {
    throw new FramePackError("BAD_SPEAKING", "speaking offsets without feature");
  }

  const metaOffset = view.getUint32(HDR_META_OFFSET, true);
  const metaLength = view.getUint32(HDR_META_LENGTH, true);
  let meta: unknown = null;
  if (metaLength > 0) {
    requireBounds(metaOffset, metaLength, "meta");
    try {
      meta = JSON.parse(decoder.decode(bytes.subarray(metaOffset, metaOffset + metaLength)));
    } catch {
      // The device only bounds-checks meta and never parses it; stay in
      // lockstep with fp_validate by tolerating unparseable meta here too.
      meta = null;
    }
  }

  const id = readString(view.getUint32(HDR_ID_STR_OFFSET, true), view.getUint16(HDR_ID_STR_LEN, true), "id");
  const name = readString(view.getUint32(HDR_NAME_STR_OFFSET, true), view.getUint16(HDR_NAME_STR_LEN, true), "name");
  const version = readString(
    view.getUint32(HDR_VERSION_STR_OFFSET, true),
    view.getUint16(HDR_VERSION_STR_LEN, true),
    "version",
  );

  return {
    info: {
      formatVersion,
      width: canvas,
      height: canvas,
      id,
      name,
      version,
      gender,
      approved: (features & FRAME_FLAG_APPROVED) !== 0,
      features,
      tickMs: view.getUint16(HDR_TICK_MS, true),
      paletteCount,
      bgPaletteIndex,
      frameCount,
      clipCount,
      emotionCount,
      overlayCount,
      fileLength,
      payloadCrc32,
    },
    paletteRgb565,
    paletteRgb,
    frames,
    clips,
    roles,
    emotions,
    talk: { stageFrames, levelToStage },
    idle: {
      bobAmplitudePx, bobPeriodTicks, microGapMinTicks, microGapMaxTicks, micro,
      fallbacksEnabled: (motionFlags & 1) !== 0,
      parallaxSafe: (motionFlags & 2) !== 0,
      maxParallaxPx,
    },
    actions,
    ...(facialRegions ? { facialRegions } : {}),
    ...(speakingPoses ? { speakingPoses } : {}),
    meta,
    bytes,
    decodeFrame(index: number): Uint8Array {
      const frame = frames[index];
      if (!frame) throw new RangeError(`frame ${index} out of range`);
      const data = bytes.subarray(frame.offset, frame.offset + frame.length);
      if (isZlibCodec(frame.codec)) return decodeZlibResource(frame.codec, data, canvas);
      if (frame.codec === FRAME_CODEC_INDEX8_FULL_RLE) {
        const out = new Uint8Array(canvas * canvas); let at = 0;
        for (let p = 0; p < data.length; p += 2) out.fill(data[p + 1]!, at, at += data[p]!);
        return out;
      }
      if (frame.codec === FRAME_CODEC_INDEX8_MASKED_RECT_RLE) {
        const { maskBytes } = maskedRectInfo(data, canvas); const start = 4 + maskBytes;
        let opaque = 0; for (let p = 0; p < data[2]! * data[3]!; p++) opaque += (data[4 + (p >> 3)]! >> (p & 7)) & 1;
        const out = new Uint8Array(start + opaque); out.set(data.subarray(0, start)); let at = start;
        for (let p = start; p < data.length; p += 2) out.fill(data[p + 1]!, at, at += data[p]!);
        return out;
      }
      return data;
    },
  };
}
