import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import { join } from "node:path";
import {
  ACTION_FLAG_ESSENTIAL,
  ACTION_NO_CLIP,
  ACTION_PLANE_CODES,
  ACTION_SEMANTIC_CODES,
  ACTIVATION_CODES,
  EMOTION_IDS,
  FRAME_CODEC_INDEX8_FULL,
  FRAME_CODEC_INDEX8_MASKED_RECT,
  FRAME_CODEC_INDEX8_DENSE_RECT,
  FRAME_CODEC_INDEX8_FULL_RLE,
  FRAME_CODEC_INDEX8_MASKED_RECT_RLE,
  FACIAL_GROUP_ROLES,
  FRAME_PACK_CANVAS,
  FRAME_PACK_TICK_MS,
  GENDER_CODES,
  LOOP_HOLD_LAST,
  LOOP_LOOP,
  LOOP_ONCE,
  ROLE_ABSENT,
  ROLE_COUNT,
  ROLE_IDLE_NEUTRAL,
  TALK_LUT_BYTES,
  PROFILE_BITS,
} from "./constants.js";
import { crc32 } from "./crc32.js";
import { deflateResource, smallestFrameResource } from "./frame-codec-encode.js";
import { align, ALIGN_RADIUS, within } from "./ingest/align.js";
import { buildNativeProtectedPalette, buildReservedPalette, from565, to565, weightedDistance } from "./ingest/palette.js";
import { loadPng, readDeviceGrid, type Rgb, type RgbaImage } from "./ingest/png.js";
import { detectGrid, rectify, type GridReport } from "./ingest/rectify.js";
import { parseCharacterManifest, type CharacterManifest, type SourceRef } from "./schema.js";
import { resolveEffectiveEffectProfile, type EffectiveEffectProfile } from "./effect-profile.js";
import { writeFramePack, type ActionEntry, type Clip, type EmotionEntry, type FramePackModel, type FrameResource, type SpeakingPoses } from "./binary.js";



const BG_TOLERANCE = 28;
/** Outer band (px) compared against the neutral frame's own band. */
const BG_BAND = 4;

function encodeRle(values: Uint8Array | number[]): Uint8Array {
  const out: number[] = [];
  for (let at = 0; at < values.length;) {
    const value = values[at]!;
    let run = 1;
    while (at + run < values.length && values[at + run] === value && run < 255) run++;
    out.push(run, value);
    at += run;
  }
  return Uint8Array.from(out);
}
/** Outer ring (px) whose mode color defines the background. */
const BG_RING = 2;
const BAND_COHERENCE_WARN = 0.97;
const BAND_COHERENCE_HARD = 0.9;
const IOU_HARD = 0.7;
const IOU_WARN = 0.85;
// A 30 dB source-to-indexed RGB565 floor, expressed in the palette metric.
// Native device artwork is not assumed to have a flat border/background.
const NATIVE_MAX_MEAN_WEIGHTED_ERROR = 7 * 255 * 255 / 1000;
const nativePsnr = (meanWeightedError: number): number =>
  meanWeightedError === 0 ? Infinity : 10 * Math.log10(7 * 255 * 255 / meanWeightedError);

export type GateVerdict = "pass" | "warn" | "fail";

export interface GateResult {
  gate: string;
  subject: string;
  verdict: GateVerdict;
  detail: string;
}

export interface SourceFrame {
  /** Stable key: source role, e.g. "neutral", "talk[3]", "emotion.joy.onset". */
  key: string;
  file: string;
  pixels: Rgb[];
  /** 1 where the pixel was classified background and snapped to the bg color. */
  bgMask: Uint8Array;
  shift: [number, number];
  grid: GridReport | null;
}

type ActionSourceStep = { frame: SourceRef; durationMs: number };

export interface CompileResult {
  manifest: CharacterManifest;
  model: FramePackModel;
  pack: Uint8Array;
  gates: GateResult[];
  report: Record<string, unknown>;
  /** For preview rendering: every unique frame as palette indices. */
  frames: Uint8Array[];
  palette: Rgb[];
  sources: SourceFrame[];
  /** key -> frame bank index. */
  frameIndexByKey: Map<string, number>;
  /**
   * Effect overlay key ("action.<id>.main[i]" / "action.<id>.exit[i]") ->
   * index into `model.frames` (FRAME_CODEC_INDEX8_MASKED_RECT resources).
   */
  effectFrameIndexByKey: Map<string, number>;
}

interface EffectSource {
  key: string;
  file: string;
  image: RgbaImage;
  colors: Rgb[];
}
interface DenseSource { key:string; file:string; image:RgbaImage; colors:Rgb[] }

function loadDenseSource(characterDir:string,file:string,lock:LockFile,key:string,width:number,height:number):DenseSource {
  const ref={file,kind:"device-grid"} as SourceRef; const path=verifyLockedFile(characterDir,ref,lock,key); const image=loadPng(path);
  if(image.width!==width||image.height!==height) throw new Error(`${key}: expected ${width}x${height} dense patch`);
  const colors:Rgb[]=[]; for(let i=0;i<width*height;i++){if(image.data[i*4+3]!==255)throw new Error(`${key}: dense patch must be opaque`);colors.push([image.data[i*4]!,image.data[i*4+1]!,image.data[i*4+2]!]);}
  return {key,file,image,colors};
}

interface LockFile {
  origin: { repoBranch: string; commit: string; path?: string };
  files: Record<string, { sha256: string; bytes: number }>;
}

const sha256 = (bytes: Uint8Array): string => createHash("sha256").update(bytes).digest("hex");

export const msToTicks = (ms: number): number => Math.max(1, Math.round(ms / FRAME_PACK_TICK_MS));

function loadSource(
  characterDir: string,
  ref: SourceRef,
  lock: LockFile,
  label: string,
  CANVAS = FRAME_PACK_CANVAS,
): { pixels: Rgb[]; grid: GridReport | null } {
  const path = join(characterDir, ref.file);
  const raw = readFileSync(path);
  const relative = ref.file.replace(/^source[\\/]/, "");
  const locked = lock.files[relative];
  if (!locked) throw new Error(`${label}: ${relative} is not in SOURCES.lock.json — ingest real, locked art only`);
  const digest = sha256(raw);
  if (digest !== locked.sha256) {
    throw new Error(
      `${label}: ${relative} sha256 ${digest} does not match SOURCES.lock.json (${locked.sha256}); art must never be silently swapped`,
    );
  }
  const img = loadPng(path);
  if (ref.kind === "device-grid") {
    return { pixels: readDeviceGrid(img, CANVAS, label), grid: null };
  }
  return { pixels: rectify(img, CANVAS), grid: detectGrid(img) };
}

function verifyLockedFile(characterDir: string, ref: SourceRef, lock: LockFile, label: string): string {
  const path = join(characterDir, ref.file);
  const raw = readFileSync(path);
  const relative = ref.file.replace(/^source[\\/]/, "");
  const locked = lock.files[relative];
  if (!locked) throw new Error(`${label}: ${relative} is not in SOURCES.lock.json`);
  const digest = sha256(raw);
  if (digest !== locked.sha256) throw new Error(`${label}: ${relative} sha256 does not match SOURCES.lock.json`);
  return path;
}

function loadEffectSource(characterDir: string, ref: SourceRef, lock: LockFile, key: string, CANVAS: number): EffectSource {
  if (ref.kind !== "device-grid") throw new Error(`${key}: effect overlays must be device-grid PNGs`);
  const path = verifyLockedFile(characterDir, ref, lock, key);
  const image = loadPng(path);
  if (image.width !== CANVAS || image.height !== CANVAS) throw new Error(`${key}: expected ${CANVAS}x${CANVAS} overlay`);
  const colors: Rgb[] = [];
  for (let i = 0; i < CANVAS * CANVAS; i++) {
    const alpha = image.data[i * 4 + 3]!;
    if (alpha !== 0 && alpha !== 255) throw new Error(`${key}: alpha must be exactly 0 or 255`);
    if (alpha === 255) colors.push([image.data[i * 4]!, image.data[i * 4 + 1]!, image.data[i * 4 + 2]!]);
  }
  return { key, file: ref.file, image, colors };
}

const STATE_BITS: Record<string, number> = {
  booting: 1 << 0,
  provisioning: 1 << 1,
  connecting: 1 << 2,
  idle: 1 << 3,
  listening: 1 << 4,
  thinking: 1 << 5,
  speaking: 1 << 6,
  offline: 1 << 7,
  error: 1 << 8,
};

function expressionBit(name: string): number {
  return name === "neutral" ? 1 : 1 << EMOTION_IDS[name]!;
}

/** Most common exact RGB in the outer `ring`-px border of a frame. */
function borderModeColor(pixels: Rgb[], ring: number, CANVAS: number): Rgb {
  const counts = new Map<number, { rgb: Rgb; count: number }>();
  for (let y = 0; y < CANVAS; y++) {
    for (let x = 0; x < CANVAS; x++) {
      if (x >= ring && x < CANVAS - ring && y >= ring && y < CANVAS - ring) continue;
      const px = pixels[y * CANVAS + x]!;
      const key = (px[0] << 16) | (px[1] << 8) | px[2];
      const entry = counts.get(key);
      if (entry) entry.count++;
      else counts.set(key, { rgb: px, count: 1 });
    }
  }
  let top: { rgb: Rgb; count: number } | null = null;
  for (const entry of counts.values()) if (!top || entry.count > top.count) top = entry;
  return top!.rgb;
}

/**
 * Background normalization: 4-neighbor flood fill from every border pixel
 * that is within tolerance of the background color; every reached pixel is
 * snapped to exactly `bg`. This makes the background bit-stable across every
 * frame of the bank (no cross-generation cyan noise, no border shimmer, one
 * palette entry) and is what makes whole-frame offset motion safe. Interior
 * colors similar to the background (Pablo's blue eyes) are safe because the
 * fill only reaches border-connected regions.
 */
function normalizeBackground(pixels: Rgb[], bg: Rgb, CANVAS: number): { out: Rgb[]; mask: Uint8Array } {
  const mask = new Uint8Array(CANVAS * CANVAS);
  const queue: number[] = [];
  for (let x = 0; x < CANVAS; x++) {
    for (const y of [0, CANVAS - 1]) {
      const at = y * CANVAS + x;
      if (!mask[at] && within(pixels[at]!, bg, BG_TOLERANCE)) {
        mask[at] = 1;
        queue.push(at);
      }
    }
  }
  for (let y = 0; y < CANVAS; y++) {
    for (const x of [0, CANVAS - 1]) {
      const at = y * CANVAS + x;
      if (!mask[at] && within(pixels[at]!, bg, BG_TOLERANCE)) {
        mask[at] = 1;
        queue.push(at);
      }
    }
  }
  while (queue.length > 0) {
    const at = queue.pop()!;
    const x = at % CANVAS;
    const y = (at / CANVAS) | 0;
    for (const [nx, ny] of [
      [x - 1, y],
      [x + 1, y],
      [x, y - 1],
      [x, y + 1],
    ] as const) {
      if (nx < 0 || nx >= CANVAS || ny < 0 || ny >= CANVAS) continue;
      const n = ny * CANVAS + nx;
      if (!mask[n] && within(pixels[n]!, bg, BG_TOLERANCE)) {
        mask[n] = 1;
        queue.push(n);
      }
    }
  }
  const out = pixels.map((px, i) => (mask[i] ? bg : px));
  return { out, mask };
}

/** Fraction of border-band pixels that match the neutral frame's band art. */
function bandCoherence(pixels: Rgb[], neutral: Rgb[], CANVAS: number): number {
  let inBand = 0;
  let coherent = 0;
  for (let y = 0; y < CANVAS; y++) {
    for (let x = 0; x < CANVAS; x++) {
      if (x >= BG_BAND && x < CANVAS - BG_BAND && y >= BG_BAND && y < CANVAS - BG_BAND) continue;
      inBand++;
      if (within(pixels[y * CANVAS + x]!, neutral[y * CANVAS + x]!, BG_TOLERANCE)) coherent++;
    }
  }
  return coherent / inBand;
}

function iou(a: Uint8Array, b: Uint8Array): number {
  let inter = 0;
  let union = 0;
  for (let i = 0; i < a.length; i++) {
    const av = a[i]!;
    const bv = b[i]!;
    if (av && bv) inter++;
    if (av || bv) union++;
  }
  return union === 0 ? 1 : inter / union;
}

export function compileCharacter(
  characterDir: string,
  manifestFile = "character.json",
  options: { reviewCandidate?: boolean; sourceLockFile?: string; preserveDevicePixels?: boolean } = {},
): CompileResult {
  const authoredManifest = JSON.parse(readFileSync(join(characterDir, manifestFile), "utf8")) as Record<string, unknown>;
  let effectiveProfile: EffectiveEffectProfile | undefined;
  const rawManifest = authoredManifest.effectProfile
    ? (effectiveProfile = resolveEffectiveEffectProfile(characterDir, authoredManifest)).manifest
    : authoredManifest;
  const { manifest, issues } = parseCharacterManifest(rawManifest);
  if (issues.length > 0) {
    throw new Error(`${manifestFile} invalid:\n${issues.map((i) => `  ${i.path}: ${i.message}`).join("\n")}`);
  }
  const CANVAS = manifest.canvas.width;
  const PIXELS = CANVAS * CANVAS;
  const nativePixelReview = CANVAS === 240 && options.preserveDevicePixels === true &&
    (options.reviewCandidate === true || manifest.approval.status === "approved");
  const lock = JSON.parse(readFileSync(join(characterDir, options.sourceLockFile ?? "SOURCES.lock.json"), "utf8")) as LockFile;
  if (effectiveProfile) Object.assign(lock.files, effectiveProfile.lockFiles);
  const gates: GateResult[] = [];
  const gate = (g: GateResult): void => {
    gates.push(g);
  };

  // ---- Load + normalize the neutral base ---------------------------------
  const neutralSource = loadSource(characterDir, manifest.neutral, lock, "neutral", CANVAS);
  const bgColor = borderModeColor(neutralSource.pixels, BG_RING, CANVAS);
  const neutralNormalized = normalizeBackground(neutralSource.pixels, bgColor, CANVAS);
  const neutral: SourceFrame = {
    key: "neutral",
    file: manifest.neutral.file,
    pixels: options.preserveDevicePixels ? neutralSource.pixels : neutralNormalized.out,
    bgMask: neutralNormalized.mask,
    shift: [0, 0],
    grid: neutralSource.grid,
  };

  // ---- Load talk stages --------------------------------------------------
  const sources: SourceFrame[] = [neutral];
  // Reverse timelines and shared holds refer to the same file repeatedly.
  // Reuse immutable pixels/masks while retaining every source/timing entry and
  // palette census occurrence; this does not change palette weighting.
  const loadedFrames = new Map<string, SourceFrame>();
  const loadFrame = (ref: SourceRef, key: string): SourceFrame => {
    const cacheKey=JSON.stringify(ref),cached=loadedFrames.get(cacheKey);
    if(cached)return {...cached,key};
    const loaded = loadSource(characterDir, ref, lock, key, CANVAS);
    let pixels = loaded.pixels;
    let shift: [number, number] = [0, 0];
    if (ref.kind === "render") {
      const aligned = align(loaded.pixels, neutral.pixels, CANVAS);
      pixels = aligned.aligned;
      shift = [aligned.dx, aligned.dy];
    }
    const normalized = normalizeBackground(pixels, bgColor, CANVAS);
    const frame={ key, file: ref.file, pixels: options.preserveDevicePixels ? pixels : normalized.out, bgMask: normalized.mask, shift, grid: loaded.grid };
    loadedFrames.set(cacheKey,frame);return frame;
  };
  const cleanPlate = manifest.cleanPlate ? loadFrame(manifest.cleanPlate, "cleanPlate") : undefined;
  if (cleanPlate) sources.push(cleanPlate);
  const talkSources: SourceFrame[] = [];
  for (const [i, ref] of manifest.talk.stages.entries()) {
    if (ref.file === manifest.neutral.file) {
      talkSources.push(neutral);
      continue;
    }
    const frame = loadFrame(ref, `talk[${i}]`);
    talkSources.push(frame);
    sources.push(frame);
  }
  // Speaking poses: complete speech frames, one row per head/eye pose.
  const poseSources: SourceFrame[][] = manifest.talk.poses.map((pose) => pose.stages.map((ref, i) => {
    if (ref.file === manifest.neutral.file) return neutral;
    const frame = loadFrame(ref, `talk.${pose.id}[${i}]`);
    sources.push(frame);
    return frame;
  }));
  const facialSources = manifest.facialRegions?.groups.map((group) => ({
    def: group,
    base: loadFrame(group.base, `facial.${group.id}.base`),
    mouth: group.mouth.frames.map((file,i)=>loadDenseSource(characterDir,file,lock,`facial.${group.id}.mouth[${i}]`,group.mouth.rect.width,group.mouth.rect.height)),
    eyes: group.eyes.frames.map((file,i)=>loadDenseSource(characterDir,file,lock,`facial.${group.id}.eyes[${i}]`,group.eyes.rect.width,group.eyes.rect.height)),
  })) ?? [];
  for(const group of facialSources) sources.push(group.base);

  // ---- Load + align emotion frames --------------------------------------
  const emotionNames = Object.keys(manifest.emotions).sort((a, b) => EMOTION_IDS[a]! - EMOTION_IDS[b]!);
  const emotionSources = new Map<string,
    | { kind: "legacy"; onset: SourceFrame; full: SourceFrame }
    | { kind: "detailed"; enter: { frame: SourceFrame; durationTicks: number }[]; hold: { frame: SourceFrame; durationTicks: number }[]; exit: { frame: SourceFrame; durationTicks: number }[] }
  >();
  for (const name of emotionNames) {
    const def = manifest.emotions[name]!;
    if ("enterSteps" in def) {
      const loadSteps = (phase: "enter" | "hold" | "exit", steps: typeof def.enterSteps) => steps.map((step, index) => {
        const frame = loadFrame(step.frame, `emotion.${name}.${phase}[${index}]`);
        sources.push(frame);
        return { frame, durationTicks: msToTicks(step.durationMs) };
      });
      emotionSources.set(name, {
        kind: "detailed",
        enter: loadSteps("enter", def.enterSteps),
        hold: loadSteps("hold", def.holdSteps),
        exit: loadSteps("exit", def.exitSteps),
      });
    } else {
      const onset = loadFrame(def.onset, `emotion.${name}.onset`);
      const full = loadFrame(def.full, `emotion.${name}.full`);
      emotionSources.set(name, { kind: "legacy", onset, full });
      sources.push(onset, full);
    }
  }
  const performanceSources = new Map<
    string,
    { frame: SourceFrame; durationTicks: number }[]
  >();
  for (const performance of manifest.idle.performances) {
    const steps = performance.steps.map((step, index) => {
      const frame = loadFrame(step.frame, `performance.${performance.id}[${index}]`);
      sources.push(frame);
      return { frame, durationTicks: msToTicks(step.durationMs) };
    });
    performanceSources.set(performance.id, steps);
  }
  const baseActionSources = new Map<string, { frame: SourceFrame; durationTicks: number }[]>();
  const baseActionEnterSources = new Map<string, { frame: SourceFrame; durationTicks: number }[]>();
  const baseActionExitSources = new Map<string, { frame: SourceFrame; durationTicks: number }[]>();
  const effectActionSources = new Map<string, { frame: EffectSource; durationTicks: number }[]>();
  const effectActionEnterSources = new Map<string, { frame: EffectSource; durationTicks: number }[]>();
  const effectActionExitSources = new Map<string, { frame: EffectSource; durationTicks: number }[]>();
  for (const action of manifest.actions) {
    if (action.plane === "base") {
      const load = (step: ActionSourceStep, index: number, phase: "enter" | "main" | "exit") => {
        const frame = loadFrame(step.frame, `action.${action.id}.${phase}[${index}]`);
        sources.push(frame);
        return { frame, durationTicks: msToTicks(step.durationMs) };
      };
      if ("enterSteps" in action) {
        baseActionEnterSources.set(action.id, action.enterSteps.map((step, index) => load(step, index, "enter")));
        baseActionSources.set(action.id, action.holdSteps.map((step, index) => load(step, index, "main")));
        baseActionExitSources.set(action.id, action.exitSteps.map((step, index) => load(step, index, "exit")));
      } else {
        baseActionSources.set(action.id, action.steps.map((step, index) => load(step, index, "main")));
        if (action.exitSteps) baseActionExitSources.set(action.id, action.exitSteps.map((step, index) => load(step, index, "exit")));
      }
    } else {
      const load = (step: ActionSourceStep, index: number, phase: "enter" | "main" | "exit") => ({
        frame: loadEffectSource(characterDir, step.frame, lock, `action.${action.id}.${phase}[${index}]`, CANVAS),
        durationTicks: msToTicks(step.durationMs),
      });
      if ("enterSteps" in action) {
        effectActionEnterSources.set(action.id, action.enterSteps.map((step, index) => load(step, index, "enter")));
        effectActionSources.set(action.id, action.holdSteps.map((step, index) => load(step, index, "main")));
        effectActionExitSources.set(action.id, action.exitSteps.map((step, index) => load(step, index, "exit")));
      } else {
        effectActionSources.set(action.id, action.steps.map((step, index) => load(step, index, "main")));
        if (action.exitSteps) effectActionExitSources.set(action.id, action.exitSteps.map((step, index) => load(step, index, "exit")));
      }
    }
  }

  // ---- Pre-palette gates -------------------------------------------------
  // Anchor gate against flood-fill leaks: if the background fill escaped into
  // interior art (or barely filled at all), the neutral background fraction
  // leaves the plausible range for a portrait and every relative gate
  // downstream (IoU, uniformity) would be comparing corrupted masks.
  const neutralBgPixels = neutral.bgMask.reduce((n, v) => n + v, 0);
  const neutralBgFraction = neutralBgPixels / PIXELS;
  // Small native full-body sprites deliberately reserve room for movement.
  // Keep sparse art reviewable, never silently pass a possible flood-fill leak.
  // Legacy normalized portraits retain their original hard boundary.
  const sparseNativeBackground = nativePixelReview && neutralBgFraction > 0.85 && neutralBgFraction <= 0.95;
  gate({
    gate: "background-extent",
    subject: "neutral",
    verdict: neutralBgFraction >= 0.08 && neutralBgFraction <= 0.85 ? "pass" : sparseNativeBackground ? "warn" : "fail",
    detail: `background flood covers ${(neutralBgFraction * 100).toFixed(1)}% of the canvas` +
      (sparseNativeBackground ? "; sparse locked native sprite: inspect the complete silhouette and movement clearance for flood-fill leaks before approval" : ""),
  });
  const neutralSilhouette = new Uint8Array(PIXELS);
  for (let i = 0; i < PIXELS; i++) neutralSilhouette[i] = neutral.bgMask[i] ? 0 : 1;
  for (const frame of sources) {
    if (frame === neutral) continue;
    const [dx, dy] = frame.shift;
    const atBoundary = Math.abs(dx) >= ALIGN_RADIUS || Math.abs(dy) >= ALIGN_RADIUS;
    const approvedPerformance = frame.key.startsWith("performance.");
    gate({
      gate: "alignment",
      subject: frame.key,
      verdict: atBoundary ? (approvedPerformance ? "warn" : "fail") : "pass",
      detail: `shift (${dx},${dy})${atBoundary ? approvedPerformance ? " — approved full-frame performance reaches the alignment review boundary" : " — hit search boundary, likely reframed render" : ""}`,
    });
    if (frame.key.startsWith("facial.")) {
      gate({ gate: "registered-facial-transform", subject: frame.key, verdict: "pass", detail: "deterministic nearest-neighbor pivot transform; replacement banks are certified against this base" });
      continue;
    }
    const coherence = bandCoherence(frame.pixels, neutral.pixels, CANVAS);
    gate({
      gate: "band-coherence",
      subject: frame.key,
      verdict: coherence >= BAND_COHERENCE_WARN ? "pass" : nativePixelReview || coherence >= BAND_COHERENCE_HARD ? "warn" : "fail",
      detail: `${(coherence * 100).toFixed(2)}% of the border band matches the neutral frame's band art` +
        (nativePixelReview && coherence < BAND_COHERENCE_WARN ? "; retained native artwork may intentionally vary; source-to-device fidelity is checked after palette conversion and this difference remains for human review" : ""),
    });
    const silhouette = new Uint8Array(PIXELS);
    for (let i = 0; i < PIXELS; i++) silhouette[i] = frame.bgMask[i] ? 0 : 1;
    const overlap = iou(silhouette, neutralSilhouette);
    const approvedExactDeviceFrame = (manifest.approval.status === "approved" || options.reviewCandidate === true) && frame.grid === null;
    gate({
      gate: "silhouette-iou",
      subject: frame.key,
      verdict: overlap >= IOU_WARN ? "pass" : overlap >= IOU_HARD || approvedExactDeviceFrame ? "warn" : "fail",
      detail: `IoU ${overlap.toFixed(3)} vs neutral silhouette${approvedExactDeviceFrame && overlap < IOU_HARD ? options.reviewCandidate && manifest.approval.status !== "approved" ? " — exact locked device frame retained for candidate review" : " — exact locked device frame approved by reviewer" : ""}`,
    });
  }

  // ---- Palette: talk colors reserved exactly, emotions cut into the rest -
  const talkFramePixels = [neutral, ...talkSources.filter((f) => f !== neutral)].map((f) => f.pixels);
  for (const row of poseSources) for (const frame of row) if (frame !== neutral) talkFramePixels.push(frame.pixels);
  if (cleanPlate) talkFramePixels.push(cleanPlate.pixels);
  const expressiveFramePixels = emotionNames.flatMap((name) => {
    const entry = emotionSources.get(name)!;
    return entry.kind === "legacy"
      ? [entry.onset.pixels, entry.full.pixels]
      : [...entry.enter, ...entry.hold, ...entry.exit].map((step) => step.frame.pixels);
  });
  for (const performance of manifest.idle.performances) {
    for (const step of performanceSources.get(performance.id)!) {
      expressiveFramePixels.push(step.frame.pixels);
    }
  }
  for (const steps of baseActionSources.values()) for (const step of steps) expressiveFramePixels.push(step.frame.pixels);
  for (const steps of baseActionExitSources.values()) for (const step of steps) expressiveFramePixels.push(step.frame.pixels);
  for (const steps of effectActionSources.values()) for (const step of steps) expressiveFramePixels.push(step.frame.colors);
  for (const steps of effectActionExitSources.values()) for (const step of steps) expressiveFramePixels.push(step.frame.colors);
  for(const group of facialSources){talkFramePixels.push(group.base.pixels,...group.mouth.map(f=>f.colors));expressiveFramePixels.push(...group.eyes.map(f=>f.colors));}
  const criticalResources: Rgb[][] = [];
  if (nativePixelReview) {
    const seenCriticalFiles = new Set<string>();
    const addCritical = (frame: { file: string; colors: Rgb[] }) => {
      if (seenCriticalFiles.has(frame.file)) return;
      seenCriticalFiles.add(frame.file);
      criticalResources.push(frame.colors);
    };
    for (const group of facialSources) for (const frame of [...group.mouth, ...group.eyes]) addCritical(frame);
    for (const map of [effectActionEnterSources, effectActionSources, effectActionExitSources])
      for (const steps of map.values()) for (const step of steps) addCritical(step.frame);
  }
  const paletteResult = nativePixelReview
    ? buildNativeProtectedPalette(talkFramePixels, expressiveFramePixels, criticalResources, manifest.palette.maxColors, manifest.palette.talkReserve,
      Math.min(48, Math.floor(manifest.palette.maxColors / 4), manifest.palette.talkReserve))
    : buildReservedPalette(talkFramePixels, expressiveFramePixels, manifest.palette.maxColors, manifest.palette.talkReserve);
  const { palette, indexOf } = paletteResult;
  const meanErrorOver = (framesPixels: Rgb[][]): number => {
    let total = 0;
    let count = 0;
    for (const framePixels of framesPixels) {
      for (const px of framePixels) {
        // Measure against the RGB565-snapped source: the lattice snap is
        // inherent to the format, so it must not count as palette error
        // (otherwise non-lattice source art can never pass exactness).
        total += weightedDistance(from565(to565(px)), palette[indexOf(px)]!);
        count++;
      }
    }
    return total / count;
  };
  const talkMeanError = meanErrorOver(talkFramePixels);
  const emotionMeanError = meanErrorOver(expressiveFramePixels);
  if (nativePixelReview) {
    const resourceFidelity = (kind: "facial-patch" | "effect-overlay", key: string, colors: Rgb[]): void => {
      if (colors.length === 0) {
        gate({ gate: `native-${kind}-fidelity`, subject: key, verdict: "pass", detail: "fully transparent; no palette colors to lose" });
        return;
      }
      const mean = meanErrorOver([colors]);
      gate({
        gate: `native-${kind}-fidelity`,
        subject: key,
        verdict: mean <= NATIVE_MAX_MEAN_WEIGHTED_ERROR ? "pass" : "fail",
        detail: `RGB565 source-to-indexed fidelity ${nativePsnr(mean).toFixed(2)} dB (minimum 30 dB); mean weighted error ${mean.toFixed(3)}`,
      });
    };
    for (const group of facialSources) for (const frame of [...group.mouth, ...group.eyes])
      resourceFidelity("facial-patch", frame.key, frame.colors);
    for (const map of [effectActionEnterSources, effectActionSources, effectActionExitSources])
      for (const steps of map.values()) for (const step of steps)
        resourceFidelity("effect-overlay", step.frame.key, step.frame.colors);
  }
  // reserved-exact must be bit-perfect; reserved-topk snaps only rare talk
  // colors to near neighbors (Pablo measured 0.11 at reserve 180) — the hard
  // ceiling of 2.0 catches future art whose color population is less top-heavy.
  gate({
    gate: nativePixelReview ? "talk-source-fidelity" : "talk-palette-exactness",
    subject: "talk frames",
    verdict: nativePixelReview
      ? talkMeanError <= NATIVE_MAX_MEAN_WEIGHTED_ERROR ? "pass" : "fail"
      : paletteResult.strategy === "reserved-exact"
        ? talkMeanError === 0
          ? "pass"
          : "fail"
        : talkMeanError <= 0.5
          ? "pass"
          : talkMeanError <= 2.0
            ? "warn"
            : "fail",
    detail: `${paletteResult.strategy} (${paletteResult.reservedCount} reserved); talk mean weighted error ${talkMeanError.toFixed(3)}, emotion ${emotionMeanError.toFixed(1)}` +
      (nativePixelReview ? `; RGB565 source-to-indexed fidelity ${nativePsnr(talkMeanError).toFixed(2)} dB (minimum 30 dB); exact compiled pixels still require human approval` : ""),
  });

  // ---- Index frames through the palette, dedupe by content ---------------
  const frameBank: Uint8Array[] = [];
  const frameIndexByKey = new Map<string, number>();
  const frameIndexByDigest = new Map<string, number>();
  const indexFrame = (frame: SourceFrame): number => {
    const existingByKey = frameIndexByKey.get(frame.key);
    if (existingByKey !== undefined) return existingByKey;
    const indexed = new Uint8Array(PIXELS);
    for (let i = 0; i < PIXELS; i++) indexed[i] = indexOf(frame.pixels[i]!);
    const digest = sha256(indexed);
    let bankIndex = frameIndexByDigest.get(digest);
    if (bankIndex === undefined) {
      bankIndex = frameBank.length;
      frameBank.push(indexed);
      frameIndexByDigest.set(digest, bankIndex);
    }
    frameIndexByKey.set(frame.key, bankIndex);
    return bankIndex;
  };
  const neutralFrame = indexFrame(neutral);
  const talkFrames = talkSources.map((f) => indexFrame(f));
  const poseFrames = poseSources.map((row) => row.map((f) => indexFrame(f)));
  const cleanPlateFrame = cleanPlate ? indexFrame(cleanPlate) : undefined;
  for (const name of emotionNames) {
    const entry = emotionSources.get(name)!;
    if (entry.kind === "legacy") {
      indexFrame(entry.onset);
      indexFrame(entry.full);
    } else {
      for (const step of [...entry.enter, ...entry.hold, ...entry.exit]) indexFrame(step.frame);
    }
  }
  for (const performance of manifest.idle.performances) {
    for (const step of performanceSources.get(performance.id)!) {
      indexFrame(step.frame);
    }
  }
  for (const steps of baseActionSources.values()) for (const step of steps) indexFrame(step.frame);
  for (const steps of baseActionEnterSources.values()) for (const step of steps) indexFrame(step.frame);
  for (const steps of baseActionExitSources.values()) for (const step of steps) indexFrame(step.frame);
  for(const group of facialSources) indexFrame(group.base);

  const frameResources: FrameResource[] = frameBank.map((data) => {
    const rle = encodeRle(data);
    const legacy = rle.length < data.length ? { codec: FRAME_CODEC_INDEX8_FULL_RLE, data: rle } : { codec: FRAME_CODEC_INDEX8_FULL, data };
    return CANVAS === 240 ? smallestFrameResource(legacy, deflateResource(data, "full")) : legacy;
  });
  const effectFrameIndexByKey = new Map<string, number>();
  const effectFrameIndexByDigest = new Map<string, number>();
  const indexEffectFrame = (frame: EffectSource): number => {
    const existing = effectFrameIndexByKey.get(frame.key);
    if (existing !== undefined) return existing;
    if (frame.colors.length === 0) {
      // An authored fully-transparent lifecycle frame means "this plane is
      // clear for this step". The existing masked-rectangle codec can express
      // that without a format/runtime change: a valid 1x1 rectangle whose
      // only alpha-mask bit is zero and which therefore has no color payload.
      const codec = FRAME_CODEC_INDEX8_MASKED_RECT;
      const resourceData = Uint8Array.from([0, 0, 1, 1, 0]);
      const digest = `${codec}:${sha256(resourceData)}`;
      let bankIndex = effectFrameIndexByDigest.get(digest);
      if (bankIndex === undefined) {
        bankIndex = frameResources.length;
        frameResources.push({ codec, data: resourceData });
        effectFrameIndexByDigest.set(digest, bankIndex);
      }
      effectFrameIndexByKey.set(frame.key, bankIndex);
      return bankIndex;
    }
    let minX: number = CANVAS;
    let minY: number = CANVAS;
    let maxX = -1;
    let maxY = -1;
    for (let y = 0; y < CANVAS; y++) for (let x = 0; x < CANVAS; x++) {
      if (frame.image.data[(y * CANVAS + x) * 4 + 3] === 255) {
        if (x < minX) minX = x;
        if (y < minY) minY = y;
        if (x > maxX) maxX = x;
        if (y > maxY) maxY = y;
      }
    }
    const width = maxX - minX + 1;
    const height = maxY - minY + 1;
    const maskBytes = Math.ceil((width * height) / 8);
    const mask = new Uint8Array(maskBytes);
    const indexed: number[] = [];
    for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
      const local = y * width + x;
      const source = ((minY + y) * CANVAS + minX + x) * 4;
      if (frame.image.data[source + 3] === 255) {
        mask[local >> 3]! |= 1 << (local & 7);
        indexed.push(indexOf([frame.image.data[source]!, frame.image.data[source + 1]!, frame.image.data[source + 2]!]));
      }
    }
    const data = new Uint8Array(4 + mask.length + indexed.length);
    data.set([minX, minY, width, height]);
    data.set(mask, 4);
    data.set(indexed, 4 + mask.length);
    const rleColors = encodeRle(indexed);
    const rleData = new Uint8Array(4 + mask.length + rleColors.length);
    rleData.set([minX, minY, width, height]);
    rleData.set(mask, 4);
    rleData.set(rleColors, 4 + mask.length);
    const useRle = rleData.length < data.length;
    const legacy = { codec: useRle ? FRAME_CODEC_INDEX8_MASKED_RECT_RLE : FRAME_CODEC_INDEX8_MASKED_RECT, data: useRle ? rleData : data };
    const { codec, data: resourceData } = CANVAS === 240 ? smallestFrameResource(legacy, deflateResource(data, "masked")) : legacy;
    const digest = `${codec}:${sha256(resourceData)}`;
    let bankIndex = effectFrameIndexByDigest.get(digest);
    if (bankIndex === undefined) {
      bankIndex = frameResources.length;
      frameResources.push({ codec, data: resourceData });
      effectFrameIndexByDigest.set(digest, bankIndex);
    }
    effectFrameIndexByKey.set(frame.key, bankIndex);
    return bankIndex;
  };
  for (const steps of effectActionSources.values()) for (const step of steps) indexEffectFrame(step.frame);
  for (const steps of effectActionEnterSources.values()) for (const step of steps) indexEffectFrame(step.frame);
  for (const steps of effectActionExitSources.values()) for (const step of steps) indexEffectFrame(step.frame);
  const denseFrameIndexByDigest=new Map<string,number>();
  const indexDense=(frame:DenseSource,rect:{x:number;y:number;width:number;height:number}):number=>{const pixels=frame.colors.map(indexOf);const data=new Uint8Array(4+pixels.length);data.set([rect.x,rect.y,rect.width,rect.height]);data.set(pixels,4);const digest=sha256(data);let index=denseFrameIndexByDigest.get(digest);if(index===undefined){index=frameResources.length;frameResources.push(CANVAS === 240 ? smallestFrameResource({codec:FRAME_CODEC_INDEX8_DENSE_RECT,data}, deflateResource(data,"dense")) : {codec:FRAME_CODEC_INDEX8_DENSE_RECT,data});denseFrameIndexByDigest.set(digest,index);}return index;};
  const facialRegions = manifest.facialRegions ? {
    ...(manifest.facialRegions.independentBlink ? { independentBlink: true, gazeStageTicks:(manifest.facialRegions.gazeStageMs??[1980,1980,1980,1980,1980]).map(msToTicks) } : {}),
    groups: facialSources.map((group)=>({role:FACIAL_GROUP_ROLES.indexOf(group.def.role),baseFrame:frameIndexByKey.get(group.base.key)!,mouthRect:group.def.mouth.rect,eyeRect:group.def.eyes.rect,mouthFrames:group.mouth.map(f=>indexDense(f,group.def.mouth.rect)),eyeFrames:group.eyes.map(f=>indexDense(f,group.def.eyes.rect))})),
    centerGroup: facialSources.findIndex(g=>g.def.role==="center"),
    blinkStateMask: manifest.facialRegions.blink.states.reduce((m,s)=>m|STATE_BITS[s]!,0),
    blinkGaps: [manifest.facialRegions.blink.gaps.full.minMs,manifest.facialRegions.blink.gaps.full.maxMs,manifest.facialRegions.blink.gaps.balanced.minMs,manifest.facialRegions.blink.gaps.balanced.maxMs,manifest.facialRegions.blink.gaps.reduced.minMs,manifest.facialRegions.blink.gaps.reduced.maxMs].map(msToTicks) as [number,number,number,number,number,number],
    blinkStageTicks: manifest.facialRegions.blink.stageMs.map(msToTicks),
    poseStateMask: manifest.facialRegions.pose.states.reduce((m,s)=>m|STATE_BITS[s]!,0),
    bobStateMask: manifest.facialRegions.bob.states.reduce((m,s)=>m|STATE_BITS[s]!,0),bobFullAmplitude:manifest.facialRegions.bob.fullAmplitudePx,bobBalancedAmplitude:manifest.facialRegions.bob.balancedAmplitudePx,bobPeriodTicks:msToTicks(manifest.facialRegions.bob.periodMs),
    poseTimings:[manifest.facialRegions.pose.full.gap.minMs,manifest.facialRegions.pose.full.gap.maxMs,manifest.facialRegions.pose.full.hold.minMs,manifest.facialRegions.pose.full.hold.maxMs,manifest.facialRegions.pose.balanced.gap.minMs,manifest.facialRegions.pose.balanced.gap.maxMs,manifest.facialRegions.pose.balanced.hold.minMs,manifest.facialRegions.pose.balanced.hold.maxMs].map(msToTicks) as [number,number,number,number,number,number,number,number],
  } : undefined;

  // ---- Background palette index + post-quantization gates ----------------
  const bgPaletteIndex = indexOf(bgColor);
  for (const frame of sources) {
    const indexed = frameBank[frameIndexByKey.get(frame.key)!]!;
    let bgPixels = 0;
    let uniform = 0;
    let paletteError = 0;
    let maxPaletteError = 0;
    let framePaletteError = 0;
    for (let i = 0; i < CANVAS * CANVAS; i++) {
      if (nativePixelReview) {
        const error = weightedDistance(from565(to565(frame.pixels[i]!)), palette[indexed[i]!]!);
        framePaletteError += error;
        if (frame.bgMask[i]) {
          paletteError += error;
          if (error > maxPaletteError) maxPaletteError = error;
        }
      }
      if (!frame.bgMask[i]) continue;
      bgPixels++;
      if (indexed[i] === bgPaletteIndex) uniform++;
    }
    if (nativePixelReview) {
      const mean = framePaletteError / PIXELS;
      gate({
        gate: "native-source-fidelity",
        subject: frame.key,
        verdict: mean <= NATIVE_MAX_MEAN_WEIGHTED_ERROR ? "pass" : "fail",
        detail: `RGB565 source-to-indexed fidelity ${nativePsnr(mean).toFixed(2)} dB (minimum 30 dB); mean weighted error ${mean.toFixed(3)}`,
      });
    }
    const bgMean = nativePixelReview && bgPixels > 0 ? paletteError / bgPixels : 0;
    gate({
      gate: "background-uniformity",
      subject: frame.key,
      verdict: nativePixelReview
        ? bgPixels === 0 || bgMean > NATIVE_MAX_MEAN_WEIGHTED_ERROR ? "fail" : uniform === bgPixels ? "pass" : "warn"
        : uniform === bgPixels ? "pass" : "fail",
      detail: `${uniform}/${bgPixels} background pixels are the background palette index` +
        (nativePixelReview ? `; retained native background fidelity ${nativePsnr(bgMean).toFixed(2)} dB (minimum 30 dB), mean weighted error ${bgMean.toFixed(3)}, max ${maxPaletteError}; nonuniformity remains for human review` : ""),
    });
  }
  if (manifest.idle.bob.amplitudePx > 0) {
    // The idle bob shifts the frame down by up to `amplitudePx`, exposing the
    // top rows; those must be pure background in every frame or the bob would
    // reveal a visible seam.
    for (const frame of sources) {
      const indexed = frameBank[frameIndexByKey.get(frame.key)!]!;
      let clean = true;
      for (let y = 0; y < manifest.idle.bob.amplitudePx && clean; y++) {
        for (let x = 0; x < CANVAS; x++) {
          if (indexed[y * CANVAS + x] !== bgPaletteIndex) {
            clean = false;
            break;
          }
        }
      }
      gate({
        gate: "bob-safety",
        subject: frame.key,
        verdict: clean ? "pass" : "fail",
        detail: clean
          ? `top ${manifest.idle.bob.amplitudePx}px rows are pure background`
          : `art reaches the top ${manifest.idle.bob.amplitudePx}px rows; idle bob would expose a seam`,
      });
    }
  }
  if (manifest.motion.parallaxSafe && manifest.motion.maxParallaxPx > 0) {
    const border = manifest.motion.maxParallaxPx;
    for (const frame of sources) {
      const indexed = frameBank[frameIndexByKey.get(frame.key)!]!;
      let clean = true;
      for (let y = 0; y < CANVAS && clean; y++) for (let x = 0; x < CANVAS; x++) {
        if (x >= border && x < CANVAS - border && y >= border && y < CANVAS - border) continue;
        if (indexed[y * CANVAS + x] !== bgPaletteIndex) { clean = false; break; }
      }
      gate({
        gate: "parallax-safety",
        subject: frame.key,
        verdict: clean ? "pass" : "fail",
        detail: clean ? `${border}px border is uniform background` : "art reaches the parallax guard border",
      });
    }
  }

  // ---- Clips -------------------------------------------------------------
  const clips: Clip[] = [];
  const clipIndexByName = new Map<string, number>();
  const addClip = (clip: Clip): number => {
    const index = clips.length;
    clips.push(clip);
    clipIndexByName.set(clip.name, index);
    return index;
  };
  const idleNeutralClip = addClip({
    name: "idle.neutral",
    loopMode: LOOP_HOLD_LAST,
    steps: [{ frame: neutralFrame, durationTicks: 1 }],
  });
  const emotions: EmotionEntry[] = [];
  const micro: { clip: number; weight: number }[] = [];
  const performanceMicroIndexById = new Map<string, number>();
  for (const name of emotionNames) {
    const def = manifest.emotions[name]!;
    const entry = emotionSources.get(name)!;
    let enterClip: number;
    let holdClip: number;
    let exitClip: number;
    let microFrame: number;
    if ("enterSteps" in def) {
      if (entry.kind !== "detailed") throw new Error(`emotion ${name} lifecycle source mismatch`);
      const steps = (items: typeof entry.enter) => items.map((step) => ({
        frame: frameIndexByKey.get(step.frame.key)!,
        durationTicks: step.durationTicks,
      }));
      enterClip = addClip({ name: `emotion.${name}.enter`, loopMode: LOOP_ONCE, steps: steps(entry.enter) });
      holdClip = addClip({ name: `emotion.${name}.hold`, loopMode: def.holdMode === "loop" ? LOOP_LOOP : LOOP_HOLD_LAST, steps: steps(entry.hold) });
      exitClip = addClip({ name: `emotion.${name}.exit`, loopMode: LOOP_ONCE, steps: steps(entry.exit) });
      microFrame = frameIndexByKey.get(entry.enter[Math.min(1, entry.enter.length - 1)]!.frame.key)!;
    } else {
      if (entry.kind !== "legacy") throw new Error(`emotion ${name} legacy source mismatch`);
      const onsetFrame = frameIndexByKey.get(entry.onset.key)!;
      const fullFrame = frameIndexByKey.get(entry.full.key)!;
      enterClip = addClip({
        name: `emotion.${name}.enter`,
        loopMode: LOOP_ONCE,
        steps: [
          { frame: onsetFrame, durationTicks: def.enterTicks[0] },
          { frame: fullFrame, durationTicks: def.enterTicks[1] },
        ],
      });
      holdClip = addClip({ name: `emotion.${name}.hold`, loopMode: LOOP_HOLD_LAST, steps: [{ frame: fullFrame, durationTicks: 1 }] });
      exitClip = addClip({ name: `emotion.${name}.exit`, loopMode: LOOP_ONCE, steps: [{ frame: onsetFrame, durationTicks: def.exitTicks[0] }] });
      microFrame = onsetFrame;
    }
    emotions.push({
      id: EMOTION_IDS[name]!,
      name,
      enterClip,
      holdClip,
      exitClip,
      minHoldMs: def.minHoldMs,
      maxHoldMs: def.maxHoldMs,
    });
    if (def.microWeight > 0) {
      const microClip = addClip({
        name: `micro.${name}`,
        loopMode: LOOP_ONCE,
        steps: [{ frame: microFrame, durationTicks: manifest.idle.micro.onsetTicks }],
      });
      micro.push({ clip: microClip, weight: def.microWeight });
    }
  }
  for (const performance of manifest.idle.performances) {
    const steps = performanceSources.get(performance.id)!.map((step) => ({
      frame: frameIndexByKey.get(step.frame.key)!,
      durationTicks: step.durationTicks,
    }));
    steps.push({ frame: neutralFrame, durationTicks: msToTicks(performance.returnMs) });
    const clip = addClip({
      name: `performance.${performance.id}`,
      loopMode: LOOP_ONCE,
      steps,
    });
    performanceMicroIndexById.set(performance.id, micro.length);
    micro.push({ clip, weight: performance.weight });
  }

  const actions: ActionEntry[] = [];
  const loopCode = (value: "once" | "loop" | "hold-last"): number =>
    value === "loop" ? LOOP_LOOP : value === "hold-last" ? LOOP_HOLD_LAST : LOOP_ONCE;
  for (const action of manifest.actions) {
    const base = action.plane === "base";
    const mainSources = base ? baseActionSources.get(action.id)! : effectActionSources.get(action.id)!;
    const enterSources = base ? baseActionEnterSources.get(action.id) : effectActionEnterSources.get(action.id);
    const exitSources = base ? baseActionExitSources.get(action.id) : effectActionExitSources.get(action.id);
    const frameIndex = (frame: SourceFrame | EffectSource): number =>
      base ? frameIndexByKey.get(frame.key)! : effectFrameIndexByKey.get(frame.key)!;
    const clip = addClip({
      name: `action.${action.id}`,
      loopMode: loopCode("enterSteps" in action ? action.holdMode : action.loop),
      steps: mainSources.map((step) => ({ frame: frameIndex(step.frame), durationTicks: step.durationTicks })),
    });
    const enterClip = enterSources
      ? addClip({
          name: `action.${action.id}.enter`,
          loopMode: LOOP_ONCE,
          steps: enterSources.map((step) => ({ frame: frameIndex(step.frame), durationTicks: step.durationTicks })),
        })
      : ACTION_NO_CLIP;
    const exitClip = exitSources
      ? addClip({
          name: `action.${action.id}.exit`,
          loopMode: LOOP_ONCE,
          steps: exitSources.map((step) => ({ frame: frameIndex(step.frame), durationTicks: step.durationTicks })),
        })
      : ACTION_NO_CLIP;
    const stateMask = action.activation.states.reduce((mask, state) => mask | STATE_BITS[state]!, 0);
    const expressionMask = action.activation.expressions.reduce((mask, expression) => mask | expressionBit(expression), 0);
    const performanceMask = action.activation.performances.reduce((mask, performance) => {
      const index = performanceMicroIndexById.get(performance);
      if (index === undefined) throw new Error(`action ${action.id} references unknown idle performance ${performance}`);
      return mask | (1 << index);
    }, 0);
    const profileMask = action.profiles.reduce((mask, profile) => mask | PROFILE_BITS[profile], 0);
    actions.push({
      id: action.id,
      semantic: action.semantic,
      plane: action.plane,
      activationKind: action.activation.kind,
      clip,
      enterClip,
      exitClip,
      priority: action.priority,
      essential: action.essential,
      profileMask,
      stateMask,
      expressionMask,
      performanceMask,
      intervalMinTicks: action.activation.intervalMs ? msToTicks(action.activation.intervalMs.min) : 0,
      intervalMaxTicks: action.activation.intervalMs ? msToTicks(action.activation.intervalMs.max) : 0,
      cooldownTicks: action.cooldownMs ? msToTicks(action.cooldownMs) : 0,
      posePolicy: action.posePolicy ?? (action.plane === "characterFx" ? "center-only" : "screen"),
    });
  }

  // ---- Talk table --------------------------------------------------------
  const levelToStage = new Uint8Array(TALK_LUT_BYTES);
  for (let level = 0; level < TALK_LUT_BYTES; level++) {
    let stage = 0;
    for (let i = 0; i < manifest.talk.levelBreakpoints.length; i++) {
      if (level >= manifest.talk.levelBreakpoints[i]!) stage = i;
    }
    levelToStage[level] = stage;
  }

  // ---- Speaking poses ----------------------------------------------------
  const poseIndex = new Map(["upright", ...manifest.talk.poses.map((pose) => pose.id)].map((id, index) => [id, index]));
  const speakingPoses: SpeakingPoses | undefined = manifest.talk.poses.length > 0 ? {
    frames: [talkFrames, ...poseFrames],
    gestures: manifest.talk.gestures.map((gesture) => ({
      kind: gesture.kind,
      automatic: gesture.automatic,
      steps: gesture.path.map((step) => ({ pose: poseIndex.get(step.pose)!, ticks: msToTicks(step.durationMs) })),
    })),
    breakMinTicks: msToTicks(manifest.talk.breakMs.minMs),
    breakMaxTicks: msToTicks(manifest.talk.breakMs.maxMs),
  } : undefined;

  // ---- Roles -------------------------------------------------------------
  const roles = new Array<number>(ROLE_COUNT).fill(ROLE_ABSENT);
  roles[ROLE_IDLE_NEUTRAL] = idleNeutralClip;

  // ---- Meta + model ------------------------------------------------------
  const paletteMeta = {
    strategy: paletteResult.strategy,
    uniqueBefore: paletteResult.uniqueBefore,
    count: palette.length,
    reservedTalkColors: paletteResult.reservedCount,
    talkMeanError: Number(talkMeanError.toFixed(3)),
    emotionMeanError: Number(emotionMeanError.toFixed(1)),
  };
  const meta = {
    ...(cleanPlateFrame === undefined ? {} : {cleanPlateFrame}),
    character: { id: manifest.id, name: manifest.name, version: manifest.version },
    tool: "@aipet/frame-pack 0.1.0",
    origin: lock.origin,
    sources: Object.fromEntries(Object.entries(lock.files).map(([file, entry]) => [file, entry.sha256])),
    palette: paletteMeta,
    ...(effectiveProfile ? { effectProfile: {
      baselineManifest: effectiveProfile.baselineManifest,
      baselineManifestSha256: effectiveProfile.baselineManifestSha256,
      roles: effectiveProfile.roles,
    } } : {}),
    backgroundColor: bgColor,
    generation: manifest.provenance.generation ?? null,
    idlePerformances: manifest.idle.performances.map((performance) => performance.id),
    publicationRights: manifest.provenance.publicationRights,
  };
  const model: FramePackModel = {
    canvas: CANVAS,
    ...(CANVAS === 240 ? { maxBytes: manifest.slotCapacityBytes! } : {}),
    id: manifest.id,
    name: manifest.name,
    version: manifest.version,
    gender: GENDER_CODES[manifest.gender]!,
    approved: manifest.approval.status === "approved",
    palette,
    bgPaletteIndex,
    frames: frameResources,
    clips,
    roles,
    emotions,
    talk: { stageFrames: talkFrames, levelToStage },
    idle: {
      bobAmplitudePx: manifest.idle.bob.amplitudePx,
      bobPeriodTicks: msToTicks(manifest.idle.bob.periodMs),
      microGapMinTicks: msToTicks(manifest.idle.micro.minGapMs),
      microGapMaxTicks: msToTicks(manifest.idle.micro.maxGapMs),
      micro,
      fallbacksEnabled: manifest.schemaVersion >= 2 && manifest.motion.fallbacksEnabled,
      parallaxSafe: manifest.schemaVersion >= 2 && manifest.motion.parallaxSafe,
      maxParallaxPx: manifest.schemaVersion >= 2 ? manifest.motion.maxParallaxPx : 0,
    },
    actions,
    ...(facialRegions ? { facialRegions } : {}),
    ...(speakingPoses ? { speakingPoses } : {}),
    meta,
  };
  if (micro.length > 0 && model.idle.microGapMinTicks >= model.idle.microGapMaxTicks) {
    throw new Error(
      `idle.micro gap range collapses after 33 ms tick quantization (${model.idle.microGapMinTicks} >= ${model.idle.microGapMaxTicks}); widen minGapMs/maxGapMs`,
    );
  }
  const pack = writeFramePack(model);

  // ---- Size gate ---------------------------------------------------------
  gate({
    gate: "pack-size",
    subject: "pack",
    verdict: pack.length <= manifest.budgetBytes ? "pass" : "fail",
    detail: `${pack.length} bytes vs budget ${manifest.budgetBytes}`,
  });

  // ---- Frame uniqueness (aliasing is expected for stage 0 = neutral) -----
  const aliasGroups = new Map<number, string[]>();
  for (const [key, index] of frameIndexByKey) {
    const group = aliasGroups.get(index) ?? [];
    group.push(key);
    aliasGroups.set(index, group);
  }
  for (const [index, keys] of aliasGroups) {
    if (keys.length > 1 && !(keys.includes("neutral") && keys.every((k) => k === "neutral" || k.startsWith("talk[")))) {
      gate({
        gate: "frame-uniqueness",
        subject: keys.join(" == "),
        verdict: "warn",
        detail: `frames collapsed to the same bank index ${index} after quantization — check the art actually differs`,
      });
    }
  }

  const report: Record<string, unknown> = {
    character: { id: manifest.id, name: manifest.name, version: manifest.version },
    canvas: `${CANVAS}x${CANVAS}`,
    packBytes: pack.length,
    payloadCrc32: crc32(pack.subarray(128)) >>> 0,
    frameCount: frameResources.length,
    actionCount: actions.length,
    facialGroupCount: facialRegions?.groups.length ?? 0,
    facialCombinations: facialRegions ? facialRegions.groups.length * 7 * 5 * 3 : 0,
    clipCount: clips.length,
    emotionCount: emotions.length,
    palette: paletteMeta,
    backgroundColor: bgColor,
    bgPaletteIndex,
    sources: sources.map((f) => ({
      key: f.key,
      file: f.file,
      shift: f.shift,
      bgPixels: f.bgMask.reduce((n, v) => n + v, 0),
      grid: f.grid
        ? {
            cellX: f.grid.x.s,
            cellY: f.grid.y.s,
            liftX: Number(f.grid.x.lift.toFixed(1)),
            liftY: Number(f.grid.y.lift.toFixed(1)),
          }
        : null,
    })),
    gates,
    verdict: gates.some((g) => g.verdict === "fail") ? "fail" : gates.some((g) => g.verdict === "warn") ? "warn" : "pass",
  };

  return {
    manifest,
    model,
    pack,
    gates,
    report,
    frames: frameBank,
    palette,
    sources,
    frameIndexByKey,
    effectFrameIndexByKey,
  };
}
